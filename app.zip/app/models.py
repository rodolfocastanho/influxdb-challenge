from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship, backref

from sqlalchemy.sql import text
from pymongo import MongoClient

from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash

from flask_login import UserMixin
from flask_security import RoleMixin

import urllib.parse
import os
import datetime
import config

db = SQLAlchemy()


class RolesUsers(db.Model):
    __bind_key__ = 'portaltx'
    __tablename__ = 'roles_users'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column('user_id', db.Integer, db.ForeignKey('users.id'))
    role_id = db.Column('role_id', db.Integer, db.ForeignKey('roles.id'))

    def __init__(self, user_id, role_id):
        self.user_id = user_id
        self.role_id = role_id


class Role(RoleMixin, db.Model):
    __bind_key__ = 'portaltx'
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True)
    description = db.Column(db.String(100))


class User(UserMixin, db.Model):
    __bind_key__ = 'portaltx'
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(10), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(200))
    create_date = db.Column(db.DateTime, default=datetime.datetime.now())
    create_user_id = db.Column(db.Integer)
    last_access = db.Column(db.DateTime, default=datetime.datetime.now())
    roles = relationship('Role', secondary='roles_users', backref=backref('users', lazy='dynamic'))

    def __init__(self, username, password, name, create_user_id):
        self.username = username
        self.password = self.__create_password__(password)
        self.name = name
        self.create_user_id = create_user_id

    def __create_password__(self, password):
        return generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password, password)

    def has_role(self, role):
        return role in self.roles

x = """
class Etp(db.Model):
    __bind_key__ = 'portaltx'
    __tablename__ = 'etp_atributos'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column('user_id', db.Integer, db.ForeignKey('users.id'))
    role_id = db.Column('role_id', db.Integer, db.ForeignKey('roles.id'))

    def __init__(self, user_id, role_id):
        self.user_id = user_id
        self.role_id = role_id
"""


def qry_db(sql, bind):
    return db.create_engine(config.DevelopmentConfig.SQLALCHEMY_BINDS[bind], engine_opts={}).execute(text(sql))


class MongoAPI:
    def __init__(self, keys, collection):
        conn = MongoClient('mongodb://%s:%s@%s' % (keys['user'], keys['passw'], keys['host']))
        db = conn[keys['database']]
        self.collection = db[collection]


def keys(host, user, passw, database):
    return {
        'host': urllib.parse.quote_plus(host),
        'user': urllib.parse.quote_plus(user),
        'passw': urllib.parse.quote_plus(passw),
        'database': urllib.parse.quote_plus(database)
    }


rsnac_uri = keys(os.getenv('DB_HOST_RSNAC'), os.getenv('DB_USER_RSNAC'), os.getenv('DB_PASS_RSNAC'), os.getenv('DB_BASE_RSNAC'))
etp_uri = keys(os.getenv('DB_HOST_ETP'), os.getenv('DB_USER_ETP'), os.getenv('DB_PASS_ETP'), os.getenv('DB_BASE_ETP'))
municipios_uri = keys(os.getenv('DB_HOST_MUNICIPIOS'), os.getenv('DB_USER_MUNICIPIOS'), os.getenv('DB_PASS_MUNICIPIOS'), os.getenv('DB_BASE_MUNICIPIOS'))
spam_monitor_uri = keys(os.getenv('DB_HOST_SPAMMONITOR'), os.getenv('DB_USER_SPAMMONITOR'), os.getenv('DB_PASS_SPAMMONITOR'), os.getenv('DB_BASE_SPAMMONITOR'))
influx_loss_uri = {
    'host': os.getenv('DB_HOST_INFLUX_LOSS'),
    'token': os.getenv('DB_TOKEN_INFLUX_LOSS'),
    'org': os.getenv('DB_ORG_INFLUX_LOSS'),
    'bucket': os.getenv('DB_BK_INFLUX_LOSS')
}


