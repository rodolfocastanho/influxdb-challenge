from flask import Blueprint

from flask_login import login_required
from flask_security import roles_accepted

inventario_bp = Blueprint('inventario', __name__)


@inventario_bp.route('/inventario', methods=['GET'])
@login_required
@roles_accepted('topology')
def inventario():
    pass
    # TODO: Tabela completa com filtros (Verificar Dash (Plotly))

