from flask import Blueprint

from flask_login import login_required, current_user
from flask import url_for, render_template, redirect, jsonify, request
from flask_security import roles_accepted

import pandas as pd

import influxdb_client
from influxdb_client import InfluxDBClient

from models import qry_db, rsnac_uri, MongoAPI, etp_uri, influx_loss_uri

topology_bp = Blueprint('topology', __name__)


@topology_bp.route('/', methods=['GET'])
@topology_bp.route('/index', methods=['GET'])
@login_required
def index():
    return render_template('index.html')
    # return redirect(url_for('.topologia'))


@topology_bp.route('/topologia', methods=['GET'])
@login_required
@roles_accepted('topology')
def topologia():
    ## SQL SERVER
    sites = qry_db("SELECT CONCAT(SiteA,'.',UFA) AS Site from smtx_ots "
                   "UNION "
                   "SELECT CONCAT(SiteB,'.',UFB) AS Site from smtx_ots "
                   "UNION "
                   "SELECT CONCAT(Site,'.',UF) AS Site from vw_smtx_map_marker group by CONCAT(Site,'.',UF) "
                   "UNION "
                   "SELECT CONCAT(sigla,'.',UF) AS Site from science_sites group by CONCAT(sigla,'.',UF)", 'portaltx')
    municipios = qry_db("SELECT CONCAT(nome,' - ',UF) AS Site FROM smtx_ibge_municipios", 'portaltx')
    municipiosCoordinates = qry_db("SELECT cod_ibge, nome, UF, populacao, CAST(latitude AS CHAR(18)) AS latitude, CAST(longitude AS CHAR(18)) AS longitude FROM smtx_ibge_municipios", 'portaltx')
    siglasOts = qry_db("select Sigla as Site from smtx_ots group by Sigla order by Sigla", 'portaltx')

    sites = [dict(row) for row in sites] + [dict(row) for row in municipios]

    return render_template('map.html',
                           sites=[dict(row) for row in sites],
                           municipiosCoordinates=[dict(row) for row in municipiosCoordinates],
                           siglasOts=[dict(row) for row in siglasOts]
                           )


@topology_bp.route('/ajax-topology', methods=['GET'])
@login_required
def ajax_topology():
    locations = qry_db(
        "SELECT Site, UF, ReleaseHW, Fabricante, CAST(Latitude AS CHAR(18)) AS Latitude, CAST(Longitude AS CHAR(18)) "
        "AS Longitude FROM vw_smtx_map_marker", 'portaltx')
    networkTopologyCoordinates = qry_db("SELECT * FROM vw_smtx_map_coordinate_web", 'portaltx')

    locationsOts = qry_db(
        "SELECT SiteA AS Site, UFA AS UF, ReleaseHWA AS ReleaseHW, TRIM(FabricanteA) AS Fabricante, "
        "CAST(LatitudeA AS CHAR(18)) AS Latitude, CAST(LongitudeA AS CHAR(18)) AS Longitude FROM smtx_ots "
        "UNION "
        "SELECT SiteB AS Site, UFB AS UF, ReleaseHWB AS ReleaseHW, TRIM(FabricanteB) AS Fabricante, "
        "CAST(LatitudeB AS CHAR(18)) AS Latitude, CAST(LongitudeB AS CHAR(18)) AS Longitude FROM smtx_ots", 'portaltx')
    networkTopologyCoordinatesOts = qry_db("SELECT * FROM vw_smtx_map_coordinate_web_ots", 'portaltx')

    # Camada HL ------------------------------------------------------------
    obj = MongoAPI(rsnac_uri, 'elements_layers')
    locationsHl = obj.collection.find({}, {'_id': 0,
                                         'Site': 1, 'UF': 1, 'ReleaseHW': 1,
                                         'Chave': 1, 'Latitude': 1, 'Longitude': 1})
    locationsHl = [dict(s) for s in set(frozenset(d.items()) for d in list(locationsHl))]
    # ------------------------------------------------------------------------

    response = {
        'locations': [dict(row) for row in locations],
        'networkTopologyCoordinates': [dict(row) for row in networkTopologyCoordinates],
        'locationsOts': [dict(row) for row in locationsOts],
        'networkTopologyCoordinatesOts': [dict(row) for row in networkTopologyCoordinatesOts],
        'locationsHl': [dict(row) for row in locationsHl]
    }

    return jsonify(response)


@topology_bp.route('/ajax-network-ots', methods=['GET'])
@login_required
def ajax_network_ots():
    otss = request.args.get('otss')

    sqlNetworkOtsInfos = """
        SELECT 
        netw.idWDMOTS, 
        STUFF
        ((SELECT ', ' + CONVERT(varchar(10), B.idWDMOCH)
        FROM vw_smtx_eild_ots B
        WHERE B.idWDMOTS = netw.idWDMOTS
        GROUP BY ', ' + CONVERT(varchar(10), B.idWDMOCH) FOR XML PATH('')), 1, 2, '') AS ochs, 
        STUFF
        ((SELECT ', ' + CONVERT(varchar(10), B.idWDMODU)
        FROM vw_smtx_eild_ots B
        WHERE B.idWDMOTS = netw.idWDMOTS
        GROUP BY ', ' + CONVERT(varchar(10), B.idWDMODU) FOR XML PATH('')), 1, 2, '') AS odus, 
        STUFF
        ((SELECT ', ' + CONVERT(varchar(10), B.NumEILD)
        FROM vw_smtx_eild_ots B
        WHERE B.idWDMOTS = netw.idWDMOTS
        GROUP BY ', ' + CONVERT(varchar(10), B.NumEILD) FOR XML PATH('')), 1, 2, '') AS eilds 
        FROM 
        vw_smtx_eild_ots as netw  
        WHERE 
        netw.idWDMOTS in ({}) 
        GROUP BY 
        netw.idWDMOTS
    """.format(otss)
    NetworkOtsInfos = qry_db(sqlNetworkOtsInfos, 'portaltx')
    NetworkOtsInfos = [dict(row) for row in NetworkOtsInfos]

    # buscar Caracterizacao
    NetworkOtsCaracterizacao = {}
    for ots in otss.split(','):
        sqlCaracterizacao = """
            SELECT 
            fibra_caracterizacao.* 
            FROM fibra_caracterizacao INNER JOIN 
            vw_fibra_caracterizacao_max_carga ON 
            fibra_caracterizacao.Identificador = vw_fibra_caracterizacao_max_carga.Identificador AND 
            fibra_caracterizacao.DataCarga = vw_fibra_caracterizacao_max_carga.MaxDataCarga 
            WHERE fibra_caracterizacao.Id_OTS in ({}) 
            ORDER BY fibra_caracterizacao.Identificador
        """.format(ots)
        dataCaracterizacao = qry_db(sqlCaracterizacao, 'portaltx')
        dataCaracterizacao = [dict(row) for row in dataCaracterizacao]
        NetworkOtsCaracterizacao[str(ots)] = dataCaracterizacao

    # buscar ETP's por OTS e Atenuação (InfluxDB)
    NetworkOtsEtps = []
    NetworkOtsAtenuacao = {}
    for ots in otss.split(','):
        obj = MongoAPI(etp_uri, 'resumes')
        etps = obj.collection.find({"data.data_smtx_ots.idWDMOTS": int(ots)}, {'_id': 0, 'etp': 1})
        etps = str([etp['etp'] for etp in etps]).replace('[', '').replace(']', '').replace("'", "")
        NetworkOtsEtps.append({'idWDMOTS': ots, 'etps': etps})

        try:
            client = influxdb_client.InfluxDBClient(url=influx_loss_uri['host'], token=influx_loss_uri['token'], org=influx_loss_uri['org'])
            query_api = client.query_api()
            query = """from(bucket: "{0}")
              |> range(start: -7d)
              |> filter(fn: (r) => r["_measurement"] == "span_loss")
              |> filter(fn: (r) => r["_field"] == "span_att")
              |> filter(fn: (r) => r["ots_id"] == "{1}")
              |> yield(name: "mean")""".format(influx_loss_uri['bucket'], str(ots))
            tables = query_api.query(query, org=influx_loss_uri['org'])
            client.close()

            measurements_ots = [['Data', 'Atenuação OTS '+str(ots)+' - 7 dias']]
            for table in tables:
                for record in table.records:
                    measurements_ots.append([record.get_time().strftime("%d/%m/%Y %H:%M"), record.get_value()])

            NetworkOtsAtenuacao[str(ots)] = measurements_ots
        except Exception as e:
            NetworkOtsAtenuacao[str(ots)] = []


    obj = MongoAPI(etp_uri, 'supports')
    result = obj.collection.find_one({}, {'_id': 0})
    supports = {}
    kList = ['fiber_owner']
    for k in kList:
        supports[k] = [i['k'] for i in list(result[k])]
        supports[k].sort()

    response = {
        'NetworkOtsInfos': [dict(row) for row in NetworkOtsInfos],
        'NetworkOtsEtps': [dict(row) for row in NetworkOtsEtps],
        'NetworkOtsCaracterizacao': NetworkOtsCaracterizacao,
        'NetworkOtsAtenuacao': NetworkOtsAtenuacao,
        'validation': bool(current_user.has_role('etps_edit')),
        'supportsedit': supports
    }

    return jsonify(response)


@topology_bp.route('/filtro_detalhes', methods=['GET'])
@login_required
def filtro_detalhes():
    ids = request.args.get('ids')
    filtro = request.args.get('filtro')

    sqlIdsRotaDetalhes = "SELECT * FROM smtx_circuitos_detalhes WHERE " + filtro + " in (" + ids + ")  ORDER BY " + filtro
    IdsRotaDetalhes = qry_db(sqlIdsRotaDetalhes, 'portaltx')
    IdsRotaDetalhes = [dict(row) for row in IdsRotaDetalhes]

    return render_template('map_filtro_detalhes.html', infos=IdsRotaDetalhes)


@topology_bp.route('/ajax-circuitos-oms', methods=['GET'])
@login_required
def ajax_circuitos_oms():
    ids = request.args.get('ids_oms')

    qryCircuitosOMS = "SELECT " + \
                    "oe.idWDMOMS as ID_OMS, " + \
                    "eild.NumEILD as EILD1, " + \
                    "eild.Sigla as SiglaRota, " + \
                    "eild.VelocidadeMeio as VelocidadeRota, " + \
                    "oe.NumOE as NumOE, " + \
                    "oe.Descricao as DescrOE " + \
                    "FROM smtx_oe AS oe LEFT JOIN smtx_eild as eild " + \
                    "ON oe.NumOE = eild.NumOE " + \
                    "WHERE oe.idWDMOMS in (" + ids + ") " + \
                    "AND oe.TipoOE = 'Circuito' " + \
                    "GROUP " + \
                    "BY " + \
                    "oe.idWDMOMS, " + \
                    "eild.NumEILD, " + \
                    "eild.Sigla, " + \
                    "eild.VelocidadeMeio, " + \
                    "oe.NumOE, " + \
                    "oe.Descricao " + \
                    "ORDER BY eild.VelocidadeMeio, oe.idWDMOMS, eild.NumEILD "


    #circuitosOMS = qry_db("SELECT * FROM smtx_circuitos_detalhes WHERE ID_OMS IN (" + ids + ") ORDER BY ID_OMS, EILD1")
    circuitosOMS = qry_db(qryCircuitosOMS, 'portaltx')
    response = {
        'circuitosOMS': [dict(row) for row in circuitosOMS]
    }
    return jsonify(response)