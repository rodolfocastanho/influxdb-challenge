from flask import Blueprint
from flask import url_for, render_template, redirect, request, flash, session
from flask_login import login_required

from models import qry_db
import forms as forms

b2b_bp = Blueprint('b2b', __name__)

@b2b_bp.route('/b2b', methods=['GET', 'POST'])
@login_required
def cotacao():
    b2b_cotacao = forms.B2bCotacao(request.form)

    if request.method == 'POST' and b2b_cotacao.validate():
        pass
    else:
        pass

    return render_template('b2b.html', form=b2b_cotacao)

    per = qry_db("SELECT * FROM vw_smtx_map_per", 'portaltx')
    per = [dict(row) for row in per]
    response = {
        'per': [dict(row) for row in per]
    }
    return jsonify(response)