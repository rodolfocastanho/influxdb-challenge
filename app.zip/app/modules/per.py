from flask import Blueprint

from flask_login import login_required
from flask import jsonify, request

from models import qry_db

per_bp = Blueprint('per', __name__)


@per_bp.route('/ajax-per', methods=['GET'])
@login_required
def ajax_per():
    per = qry_db("SELECT * FROM vw_smtx_map_per", 'portaltx')
    per = [dict(row) for row in per]
    response = {
        'per': [dict(row) for row in per]
    }
    return jsonify(response)


@per_bp.route('/ajax-science', methods=['GET'])
@login_required
def ajax_science():
    uf = request.args.get('uf')

    qry_marker = """
    SELECT sigla as Site, uf as UF, '' as ReleaseHW, '' as Fabricante, 
    CAST(latitude AS CHAR(18)) AS Latitude,  CAST(longitude AS CHAR(18)) AS Longitude 
    FROM science_sites 
    WHERE uf = '{}' 
    ORDER BY uf, nome, utilizacao
    """.format(uf)

    marker = qry_db(qry_marker, 'portaltx')
    marker = [dict(row) for row in marker]
    response = {
        'marker': [dict(row) for row in marker]
    }
    return jsonify(response)
