from flask import Blueprint

from flask_login import login_required
from flask import jsonify, request

from models import qry_db

idrota_bp = Blueprint('idrota', __name__)


@idrota_bp.route('/ajax-idrota', methods=['GET'])
@login_required
def ajax_idrota():
    ids = request.args.get('ids_form')
    idsC = request.args.get('ids_form') if request.args.get('ids_form_c') is None else request.args.get('ids_form_c')
    filtro = request.args.get('filtro')

    if filtro == 'OCH':
        sqlIdsRota = "SELECT och.idWDMOCH AS idRota, och.ochSiteA AS SiteA, och.ochSiteB AS SiteB, " + \
                     "och.L0 AS L0, " + \
                     "CASE WHEN SUM(eng.Latencia) IS NULL THEN 0 ELSE SUM(eng.Latencia) END AS Latencia " + \
                     "FROM smtx_och as och LEFT JOIN smtx_eng as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE och.idWDMOCH IN (" + ids + ") " + \
                     "GROUP BY och.idWDMOCH, och.ochSiteA, och.ochSiteB, och.L0"
        sqlIdsRotaOMS = "SELECT " + \
                        "och.idWDMOCH AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status " + \
                        "FROM smtx_och as och INNER JOIN vw_smtx_map_coordinate_web as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                        "WHERE och.idWDMOCH IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "och.idWDMOCH, " + \
                        "eng.idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status " + \
                        "ORDER BY och.idWDMOCH"
        idsRotaExcel = "SELECT * FROM vw_smtx_excel_eild WHERE idWDMOCH in (" + ids + ") ORDER BY idWDMOCH, ochOrdemTrecho"
    elif filtro == 'ODU':
        sqlIdsRota = "SELECT odu.idWDMODU AS idRota, odu.oduSiteA AS SiteA, odu.oduSiteB AS SiteB, " + \
                     "odu.L1 AS L1, odu.L0 AS L0, " + \
                     "odu.Caminho, " + \
                     "CASE WHEN SUM(eng.Latencia) IS NULL THEN 0 ELSE SUM(eng.Latencia) END AS Latencia " + \
                     "FROM smtx_odu as odu LEFT JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                     "LEFT JOIN smtx_eng as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE odu.idWDMODU IN (" + ids + ")  AND odu.Caminho IS NOT NULL " + \
                     "GROUP BY odu.idWDMODU, odu.oduSiteA, odu.oduSiteB, odu.L1, odu.L0, odu.Caminho"
        sqlIdsRotaOMS = "SELECT " + \
                        "odu.idWDMODU AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status, " + \
                        "odu.Caminho " + \
                        "FROM smtx_odu as odu INNER JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                        "INNER JOIN vw_smtx_map_coordinate_web as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                        "WHERE odu.idWDMODU IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "odu.idWDMODU, " + \
                        "eng.idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status, " + \
                        "odu.Caminho " + \
                        "ORDER BY odu.idWDMODU"
        idsRotaExcel = "SELECT * FROM vw_smtx_excel_eild where idWDMODU IN (" + ids + ") ORDER BY idWDMODU, oduOrdemTrecho"
    elif filtro == 'NumEILD' or filtro == 'idRota':
        sqlIdsRota = "SELECT eild." + filtro + " AS idRota, eild.rotaSiteA AS SiteA, eild.rotaSiteB AS SiteB, " + \
                     "eild.L1 AS L1, eild.L0 AS L0, " + \
                     "odu.Caminho, " + \
                     "CASE WHEN SUM(eng.Latencia) IS NULL THEN 0 ELSE SUM(eng.Latencia) END AS Latencia " + \
                     "FROM smtx_eild as eild LEFT JOIN smtx_odu as odu ON eild.idWDMODU = odu.idWDMODU " + \
                     "LEFT JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                     "LEFT JOIN smtx_eng as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE eild." + filtro + " IN (" + ids + ")  AND odu.Caminho IS NOT NULL " + \
                     "GROUP BY eild." + filtro + ", eild.rotaSiteA, eild.rotaSiteB, eild.L1, eild.L0, odu.Caminho "
        sqlIdsRotaOMS_OLD = "SELECT " + \
                        "eild." + filtro + " AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status, " + \
                        "odu.Caminho " + \
                        "FROM smtx_eild as eild INNER JOIN smtx_odu as odu ON eild.idWDMODU = odu.idWDMODU " + \
                        "INNER JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                        "INNER JOIN vw_smtx_map_coordinate_web as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                        "WHERE eild." + filtro + " IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "eild." + filtro + ", " + \
                        "eng.idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status, " + \
                        "odu.Caminho " + \
                        "ORDER BY eild." + filtro
        sqlIdsRotaOMS = "SELECT " + \
                        filtro + " AS idRota, " + \
                        "idWDMOTS AS idWDMOMS, " + \
                        "ReleaseHWA_OTS AS ReleaseHWA, " + \
                        "FabricanteA_OTS AS FabricanteA, " + \
                        "ReleaseHWB_OTS AS ReleaseHWB, " + \
                        "FabricanteB_OTS AS FabricanteB, " + \
                        "SiteA_OTS AS SiteA, " + \
                        "UFA_OTS AS UFA, " + \
                        "LatitudeA_OTS AS LatitudeA, " + \
                        "LongitudeA_OTS AS LongitudeA, " + \
                        "SiteB_OTS AS SiteB, " + \
                        "UFB_OTS AS UFB, " + \
                        "LatitudeB_OTS AS LatitudeB, " + \
                        "LongitudeB_OTS AS LongitudeB, " + \
                        "Status_OTS AS Status, " + \
                        "Caminho " + \
                        "FROM vw_smtx_eild_ots " + \
                        "WHERE " + filtro + " IN (" + ids + ") " + \
                        "GROUP BY " + \
                        filtro + ", " + \
                        "idWDMOTS, " + \
                        "ReleaseHWA_OTS, " + \
                        "FabricanteA_OTS, " + \
                        "ReleaseHWB_OTS, " + \
                        "FabricanteB_OTS, " + \
                        "SiteA_OTS, " + \
                        "UFA_OTS, " + \
                        "LatitudeA_OTS, " + \
                        "LongitudeA_OTS, " + \
                        "SiteB_OTS, " + \
                        "UFB_OTS, " + \
                        "LatitudeB_OTS, " + \
                        "LongitudeB_OTS, " + \
                        "Status_OTS, " + \
                        "Caminho " + \
                        "ORDER BY " + filtro
        idsRotaExcel = "select * from vw_smtx_excel_eild where " + filtro + " in (" + ids + ") ORDER BY idRota, rotaOrdemTrecho"
    elif filtro == 'OE':
        sqlIdsRota = "SELECT oe.NumOE AS idRota, oe.TipoOE AS SiteA, '' AS SiteB, " + \
                     "CASE WHEN SUM(eng.Latencia) IS NULL THEN 0 ELSE SUM(eng.Latencia) END AS Latencia " + \
                     "FROM smtx_oe as oe LEFT JOIN smtx_eng as eng ON oe.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE oe.NumOE IN (" + ids + ") " + \
                     "GROUP BY oe.NumOE, oe.TipoOE"
        sqlIdsRotaOMS = "SELECT " + \
                        "oe.NumOE AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status " + \
                        "FROM smtx_oe as oe LEFT JOIN vw_smtx_map_coordinate_web as eng ON oe.idWDMOMS = eng.idWDMOMS " + \
                        "WHERE oe.NumOE IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "oe.NumOE, " + \
                        "eng.idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status " + \
                        "ORDER BY oe.NumOE"
        idsRotaExcel = "select * from vw_smtx_excel_oe WHERE NumOE IN (" + ids + ") ORDER BY NumOE, idWDMOMS"
    elif filtro == 'OMS':
        sqlIdsRota = "SELECT smtx.idWDMOMS AS idRota, " + \
                     "CONCAT(smtx.SiteA,'-',smtx.UFA) AS SiteA, CONCAT(smtx.SiteB,'-',smtx.UFB) AS SiteB, " + \
                     "CASE WHEN eng.Latencia IS NULL THEN 0 ELSE eng.Latencia END AS Latencia " + \
                     "FROM vw_smtx_map_coordinate_web as smtx LEFT JOIN smtx_eng as eng ON smtx.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE CONVERT(varchar(10), smtx.idWDMOMS) IN (" + ids + ") " + \
                     "OR '99' + REPLICATE('0', 8 - LEN(smtx.idWDMOMS)) + RTrim(smtx.idWDMOMS) IN (" + ids + ") " + \
                     "ORDER BY smtx.idWDMOMS"
        sqlIdsRotaOMS = "SELECT " + \
                        "eng.idWDMOMS AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status " + \
                        "FROM vw_smtx_map_coordinate_web as eng  " + \
                        "WHERE CONVERT(varchar(10), eng.idWDMOMS) IN (" + ids + ") " + \
                        "OR '99' + REPLICATE('0', 8 - LEN(eng.idWDMOMS)) + RTrim(eng.idWDMOMS) IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "eng.idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status " + \
                        "ORDER BY eng.idWDMOMS"
        idsRotaExcel = "select * from vw_smtx_excel_eild " + \
                       "where CONVERT(varchar(10), idWDMOMS) IN (" + ids + ") " + \
                       "OR '99' + REPLICATE('0', 8 - LEN(idWDMOMS)) + RTrim(idWDMOMS) IN (" + ids + ") "
    elif filtro == 'OTS':
        sqlIdsRota = "SELECT smtx.idWDMOTS AS idRota,  " + \
                     "CONCAT(smtx.SiteA,'-',smtx.UFA) AS SiteA, CONCAT(smtx.SiteB,'-',smtx.UFB) AS SiteB, " + \
                     "ROUND((((CAST(smtx.DistanciaReal AS float) * (0.005/1000) * 1.2) * 1000)), 2) AS Latencia " + \
                     "FROM vw_smtx_map_coordinate_web_ots as smtx " + \
                     "WHERE CONVERT(varchar(10), smtx.idWDMOTS) IN (" + ids + ") " + \
                     "OR smtx.ChaveOTS IN (" + ids + ") " + \
                     "OR smtx.Sigla IN (" + ids + ") " + \
                     "OR smtx.Sigla like ('%" + idsC.replace("'", "") + "%') " + \
                     "ORDER BY smtx.idWDMOTS"
        sqlIdsRotaOMS = "SELECT " + \
                        "eng.idWDMOTS AS idRota, " + \
                        "eng.idWDMOTS AS idWDMOMS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status " + \
                        "FROM vw_smtx_map_coordinate_web_ots as eng  " + \
                        "WHERE CONVERT(varchar(10), eng.idWDMOTS) IN (" + ids + ") " + \
                        "OR eng.ChaveOTS IN (" + ids + ") " + \
                        "OR eng.Sigla IN (" + ids + ") " + \
                        "OR eng.Sigla like ('%" + idsC.replace("'", "") + "%') " + \
                        "GROUP BY " + \
                        "eng.idWDMOTS, " + \
                        "eng.ReleaseHWA, " + \
                        "eng.FabricanteA, " + \
                        "eng.ReleaseHWB, " + \
                        "eng.FabricanteB, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status " + \
                        "ORDER BY eng.idWDMOTS"
        idsRotaExcel = "select *, " \
                       "ROUND((((CAST(DistanciaReal_OTS AS float) * (0.005/1000) * 1.2) * 1000)), 2) AS Latencia " \
                       "from vw_smtx_eild_ots " + \
                       "where CONVERT(varchar(10), idWDMOTS) IN (" + ids + ") " + \
                       "OR ChaveOTS IN (" + ids + ") " + \
                       "OR Sigla_OTS IN (" + ids + ") " + \
                       "OR Sigla like ('%" + idsC.replace("'", "") + "%') "
    else:
        pass

    idsRota = qry_db(sqlIdsRota, 'portaltx')
    idsRota = [dict(row) for row in idsRota]
    idsRotaOMS = qry_db(sqlIdsRotaOMS, 'portaltx')
    idsRotaOMS = [dict(row) for row in idsRotaOMS]
    idsRotaExcel = qry_db(idsRotaExcel, 'portaltx')
    idsRotaExcel = [dict(row) for row in idsRotaExcel]

    idsRotaFields = {}
    if len(idsRotaExcel) > 0:
        i = 0
        for key in idsRotaExcel[0].keys():
            idsRotaFields[i] = key
            i = i + 1

    response = {
        'idsRota': [dict(row) for row in idsRota],
        'idsRotaOMS': [dict(row) for row in idsRotaOMS],
        'idsRotaExcel': [dict(row) for row in idsRotaExcel],
        'idsRotaFields': idsRotaFields
    }

    return jsonify(response)
