from flask import Blueprint

from flask import url_for, render_template, redirect, jsonify, request
from flask_login import login_required, current_user
from flask_security import roles_accepted
from flask_pymongo import PyMongo
from flask_wtf import CsrfProtect

from itertools import groupby
from collections import Counter
import datetime
import copy

from models import qry_db, etp_uri, MongoAPI

# MongoDB RSNAC
etpDb = PyMongo()

etps_bp = Blueprint('etps', __name__)


@etps_bp.route('/etps-teste', methods=['GET'])
@login_required
@roles_accepted('etps')
def etps_teste():
    return render_template('etps_teste.html')


@etps_bp.route('/etps', methods=['GET'])
@login_required
@roles_accepted('etps')
def etps():
    obj = MongoAPI(etp_uri, 'supports')
    result = obj.collection.find_one({}, {'_id': 0})

    supports = {}
    dxm = {}
    kList = ['demand', 'motivator', 'hierarchy', 'fiber_owner', 'vendor', 'cnl']

    for k in kList:
        supports[k] = [i['k'] for i in list(result[k])]
        supports[k].sort()

    for d in result['demand']:
        dxm[d['k']] = d['l']
    supports['dxm'] = dxm

    supports['complemento'] = ['ID NOVA ROTA', 'CLUSTER METRO SPO', 'DADOS B2B', 'TEXTO LIVRE']

    return render_template('etps.html',
                           authedit='true' if current_user.has_role('etps_edit') else 'false',
                           supportsedit=supports)


@etps_bp.route('/ajax-etps', methods=['GET'])
@login_required
@roles_accepted('etps')
def ajax_etps():
    etps = request.args.get('etp')
    group = request.args.get('group')

    if group == 'etp':
        etps = etps.split(' ')
        while '' in etps: etps.remove('')
    else:
        etps = [etps]

    collection = 'resumes' if group == 'etp' else 'resumes_groups'

    execution_errors = []
    etps_result = {}

    smtx_oms_qry = """
        select 
        idWDMOMS, 
        convert(varchar(10), idWDMOMS) as idWDMOMStxt, 
        SiteA, 
        UFA, 
        EquipA, 
        LEFT(EquipA, 5) as EquipA2, 
        LatitudeA, 
        LongitudeA, 
        SiteB, 
        UFB, 
        EquipB, 
        LEFT(EquipB, 5) as EquipB2, 
        LatitudeB, 
        LongitudeB, 
        Status 
        from vw_smtx_map_coordinate_web 
    """
    data_smtx_oms = qry_db(smtx_oms_qry, 'portaltx')
    data_smtx_oms = [dict(row) for row in data_smtx_oms]

    for etp in etps:
        if len(etp) == 9 or etp in ['TransfOptica', 'NovasRotas', 'NovasCidades']:
            # obj_resumes = MongoAPI(etp_uri, 'resumes')
            obj_resumes = MongoAPI(etp_uri, collection)
            resume = obj_resumes.collection.find_one({'etp': etp}, {'_id': 0})

            if resume:
                obj_atributes = MongoAPI(etp_uri, 'atributes')
                atributes = obj_atributes.collection.find_one({'etp': etp}, {'_id': 0})

                data = resume['data']
                data['atributes'] = atributes
                data['data_smtx_eild_legado'] = getEtpDataLegado(atributes['checklist']) if atributes else []

                execution_etp = data['execution_etp']
                resumes, details = getEtpDataResumes(data, data_smtx_oms)
            else:
                data = getEtpData(etp)
                execution_etp = data['execution_etp']
                resumes, details = getEtpDataResumes(data, data_smtx_oms)
                del data['atributes']
                del data['data_smtx_eild_legado']
                obj_resumes.collection.update_one({'etp': etp}, {'$set': {'data': data, 'update': datetime.datetime.now()}},
                                                  upsert=True)

            if group != 'etp':
                details['data_etps_infos'] = data['data_etps_infos']


            # ADICIONAIS
            details['adicionais'] = {}
            obj_adicionais = MongoAPI(etp_uri, 'adicionais')
            adicionais = obj_adicionais.collection.find_one({'etp': etp}, {'_id': 0})
            if adicionais:
                details['adicionais']['etps_predecessoras'] = adicionais['etps_predecessoras']
                details['adicionais']['oes_predecessoras'] = adicionais['oes_predecessoras']
            else:
                details['adicionais']['etps_predecessoras'] = []
                details['adicionais']['oes_predecessoras'] = []

            # if resumes['ETP']['search']:
            etps_result[etp] = {
                'resumes': resumes,
                'details': details
            }
            execution_errors.append(execution_etp)

    response = {
        'etps_result': etps_result,
        'NEW_VALIDATION': current_user.has_role('etps_edit'),
        'errors': execution_errors
    }

    return jsonify(response)


@etps_bp.route('/ajax-etp-status', methods=['GET'])
@login_required
@roles_accepted('etps')
def ajax_etp_status():
    status = request.args.get('status')

    # OPEN SYMMETRIC KEY SymKey_SSI_CONS  DECRYPTION BY CERTIFICATE Certificado_SSI_CONS WITH PASSWORD = 'TguevwLh3ee#';
    qry = """
        
        SELECT 
        CASE 
        WHEN CHARINDEX('0040-', REFERENCIA)>0 THEN SUBSTRING(REFERENCIA, CHARINDEX('0040-', REFERENCIA), 9)  
        WHEN CHARINDEX('0045-', REFERENCIA)>0 THEN SUBSTRING(REFERENCIA, CHARINDEX('0045-', REFERENCIA), 9) 
        WHEN CHARINDEX('0050-', REFERENCIA)>0 THEN SUBSTRING(REFERENCIA, CHARINDEX('0050-', REFERENCIA), 9) 
        WHEN CHARINDEX('0040-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0040-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9)  
        WHEN CHARINDEX('0045-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0045-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9) 
        WHEN CHARINDEX('0050-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0050-', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9) 
        WHEN CHARINDEX('0040.', REFERENCIA)>0 THEN REPLACE(SUBSTRING(REFERENCIA, CHARINDEX('0040.', REFERENCIA), 9), '.', '-')  
        WHEN CHARINDEX('0045.', REFERENCIA)>0 THEN REPLACE(SUBSTRING(REFERENCIA, CHARINDEX('0045.', REFERENCIA), 9), '.', '-')   
        WHEN CHARINDEX('0050.', REFERENCIA)>0 THEN REPLACE(SUBSTRING(REFERENCIA, CHARINDEX('0050.', REFERENCIA), 9), '.', '-')  
        WHEN CHARINDEX('0040.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN REPLACE(SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0040.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9), '.', '-')  
        WHEN CHARINDEX('0045.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN REPLACE(SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0045.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9), '.', '-')  
        WHEN CHARINDEX('0050.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)))>0 THEN REPLACE(SUBSTRING(CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20)), CHARINDEX('0050.', CAST(DECRYPTBYKEY(OBJETIVO) as varchar(20))), 9), '.', '-')  
        END AS ETP, 
        SP_FSP, 
        UFS, 
        RESPONSAVEL_TECNICO 
        FROM BBTX_PEDS_ENVIADAS """

    if status == 'imp':
        qry = qry + "WHERE DESC_STATUS IN ('Aguardando PED Projeto', 'Aguardando Preparo da Instrução', 'Análise de Viabilidade', 'Análise Técnica') AND "
        statusTitle = 'Em Implantação'
    elif status == 'oper':
        qry = qry + "WHERE DESC_STATUS IN ('Aguardando Associada') AND "
        statusTitle = 'Em O&M'

    qry = qry + """
        ID_AREA_REQUISITADA IN (501, 1125, 1130, 488) AND 
        (CHARINDEX('0040-', REFERENCIA)+CHARINDEX('0040-', OBJETIVO)>0 OR 
        CHARINDEX('0045-', REFERENCIA)+CHARINDEX('0045-', OBJETIVO)>0 OR 
        CHARINDEX('0050-', REFERENCIA)+CHARINDEX('0050-', OBJETIVO)>0 OR 
        CHARINDEX('0040.', REFERENCIA)+CHARINDEX('0040.', OBJETIVO)>0 OR 
        CHARINDEX('0045.', REFERENCIA)+CHARINDEX('0045.', OBJETIVO)>0 OR 
        CHARINDEX('0050.', REFERENCIA)+CHARINDEX('0050.', OBJETIVO)>0) 
        ORDER BY SP_FSP
    """

    data = qry_db(qry, 'ssi')
    data = [dict(row) for row in data]

    response = {
        'result': data,
        'title': statusTitle
    }

    return jsonify(response)


@etps_bp.route('/ajax-etp-checklist', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_etp_checklist():
    obj = MongoAPI(etp_uri, 'atributes')
    checklist = obj.collection.find_one({'etp': request.args.get('etp')}, {'_id': 0, 'checklist': 1})
    checklist = checklist['checklist']

    fields = ['cadastro', 'ped_infra', 'ped_re', 'ped_dcn', 'topologia']
    for i in fields:
        next(item for item in checklist if item["k"] == i)['v'] = request.args.get(i)

    next(item for item in checklist if item["k"] == 'ped_demanda')['v'] = request.args.get('ped_demanda').split('_')
    next(item for item in checklist if item["k"] == 'eild_legado')['v'] = request.args.get('eild_legado').split('_')
    next(item for item in checklist if item["k"] == 'site_science')['v'] = request.args.get('site_science').split('_')
    next(item for item in checklist if item["k"] == 'ots_desativa')['v'] = request.args.get('ots_desativa').split('_')

    next(item for item in checklist if item["k"] == 'comissiona_gbe')['v'] = list(filter(lambda x: x != '', request.args.get('comissiona_gbe').split('\n')))
    next(item for item in checklist if item["k"] == 'descomissiona_gbe')['v'] = list(filter(lambda x: x != '', request.args.get('descomissiona_gbe').split('\n')))
    next(item for item in checklist if item["k"] == 'comissiona_portadora')['v'] = list(filter(lambda x: x != '', request.args.get('comissiona_portadora').split('\n')))
    next(item for item in checklist if item["k"] == 'descomissiona_portadora')['v'] = list(filter(lambda x: x != '', request.args.get('descomissiona_portadora').split('\n')))

    obj.collection.update_one({'etp': request.args.get('etp')}, {'$set': {'checklist': checklist}})
    response = {
        'checklist': checklist
    }
    return jsonify(response)


@etps_bp.route('/ajax-etp-atributos', methods=['GET', 'POST'])
@login_required
@roles_accepted('etps_edit')
def ajax_etp_atributos():
    obj = MongoAPI(etp_uri, 'atributes')
    etp = obj.collection.find_one({'etp': request.form['etp']}, {'_id': 0})

    objSupports = MongoAPI(etp_uri, 'supports')
    supports = objSupports.collection.find_one({}, {'_id': 0})

    if not etp['cancelamento']:
        predecessoras = [] if request.form['predecessoras'].replace(' ', '') == '' else request.form[
            'predecessoras'].replace(' ', '').split(',')

        hierarquia = etp['hierarquia'] if etp['tipoEtp'] == 'Demanda' else [[item['k'], item['v']] for t in
                                                                            request.form['hierarquia'].split('_')
                                                                            for item in supports['hierarchy'] if
                                                                            item['k'] == t]
        prop_fibra = etp['prop_fibra'] if etp['tipoEtp'] == 'Demanda' else [[item['k'], item['v']] for t in
                                                                            request.form['prop_fibra'].split('_')
                                                                            for item in supports['fiber_owner'] if
                                                                            item['k'] == t]

        atributes = {
            'hierarquia': hierarquia,
            'prop_fibra': prop_fibra,
            'vendor': [[item['k'], item['v']] for t in request.form['vendor'].split('_') for item in
                       supports['vendor'] if item['k'] == t],
            'municipio_a': next([item['k'], item['v']] for item in supports['cnl'] if
                                item['k'] == request.form['municipio_a']) if len(
                request.form['municipio_a']) > 0 else [],
            'municipio_b': next([item['k'], item['v']] for item in supports['cnl'] if
                                item['k'] == request.form['municipio_b']) if len(
                request.form['municipio_b']) > 0 else [],
            'complemento': [request.form['complemento_tipo'], request.form['complemento_texto']] if len(
                request.form['complemento_tipo']) > 0 else [],

            'emissao': etp['emissao'] if request.form['muda_emissao'] == 'false' else etp['emissao'] + 1,
            'descricao_macro': request.form['descricao_macro'],
            'objetivo': request.form['objetivo'],
            'justificativa': request.form['justificativa'],
            'predecessoras': predecessoras,
            'escopo': request.form['escopo'],
            'premissas': request.form['premissas'],
            'restricoes': request.form['restricoes'],
            'fatores_criticos': request.form['fatores_criticos'],
            'topologia_type': request.form['topologia_type'],
            'topologia_file': request.form['topologia_file'],
            'cancelamento': bool(0 if request.form['cancelamento'] == 'false' else 1),
            'status': etp['status'] if request.form['cancelamento'] == 'false' else 'Cancelada'
        }

        atributes['titulo'] = next(item['v'] for item in supports['nomenclature'] if item['k'] == next(
            item['v'] for item in supports['types'] if item['k'] == etp['tipoEtp'])).format(
            etp['etp'],
            atributes['emissao'],
            etp['elaborador'][1],
            etp['demanda'][1],
            etp['motivador'][1],
            '_'.join([i[1] for i in atributes['hierarquia']]),
            '_'.join([i[1] for i in atributes['prop_fibra']]),
            '_'.join([i[1] for i in atributes['vendor']]),
            str(etp['ano'])[2:],
            atributes['municipio_a'][1])

        if len(atributes['municipio_b']) > 0:
            atributes['titulo'] = atributes['titulo'] + '-' + atributes['municipio_b'][1]
        if len(atributes['complemento']) > 0:
            atributes['titulo'] = atributes['titulo'] + '-' + atributes['complemento'][1].upper().replace(' ', '_')

        changes = {
            'date': datetime.datetime.now(),
            'id': current_user.id,
            'name': current_user.name,
            'changes': []
        }
        for atrKey in list(atributes.keys()):
            if (atrKey not in etp and len(atributes[atrKey]) > 0 and atributes[atrKey] != 'null') or (
                    atrKey in etp and etp[atrKey] != atributes[atrKey]):
                change = {
                    'field': atrKey,
                    'from': etp[atrKey] if atrKey in etp else '',
                    'to': atributes[atrKey]
                }
                changes['changes'].append(change)
        atributes['changes_control'] = etp['changes_control']
        if len(changes['changes']) > 0:
            atributes['changes_control'].append(changes)

        obj.collection.update_one({'etp': request.form['etp']}, {'$set': atributes})

    atributes = obj.collection.find_one({'etp': request.form['etp']}, {'_id': 0})

    response = {
        'atributes': atributes
    }
    return jsonify(response)


@etps_bp.route('/ajax-etp-new-start', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_etp_new_start():
    obj = MongoAPI(etp_uri, 'supports')
    result = obj.collection.find_one({}, {'_id': 0})

    supports = {}
    dxm = {}
    kList = ['types', 'names', 'demand', 'motivator', 'hierarchy', 'fiber_owner', 'vendor', 'cnl']

    for k in kList:
        supports[k] = [i['k'] for i in list(result[k])]
        supports[k].sort()

    for d in result['demand']:
        if len(d['l']) > 0:
            dxm[d['k']] = d['l']
        else:
            dxm[d['k']] = supports['fiber_owner']
    for d in list(dxm.keys()):
        dxm[d].sort()
    supports['dxm'] = dxm

    supports['nameOK'] = current_user.name in supports['names']
    supports['nameUser'] = current_user.name
    supports['year'] = int(datetime.datetime.now().strftime("%Y"))

    response = {
        'supports': supports
    }
    return jsonify(response)


@etps_bp.route('/ajax-etp-new', methods=['GET', 'POST'])
@login_required
@roles_accepted('etps_edit')
def ajax_etp_new():
    objSupports = MongoAPI(etp_uri, 'supports')
    objEtp = MongoAPI(etp_uri, 'atributes')

    supports = objSupports.collection.find_one({}, {'_id': 0})

    hierarquia = [['', '']] if request.form['TipoNewEtp'] == 'Demanda' else [[item['k'], item['v']] for t in
                                                                             request.form[
                                                                                 'HierarquiaNewEtp'].split('_') for
                                                                             item in supports['hierarchy'] if
                                                                             item['k'] == t]
    prop_fibra = [['', '']] if request.form['TipoNewEtp'] == 'Demanda' else [[item['k'], item['v']] for t in
                                                                             request.form[
                                                                                 'PropFibraNewEtp'].split('_') for
                                                                             item in supports['fiber_owner'] if
                                                                             item['k'] == t]

    elaboradorNome = current_user.name if (
            current_user.name in [i['k'] for i in supports['names']]) else request.form['ElaboradorNewEtp']
    motivadorBusca = 'motivator' if len(next(item['l'] for item in supports['demand'] if item['k'] == request.form['DemandaNewEtp']))>0 else 'fiber_owner'

    newEtp = {
        'etp': next(
            item['v'] + '-' + item['n'] for item in supports['types'] if item['k'] == request.form['TipoNewEtp']),
        'tipoEtp': request.form['TipoNewEtp'],
        'emissao': 1,
        'data_emissao': datetime.datetime.now(),
        'elaborador': next([item['k'], item['v']] for item in supports['names'] if item['k'] == elaboradorNome),
        'ano': int(request.form['AnoNewEtp']),
        'demanda': next(
            [item['k'], item['v']] for item in supports['demand'] if item['k'] == request.form['DemandaNewEtp']),
        'motivador': next([item['k'], item['v']] for item in supports[motivadorBusca] if
                          item['k'] == request.form['MotivadorNewEtp']),
        'hierarquia': hierarquia,
        'prop_fibra': prop_fibra,
        'vendor': [[item['k'], item['v']] for t in request.form['VendorNewEtp'].split('_') for item in
                   supports['vendor'] if item['k'] == t],

        'municipio_a': next(
            [item['k'], item['v']] for item in supports['cnl'] if item['k'] == request.form['MunANewEtp']) if len(
            request.form['MunANewEtp']) > 0 else [],
        'municipio_b': next(
            [item['k'], item['v']] for item in supports['cnl'] if item['k'] == request.form['MunBNewEtp']) if len(
            request.form['MunBNewEtp']) > 0 else [],
        'complemento': [request.form['ComplementoTipoNewEtp'], request.form['ComplementoTextoNewEtp']] if len(
            request.form['ComplementoTipoNewEtp']) > 0 else [],

        'cancelamento': bool(0),
        'status': 'Em Engenharia',
        'checklist': [
            {'k': 'cadastro', 'l': 'Cadastro TX', 'v': 'NOK'},
            {'k': 'ped_infra', 'l': 'SSIPED INFRA', 'v': 'NOK'},
            {'k': 'ped_re', 'l': 'SSIPED RE', 'v': 'NOK'},
            {'k': 'ped_dcn', 'l': 'SSIPED DCN', 'v': 'NOK'},
            {'k': 'ped_demanda', 'l': 'SSIPED DEMANDA', 'v': []},
            {'k': 'topologia', 'l': 'Topologia', 'v': 'NOK'},
            {'k': 'eild_legado', 'l': 'EILD(s) Legado(s)', 'v': []},
            {'k': 'site_science', 'l': 'Sites Science', 'v': []},
            {'k': 'ots_desativa', 'l': 'OTS(s) a desativar', 'v': []},
            {'k': 'comissiona_gbe', 'l': 'Comissionar GBE', 'v': []},
            {'k': 'descomissiona_gbe', 'l': 'Descomissionar GBE', 'v': []},
            {'k': 'comissiona_portadora', 'l': 'Comissionar Portadora', 'v': []},
            {'k': 'descomissiona_portadora', 'l': 'Descomissionar Portadora', 'v': []},
        ],
        'changes_control': [
            {
                'date': datetime.datetime.now(),
                'id': current_user.id,
                'name': current_user.name,
                'changes': [
                    {
                        'field': 'Todos',
                        'from': '',
                        'to': ''
                    }
                ]
            }
        ]
    }

    type_index = next(item for item in range(len(supports['types'])) if
                      supports['types'][item]['k'] == request.form['TipoNewEtp'])
    supports['types'][type_index]['n'] = str(int(supports['types'][type_index]['n']) + 1).zfill(4)

    newEtp['titulo'] = next(item['v'] for item in supports['nomenclature'] if item['k'] == next(
        item['v'] for item in supports['types'] if item['k'] == request.form['TipoNewEtp'])).format(
        newEtp['etp'],
        newEtp['emissao'],
        newEtp['elaborador'][1],
        newEtp['demanda'][1],
        newEtp['motivador'][1],
        '_'.join([i[1] for i in newEtp['hierarquia']]),
        '_'.join([i[1] for i in newEtp['prop_fibra']]),
        '_'.join([i[1] for i in newEtp['vendor']]),
        str(newEtp['ano'])[2:],
        newEtp['municipio_a'][1])

    if len(newEtp['municipio_b']) > 0:
        newEtp['titulo'] = newEtp['titulo'] + '-' + newEtp['municipio_b'][1]
    if len(newEtp['complemento']) > 0:
        newEtp['titulo'] = newEtp['titulo'] + '-' + newEtp['complemento'][1].upper().replace(' ', '_')

    objSupports.collection.replace_one({}, supports, upsert=True)
    objEtp.collection.insert(newEtp)

    response = {
        'etp': newEtp['etp']
    }
    return jsonify(response)


@etps_bp.route('/ajax-ped-demanda', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_ped_demanda():
    qry_ssiped_demanda = qry_demanda(request.args.get('ped'))

    data_ssiped_demanda = qry_db(qry_ssiped_demanda, 'ssi')
    data_ssiped_demanda = [dict(row) for row in data_ssiped_demanda]

    response = {
        'ped_demanda': data_ssiped_demanda
    }
    return jsonify(response)


@etps_bp.route('/ajax-site-science', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_site_science():
    qry_site = qry_site_science(request.args.get('site'), request.args.get('site'), 'M')

    data_site = qry_db(qry_site, 'portaltx')
    data_site = [dict(row) for row in data_site]

    response = {
        'site': data_site
    }
    return jsonify(response)


@etps_bp.route('/ajax-ots-desativar', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_ots_desativar():
    qry_sigla = "select ChaveOTS from smtx_ots where CONVERT(varchar(10),idWDMOTS) = '"+request.args.get('ots')+"' or ChaveOTS = '"+request.args.get('ots')+"'"

    ots_sigla = qry_db(qry_sigla, 'portaltx')
    ots_sigla = [dict(row) for row in ots_sigla]

    response = {
        'ots_sigla': ots_sigla
    }
    return jsonify(response)


@etps_bp.route('/ajax-eild-legado', methods=['GET'])
@login_required
@roles_accepted('etps_edit')
def ajax_eild_legado():
    qry_eild_legado = qry_legado(request.args.get('eild'))

    data_eild_legado = qry_db(qry_eild_legado, 'portaltx')
    data_eild_legado = [dict(row) for row in data_eild_legado]

    response = {
        'eild_legado': data_eild_legado
    }
    return jsonify(response)


@etps_bp.route('/ajax-list-etps', methods=['GET'])
@login_required
@roles_accepted('etps')
def ajax_list_etps():
    ##### ATRIBUTES #######################
    obj = MongoAPI(etp_uri, 'list')
    etps = obj.collection.find({}, {'_id': 0})
    etps = [dict(row) for row in etps]

    response = {
        'etpsOnLine': etps
    }
    return jsonify(response)


@etps_bp.route('/ajax-refresh-etp', methods=['GET', 'POST'])
@login_required
@roles_accepted('etps_edit')
def ajax_refresh_etp():
    etp = request.args.get('etp')
    obj = MongoAPI(etp_uri, 'resumes')
    obj.collection.delete_one({'etp': etp})

    response = {
        'etp': etp
    }
    return jsonify(response)


@etps_bp.route('/ajax-etp-update-ots', methods=['GET', 'POST'])
@login_required
@roles_accepted('etps_edit')
def ajax_etp_update_ots():
    etp = request.args.get('etp')
    otss = request.args.get('otss')
    otss = otss.split('#')

    for ots in otss:
        ots = ots.split('|')
        sots = qry_db('select idWDMOTS from smtx_eng_ots where idWDMOTS = {0}'.format(ots[0]), 'portaltx')
        sots = [dict(row) for row in sots]
        if len(sots)>0:
            qry_db("update smtx_eng_ots set PropriedadeFibra = '{0}' where idWDMOTS = {1}".format(ots[1], ots[0]), 'portaltx')
        else:
            qry = """
            insert into smtx_eng_ots 
            (idWDMOTS, PropriedadeFibra, NomeRota, NomeRotaNovo) 
            values 
            ({0}, '{1}', '', '')
            """.format(int(ots[0]), ots[1])
            qry_db(qry, 'portaltx')

    obj = MongoAPI(etp_uri, 'resumes')
    obj.collection.delete_one({'etp': etp})

    response = {
        'etp': etp
    }
    return jsonify(response)


def createQuerys(f):
    smtx_oms = """
        select 
        idWDMOMS, 
        convert(varchar(10), idWDMOMS) as idWDMOMStxt, 
        SiteA, 
        UFA, 
        EquipA, 
        LEFT(EquipA, 5) as EquipA2, 
        LatitudeA, 
        LongitudeA, 
        SiteB, 
        UFB, 
        EquipB, 
        LEFT(EquipB, 5) as EquipB2, 
        LatitudeB, 
        LongitudeB, 
        Status 
        from vw_smtx_map_coordinate_web 
    """
    smtx_oe_oms = """
        select 
        '99' + REPLICATE('0', 8 - LEN(id)) + RTrim(id) AS id, 
        TipoElemento, 
        numOE, 
        TipoOE, 
        Status, 
        Descricao, 
        id as idsWDMOMS, 
        '' as SiteA, 
        '' as SiteB 
        from smtx_oe_elemento 
        where TipoElemento = 'OMS'  and 
        Descricao like '%{0}%'""".format(f)

    smtx_oe_och = """
        select 
        '99' + REPLICATE('0', 8 - LEN(och.idWDMOCH)) + RTrim(och.idWDMOCH) AS id, 
        oe.TipoElemento, 
        och.ochVelocidade as Velocidade, 
        oe.numOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        SUBSTRING((SELECT ',' + convert(varchar(10), oms.idWDMOMS) AS [text()] 
        FROM smtx_och as oms 
        where oms.idWDMOCH = och.idWDMOCH 
        order by oms.idWDMOMS 
        FOR XML PATH ('')), 2, 8000) AS idsWDMOMS, 
        och.ochSiteA as SiteA, 
        och.ochSiteB as SiteB 
        from smtx_och as och RIGHT JOIN smtx_oe_elemento as oe 
        ON och.idWDMOCH = oe.id 
        where oe.TipoElemento = 'OCH' and och.idWDMOCH is not null and oe.Descricao like '%{0}%' 
        group by 
        och.idWDMOCH, 
        oe.TipoElemento, 
        och.ochVelocidade, 
        oe.numOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        och.ochSiteA, 
        och.ochSiteB 
        order by idWDMOCH""".format(f)

    smtx_oe_odu = """
        select 
        '99' + REPLICATE('0', 8 - LEN(odu.idWDMODU)) + RTrim(odu.idWDMODU) AS id, 
        oe.TipoElemento, 
        oe.numOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        SUBSTRING((SELECT ',' + convert(varchar(10), oms.idWDMOMS) AS [text()] 
        FROM vw_smtx_excel_odu as oms 
        where oms.idWDMODU = odu.idWDMODU 
        order by oms.idWDMOMS 
        FOR XML PATH ('')), 2, 8000) AS idsWDMOMS, 
        odu.oduSiteA as SiteA, 
        odu.oduSiteB as SiteB 
        from vw_smtx_excel_odu as odu RIGHT JOIN smtx_oe_elemento as oe ON odu.idWDMODU = oe.id 
        where oe.TipoElemento = 'ODU' and odu.idWDMODU is not null and oe.Descricao like '%{0}%' 
        group by 
        odu.idWDMODU, 
        oe.TipoElemento, 
        oe.numOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        odu.oduSiteA, 
        odu.oduSiteB 
        order by idWDMODU""".format(f)

    smtx_oe_circuito = """
        SELECT 
        eild.NumEILD AS id, 
        eild.VelocidadeMeio as Velocidade, 
        'EILD' AS TipoElemento, 
        oe.NumOE AS numOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        SUBSTRING((SELECT ',' + convert(varchar(10), oms.idWDMOMS) AS [text()] 
        FROM vw_smtx_excel_eild as oms 
        where oms.idRota = eild.idRota 
        order by oms.idWDMOMS 
        FOR XML PATH ('')), 2, 8000) AS idsWDMOMS, 
        eild.rotaSiteA AS SiteA, 
        eild.rotaSiteB AS SiteB, 
        CASE eild.L0 
        WHEN '-' THEN 'N' 
        WHEN 'Parcial' THEN 'L0-P' 
        WHEN 'Total' THEN 'L0-T' 
        ELSE 'N' 
        END AS L0, 
        CASE 
        WHEN eild_equip.AgrupEquipInicAcesso is null THEN 'Z' 
        ELSE eild_equip.AgrupEquipInicAcesso 
        END AS Rota, 
        eild_equip.SiglaEquipInicAcesso AS EquipamentoI, 
        eild_equip.IntEquipInicAcesso AS InterfaceI, 
        eild_equip.SiglaEquipFimAcesso AS EquipamentoF, 
        eild_equip.IntEquipFimAcesso AS InterfaceF, 
        eild_pos.siglaA, 
		eild_pos.shelfA, 
		eild_pos.slotA, 
		eild_pos.portaA, 
		eild_pos.siglaB, 
		eild_pos.shelfB, 
		eild_pos.slotB, 
		eild_pos.portaB, 
        eild_pos.dgoTxA, 
        eild_pos.dgoRxA, 
        eild_pos.dgoTxB, 
        eild_pos.dgoRxB 
        FROM smtx_oe AS oe INNER JOIN smtx_eild AS eild ON oe.NumOE = eild.NumOE 
        INNER JOIN vw_smtx_excel_eild as eild_oms ON eild.idRota = eild_oms.idRota 
        INNER JOIN smtx_idrota_equipamentos as eild_equip ON eild.idRota = eild_equip.idRota 
		LEFT JOIN smtx_idrota_posicoes as eild_pos ON (eild.idRota = eild_pos.idRota and eild.NumOE = eild_pos.NumOE) 
        where oe.TipoOE = 'Circuito' and eild.idRota is not null and oe.Descricao like '%{0}%' 
        group by 
        eild.NumEILD,  
        eild.VelocidadeMeio, 
        eild.idRota, 
        oe.NumOE, 
        oe.TipoOE, 
        oe.Status, 
        oe.Descricao, 
        eild.rotaSiteA, 
        eild.rotaSiteB, 
        eild.L0, 
        eild_equip.SiglaEquipInicAcesso, 
        eild_equip.IntEquipInicAcesso, 
        eild_equip.AgrupEquipInicAcesso, 
        eild_equip.SiglaEquipFimAcesso, 
        eild_equip.IntEquipFimAcesso, 
        eild_pos.siglaA, 
		eild_pos.shelfA, 
		eild_pos.slotA, 
		eild_pos.portaA, 
		eild_pos.siglaB, 
		eild_pos.shelfB, 
		eild_pos.slotB, 
		eild_pos.portaB, 
        eild_pos.dgoTxA, 
        eild_pos.dgoRxA, 
        eild_pos.dgoTxB, 
        eild_pos.dgoRxB 
        order by eild.idRota""".format(f)

    smtx_oe_elemento = """
        select 
        Nome as id, 
        TipoEquip as TipoElemento, 
        NumOE as numOE, 
        TipoOE, 
        Status, 
        Descricao, 
        'N/A' as idsWDMOMS 
        from smtx_equip_oe 
        where Descricao like '%{0}%' 
        order by Nome, NumOE""".format(f)

    # OPEN SYMMETRIC KEY SymKey_SSI_CONS  DECRYPTION BY CERTIFICATE Certificado_SSI_CONS WITH PASSWORD = 'TguevwLh3ee#';
    ssiped = """ 
        
        SELECT 
        ID_PED,
        NUMERO_SSI_PED AS PED, 
        SSI_ASSOCIADA AS PED_ASSOCIADA, 
        ANO, 
        SP_FSP, 
        UFS, 
        MOTIVACAO, 
        PRIORIDADE, 
        DESC_STATUS AS STATUS, 
        REFERENCIA, 
        APLICACAO, 
        NOME_AMIG_AREA_REQUISITANTE AS REQUISITANTE, 
        DESCRICAO_AREA_SOLICITANTE AS SOLICITANTE, 
        DESCRICAO_REQUISITADA AS REQUISITADO, 
        DATA_CRIACAO, 
        CONCLUSAO, 
        RESPONSAVEL_TECNICO, 
        DESC_STATUS AS STATUS_SSI, 
        CASE DESC_STATUS 
        WHEN 'Aguardando Associada' THEN 'Associada' 
        WHEN 'Aguardando PED Projeto' THEN 'Em Análise' 
        WHEN 'Aguardando Preparo da Instrução' THEN 'Em Análise' 
        WHEN 'Análise de Viabilidade' THEN 'Em Análise' 
        WHEN 'Análise Técnica' THEN 'Em Análise' 
        WHEN 'Cancelada' THEN 'Cancelada' 
        WHEN 'Concluída - Avaliação Final Realizada' THEN 'Concluída' 
        WHEN 'Concluída - Finalizada Com Sucesso' THEN 'Concluída' 
        WHEN 'Concluída - Finalizada Parcialmente' THEN 'Concluída' 
        WHEN 'Concluída - Finalizada Sem Sucesso' THEN 'Concluída' 
        WHEN 'Concluída Parcialmente' THEN 'Concluída' 
        WHEN 'Concluída Sem Sucesso' THEN 'Concluída' 
        WHEN 'Execução' THEN 'Em Execução' 
        WHEN 'Revisão pelo Emissor' THEN 'Devolvida'
        WHEN 'SSI Concluída' THEN 'Concluída' 
        ELSE 'Outros' 
        END AS LabelStatus, 
        CASE ID_AREA_REQUISITADA 
        WHEN 1062 THEN 'Eng. Infr. CORE' 
        WHEN 977 THEN 'Outros' 
        WHEN 835 THEN 'Outros' 
        WHEN 921 THEN 'Outros' 
        WHEN 832 THEN 'Outros' 
        WHEN 826 THEN 'Outros' 
        WHEN 871 THEN 'Outros' 
        WHEN 925 THEN 'Outros' 
        WHEN 926 THEN 'Outros' 
        WHEN 1130 THEN 'Impl. LAN/DCN/Segurança' 
        WHEN 1218 THEN 'Impl. METRO SP' 
        WHEN 398 THEN 'Oper. Banda Larga' 
        WHEN 690 THEN 'Eng. Infr. CORE' 
        WHEN 1274 THEN 'Eng. CORE' 
        WHEN 1275 THEN 'Eng. CORE' 
        WHEN 1063 THEN 'Eng. CORE' 
        WHEN 814 THEN 'Eng. METRO CO/NO/NE' 
        WHEN 465 THEN 'Eng. METRO NE' 
        WHEN 779 THEN 'Eng. METRO NO' 
        WHEN 674 THEN 'Eng. BACKBONE TX' 
        WHEN 477 THEN 'Eng. BACKBONE IP' 
        WHEN 476 THEN 'Eng. LAN/DCN/Segurança' 
        WHEN 1039 THEN 'Eng. de Rede Externa' 
        WHEN 1228 THEN 'Eng. de Rede Externa FSP' 
        WHEN 1227 THEN 'Eng. de Rede Externa SP' 
        WHEN 1043 THEN 'Impl. BACKBONE IP' 
        WHEN 1125 THEN 'Impl. BACKBONE IP' 
        WHEN 1266 THEN 'Outros' 
        WHEN 1107 THEN 'Plan. Infr.' 
        WHEN 1269 THEN 'Plan. LAN/DCN/Segurança' 
        WHEN 488 THEN 'Impl. BACKBONE TX' 
        WHEN 503 THEN 'Outros' 
        WHEN 795 THEN 'Suporte SSI' 
        WHEN 800 THEN 'Suporte SSI' 
        WHEN 798 THEN 'Suporte SSI' 
        WHEN 797 THEN 'Suporte SSI' 
        WHEN 794 THEN 'Suporte SSI' 
        WHEN 806 THEN 'Suporte SSI' 
        WHEN 501 THEN 'TI OSS' 
        WHEN 652 THEN 'TI OSS' 
        WHEN 2397 THEN 'Infraestrutura' 
        ELSE 'Outros' 
        END AS LabelRequisitada, 
        OBJETIVO 
        FROM BBTX_PEDS_ENVIADAS 
        WHERE REFERENCIA like '%{0}%' or 
        OBJETIVO LIKE '%{1}%' 
        ORDER BY LabelRequisitada, ID_PED""".format(f, f)

    cpomT2 = """SELECT 
        *, 
        CASE 
        WHEN Fornecedor like '%HUAWEI%' THEN 'HUAWEI' 
        WHEN Fornecedor like '%INFINERA%' THEN 'INFINERA' 
        WHEN Fornecedor like '%NOKIA%' THEN 'NOKIA' 
        WHEN Fornecedor like '%ERICSSON%' THEN 'NOKIA' 
        WHEN Fornecedor like '%ALCATEL%' THEN 'NOKIA' 
        WHEN Fornecedor like '%LUCENT%' THEN 'NOKIA' 
        WHEN Fornecedor like '%PADTEC%' THEN 'PADTEC' 
        WHEN Fornecedor like '%SIAE%' THEN 'SIAE' 
        WHEN Fornecedor like '%ZTE DO BRASIL%' THEN 'ZTE' 
        WHEN Fornecedor like '%CERAGON%' THEN 'CERAGON' 
        WHEN Fornecedor like '%CIENA%' THEN 'CIENA' 
        WHEN Fornecedor like '%CORIANT%' THEN 'CORIANT' 
        WHEN Fornecedor like '%ICOMON%' THEN 'ICOMON' 
        WHEN Fornecedor like '%NEC LATIN%' THEN 'NEC' 
        WHEN Fornecedor like '%NESIC%' THEN 'NESIC' 
        WHEN Fornecedor like '%PROLINK%' THEN 'PROLINK' 
        WHEN Fornecedor like '%PROMON%' THEN 'PROMON' 
        WHEN Fornecedor like '%TEL TELEC%' THEN 'TEL' 
        ELSE Fornecedor
        END AS FornecedorLabel 
        FROM T2 
        WHERE T2.Escopo LIKE '%{0}%' 
        ORDER BY Status, T2""".format(f)

    cpomPC = "SELECT *, convert(varchar, DataCriacao, 103) AS DataPc from Pedidos WHERE Escopo LIKE '%{0}%'".format(f)

    cpomITEM = "SELECT * from Item WHERE Escopo like '%{0}%' order by Site, IdT2".format(f)

    pmts = """
        SELECT 
        TOP 1 
        ETP, 
        STATUS, 
        OBS 
        FROM etp_pmts 
        WHERE ETP LIKE '%{0}%'""".format(f)

    smtx_oe_desativacao = """SELECT *, 
     '' as id, '' as SiteA, '' as SiteB, '' as idsWDMOMS 
     FROM smtx_oe_desat WHERE Descricao like '%{0}%' order by NumOE""".format(f)

    return smtx_oms, smtx_oe_oms, smtx_oe_och, smtx_oe_odu, smtx_oe_circuito, smtx_oe_elemento, ssiped, cpomT2, cpomPC, cpomITEM, pmts, smtx_oe_desativacao


def createCpomData(t2s, pcs):
    cpom = []
    for t2 in t2s:
        t2pc = list(filter(lambda x: x['IdT2'] == t2['T2'], pcs))
        t2['Pedidos'] = t2pc
        cpom.insert(len(cpom), t2)
    return cpom


def resume(data, keyName, groupName, groupNameOrig, keysOK):
    INFO = sorted(data, key=lambda i: i[keyName])
    resume = []

    for key, value in groupby(INFO, lambda i: i[keyName]):
        value_copy = list(value)
        status = Counter(s[groupName] for s in value_copy)
        statusOrig = [so[groupNameOrig] for so in value_copy]
        if 'Cancelada' in statusOrig and len(statusOrig) > 1:
            statusOrig.remove('Cancelada')

        concluido = 0
        for i in status:
            if i in keysOK:
                concluido += status[i]

        item = {
            'id': key,
            'qtd': sum(status.values()),
            'status': dict(status),
            'resultado': True if sum(status.values()) == concluido else False,
            'status_orig': statusOrig[-1]
        }
        resume.insert(len(resume), item)

    return resume


def qry_associada(ped_associada):
    # OPEN SYMMETRIC KEY SymKey_SSI_CONS  DECRYPTION BY CERTIFICATE Certificado_SSI_CONS WITH PASSWORD = 'TguevwLh3ee#';
    qry = """
        
        SELECT 
        ID_PED, 
        NUMERO_SSI_PED AS PED, 
        CASE ID_AREA_REQUISITADA 
        WHEN 1062 THEN 'Eng. Infr. CORE' 
        WHEN 977 THEN 'Outros' 
        WHEN 835 THEN 'Outros' 
        WHEN 921 THEN 'Outros' 
        WHEN 832 THEN 'Outros' 
        WHEN 826 THEN 'Outros' 
        WHEN 871 THEN 'Outros' 
        WHEN 925 THEN 'Outros' 
        WHEN 926 THEN 'Outros' 
        WHEN 1130 THEN 'Impl. LAN/DCN/Segurança' 
        WHEN 1218 THEN 'Impl. METRO SP' 
        WHEN 398 THEN 'Oper. Banda Larga' 
        WHEN 690 THEN 'Eng. Infr. CORE' 
        WHEN 1274 THEN 'Eng. CORE' 
        WHEN 1275 THEN 'Eng. CORE' 
        WHEN 1063 THEN 'Eng. CORE' 
        WHEN 814 THEN 'Eng. METRO CO/NO/NE' 
        WHEN 465 THEN 'Eng. METRO NE' 
        WHEN 779 THEN 'Eng. METRO NO' 
        WHEN 674 THEN 'Eng. BACKBONE TX' 
        WHEN 477 THEN 'Eng. BACKBONE IP' 
        WHEN 476 THEN 'Eng. LAN/DCN/Segurança' 
        WHEN 1039 THEN 'Eng. de Rede Externa' 
        WHEN 1228 THEN 'Eng. de Rede Externa FSP' 
        WHEN 1227 THEN 'Eng. de Rede Externa SP' 
        WHEN 1043 THEN 'Impl. BACKBONE IP' 
        WHEN 1125 THEN 'Impl. BACKBONE IP' 
        WHEN 1266 THEN 'Outros' 
        WHEN 1107 THEN 'Plan. Infr.' 
        WHEN 1269 THEN 'Plan. LAN/DCN/Segurança' 
        WHEN 488 THEN 'Impl. BACKBONE TX' 
        WHEN 503 THEN 'Outros' 
        WHEN 795 THEN 'Suporte SSI' 
        WHEN 800 THEN 'Suporte SSI' 
        WHEN 798 THEN 'Suporte SSI' 
        WHEN 797 THEN 'Suporte SSI' 
        WHEN 794 THEN 'Suporte SSI' 
        WHEN 806 THEN 'Suporte SSI' 
        WHEN 501 THEN 'TI OSS' 
        WHEN 652 THEN 'TI OSS' 
        WHEN 2397 THEN 'Infraestrutura' 
        ELSE 'Outros' 
        END AS LabelRequisitada, 
        DESC_STATUS AS STATUS_SSI, 
        RESPONSAVEL_TECNICO, 
        REFERENCIA, 
        APLICACAO, 
        OBJETIVO 
        FROM BBTX_PEDS_ENVIADAS 
        where NUMERO_SSI_PED = '{0}'""".format(ped_associada)

    return qry


def qry_demanda(ped_demanda):
    qry = """
        SELECT 
        NUMERO_SSI_PED, 
        SIGLA_AREA_SOLICITANTE, 
        SIGLA_AREA_REQUISITADA, 
        DESC_STATUS, 
        TITULO_SSI, 
        APLICACAO, 
        MOTIVACAO, 
        SP_FSP, 
        UFs 
        FROM BBTX_PEDS_RECEBIDAS 
        WHERE NUMERO_SSI_PED = '{}'""".format(ped_demanda)
    return qry


def qry_legado(eild_legado):
    qry = """
        SELECT  
        idRota, 
        NumEILD, 
        StatusCircuito, 
        rotaSiteA, 
        rotaSiteB, 
        VelocidadeMeio 
        FROM smtx_eild  
        WHERE idRota = '{0}' or NumEILD = '{1}' 
        GROUP BY 
        idRota, 
        NumEILD, 
        StatusCircuito, 
        rotaSiteA, 
        rotaSiteB, 
        VelocidadeMeio""".format(eild_legado, eild_legado)
    return qry


def qry_eild_legado_etp(eilds):
    qry = """
        SELECT  
        'EILD LEGADO' AS Descricao, 
        eild.rotaSiteA AS SiteA, 
        eild.rotaSiteB AS SiteB, 
        'LEGADO' AS Status, 
        'LEGADO' AS TipoElemento, 
        'EILD LEGADO' AS TipoOE, 
        eild.NumEILD AS id, 
        eild.VelocidadeMeio AS Velocidade,  
        SUBSTRING((SELECT ',' + convert(varchar(10), oms.idWDMOMS) AS [text()] 
        FROM vw_smtx_excel_eild as oms 
        where oms.idRota = eild.idRota 
        order by oms.idWDMOMS 
        FOR XML PATH ('')), 2, 8000) AS idsWDMOMS, 
        0 AS numOE, 
        CASE eild.rotaL0 
        WHEN '-' THEN 'N' 
        WHEN 'Parcial' THEN 'L0-P' 
        WHEN 'Total' THEN 'L0-T' 
        ELSE 'N' 
        END AS L0, 
        CASE 
        WHEN eild_equip.AgrupEquipInicAcesso is null THEN 'Z' 
        ELSE eild_equip.AgrupEquipInicAcesso 
        END AS Rota, 
        eild_equip.SiglaEquipInicAcesso AS EquipamentoI, 
        eild_equip.IntEquipInicAcesso AS InterfaceI, 
        eild_equip.SiglaEquipFimAcesso AS EquipamentoF, 
        eild_equip.IntEquipFimAcesso AS InterfaceF, 
        eild_pos.siglaA, 
		eild_pos.shelfA, 
		eild_pos.slotA, 
		eild_pos.portaA, 
		eild_pos.siglaB, 
		eild_pos.shelfB, 
		eild_pos.slotB, 
		eild_pos.portaB, 
        eild_pos.dgoTxA, 
        eild_pos.dgoRxA, 
        eild_pos.dgoTxB, 
        eild_pos.dgoRxB 
        FROM vw_smtx_excel_eild as eild INNER JOIN smtx_idrota_equipamentos as eild_equip 
        ON eild.idRota = eild_equip.idRota 
		LEFT JOIN smtx_idrota_posicoes as eild_pos ON eild.idRota = eild_pos.idRota 
        WHERE NumEILD in ({0}) and idWDMOMS is not null 
        GROUP BY 
        eild.rotaSiteA, 
        eild.rotaSiteB, 
        eild.StatusCircuito, 
        eild.NumEILD, 
        eild.idRota, 
        eild.VelocidadeMeio, 
        eild.rotaL0, 
        eild_equip.SiglaEquipInicAcesso, 
        eild_equip.IntEquipInicAcesso, 
        eild_equip.AgrupEquipInicAcesso, 
        eild_equip.SiglaEquipFimAcesso, 
        eild_equip.IntEquipFimAcesso, 
        eild_pos.siglaA, 
		eild_pos.shelfA, 
		eild_pos.slotA, 
		eild_pos.portaA, 
		eild_pos.siglaB, 
		eild_pos.shelfB, 
		eild_pos.slotB, 
		eild_pos.portaB, 
        eild_pos.dgoTxA, 
        eild_pos.dgoRxA, 
        eild_pos.dgoTxB, 
        eild_pos.dgoRxB 
        order by eild.idRota""".format(eilds)
    return qry


def getEtpData(etp):
    execution_etp = {
        'Etp': etp
    }

    qry_smtx_oms, qry_smtx_oe_oms, qry_smtx_oe_och, qry_smtx_oe_odu, qry_smtx_oe_circuito, qry_smtx_oe_elemento, \
    qry_ssiped, \
    qry_cpomT2, qry_cpomPC, qry_cpomITEM, \
    qry_pmts, qry_smtx_oe_desativacao = createQuerys(etp)

    try:
        #data_smtx_oms = qry_db(qry_smtx_oms, 'portaltx')
        #data_smtx_oms = [dict(row) for row in data_smtx_oms]
        data_smtx_oe_oms = qry_db(qry_smtx_oe_oms, 'portaltx')
        data_smtx_oe_oms = [dict(row) for row in data_smtx_oe_oms]
        data_smtx_oe_och = qry_db(qry_smtx_oe_och, 'portaltx')
        data_smtx_oe_och = [dict(row) for row in data_smtx_oe_och]
        data_smtx_oe_odu = qry_db(qry_smtx_oe_odu, 'portaltx')
        data_smtx_oe_odu = [dict(row) for row in data_smtx_oe_odu]
        data_smtx_oe_circuito = qry_db(qry_smtx_oe_circuito, 'portaltx')
        data_smtx_oe_circuito = [dict(row) for row in data_smtx_oe_circuito]
        data_smtx_oe_elemento = qry_db(qry_smtx_oe_elemento, 'portaltx')
        data_smtx_oe_elemento = [dict(row) for row in data_smtx_oe_elemento]
        data_smtx_oe_desativacao = qry_db(qry_smtx_oe_desativacao, 'portaltx')
        data_smtx_oe_desativacao = [dict(row) for row in data_smtx_oe_desativacao]
    except Exception as e:
        execution_etp['SMTX'] = str(e)
        data_smtx_oms, data_smtx_oe_oms, data_smtx_oe_och, data_smtx_oe_odu, data_smtx_oe_circuito, data_smtx_oe_elemento, data_smtx_oe_desativacao = [], [], [], [], [], [], []

    try:
        data_cpomT2 = qry_db(qry_cpomT2, 'cpom')
        data_cpomT2 = [dict(row) for row in data_cpomT2]
        data_cpomPC = qry_db(qry_cpomPC, 'cpom')
        data_cpomPC = [dict(row) for row in data_cpomPC]
        data_cpomITEM = qry_db(qry_cpomITEM, 'cpom')
        data_cpomITEM = [dict(row) for row in data_cpomITEM]

        for pc in data_cpomPC:
            try:
                pc['SitePC'] = pc['Pep_Id'].split('-')[3][2:5] + '.' + pc['Pep_Id'].split('-')[0][1:]
            except:
                pc['SitePC'] = ''
    except Exception as e:
        execution_etp['CPOM'] = str(e)
        data_cpomT2, data_cpomPC = [], []

    try:
        data_ssiped = qry_db(qry_ssiped, 'ssi')
        data_ssiped = [dict(row) for row in data_ssiped]

        for ped in data_ssiped:
            if ped['PED_ASSOCIADA']:
                associada = qry_db(qry_associada(ped['PED_ASSOCIADA']), 'ssi')
                associada = [dict(row) for row in associada]
                if len(associada) > 0:
                    ped['PED_ASSOCIADA_DETALHES'] = associada[0]
                else:
                    ped['PED_ASSOCIADA_DETALHES'] = None
            else:
                ped['PED_ASSOCIADA_DETALHES'] = None
    except Exception as e:
        execution_etp['SSIPED'] = str(e)
        data_ssiped = []

    try:
        obj = MongoAPI(etp_uri, 'atributes')
        atributes = obj.collection.find_one({'etp': etp}, {'_id': 0})

        data_smtx_eild_legado = getEtpDataLegado(atributes['checklist'])
    except Exception as e:
        execution_etp['ATRIBUTES'] = str(e)
        atributes = None
        data_smtx_eild_legado = []

    data = {
        'execution_etp': execution_etp,
        #'data_smtx_oms': data_smtx_oms,
        'data_smtx_oe_oms': data_smtx_oe_oms,
        'data_smtx_oe_och': data_smtx_oe_och,
        'data_smtx_oe_odu': data_smtx_oe_odu,
        'data_smtx_oe_circuito': data_smtx_oe_circuito,
        'data_smtx_oe_elemento': data_smtx_oe_elemento,
        'data_cpomT2': data_cpomT2,
        'data_cpomPC': data_cpomPC,
        'data_cpomITEM': data_cpomITEM,
        'data_ssiped': data_ssiped,
        'data_smtx_eild_legado': data_smtx_eild_legado,
        'data_smtx_oe_desativacao': data_smtx_oe_desativacao,
        'data_smtx_ots': [],
        'atributes': atributes
    }

    # INCLUSÃO DAS OTS's
    if len(data['data_smtx_oe_oms']) > 0:
        qry = """
            SELECT 
            smtx_ots.idWDMOTS, ChaveOTS, Sigla, 
            SiteA, UFA, EquipA, CAST(LatitudeA AS CHAR(18)) AS LatitudeA, CAST(LongitudeA AS CHAR(18)) AS LongitudeA, 
            SiteB, UFB, EquipB, CAST(LatitudeB AS CHAR(18)) AS LatitudeB, CAST(LongitudeB AS CHAR(18)) AS LongitudeB, 
            Status, PropriedadeFibra, NomeRotaNovo 
            FROM smtx_ots LEFT JOIN smtx_eng_ots ON smtx_ots.idWDMOTS = smtx_eng_ots.idWDMOTS 
            WHERE idWDMOMS in ({0})
            """.format(
            str([str(oms['idsWDMOMS']) for oms in data['data_smtx_oe_oms']]).replace('[', '').replace(']', ''))

        data_ssiped_demanda = qry_db(qry, 'portaltx')
        data['data_smtx_ots'] = [dict(row) for row in data_ssiped_demanda]

    return data


def getEtpDataLegado(checklist):
    legados = next(item['v'] for item in checklist if item['k'] == 'eild_legado')
    s = "', '"
    qry_eild_legado = qry_eild_legado_etp("'" + s.join(legados) + "'")
    data_smtx_eild_legado = qry_db(qry_eild_legado, 'portaltx')
    data_smtx_eild_legado = [dict(row) for row in data_smtx_eild_legado]

    return data_smtx_eild_legado


def getEtpDataResumes(data, data_smtx_oms):
    #data_smtx_oms = data['data_smtx_oms']
    data_smtx_oe_oms = data['data_smtx_oe_oms']
    data_smtx_oe_och = data['data_smtx_oe_och']
    data_smtx_oe_odu = data['data_smtx_oe_odu']
    data_smtx_oe_circuito = data['data_smtx_oe_circuito']
    data_smtx_oe_elemento = data['data_smtx_oe_elemento']
    data_cpomT2 = data['data_cpomT2']
    data_cpomPC = data['data_cpomPC']
    data_cpomITEM = data['data_cpomITEM']
    data_ssiped = data['data_ssiped']
    data_smtx_eild_legado = data['data_smtx_eild_legado']
    data_smtx_oe_desativacao = data['data_smtx_oe_desativacao']
    data_smtx_ots = data['data_smtx_ots'] if 'data_smtx_ots' in data else []
    atributes = data['atributes']

    getElements = lambda data, key, value: [d for d in data if key in d and d[key] in value]

    data_cpom = createCpomData(data_cpomT2, data_cpomPC)
    data_oe = data_smtx_oe_oms + data_smtx_oe_och + data_smtx_oe_odu + data_smtx_oe_circuito + data_smtx_oe_elemento + data_smtx_eild_legado

    resumes = {
        'PED': resume(data_ssiped, 'LabelRequisitada', 'LabelStatus', 'STATUS_SSI', ['Concluída', 'Cancelada']),
        'T2': resume(data_cpom, 'Agrupamento', 'Status', 'Status', []),
        'ETP': {
            'oes': True if len(data_oe) > 0 else False,
            'peds': True if len(data_ssiped) > 0 else False,
            'search': True if (len(data_ssiped) + len(data_cpom) + len(
                data_oe)) > 0 or atributes is not None else False
        },
        'PLOTS': [],
        'OTS': data_smtx_ots
    }

    t2ValorTotal = 0.0
    t2ValorPc = 0.0
    t2ValorFaturado = 0.0

    if len(resumes['T2']) > 0:
        resumes['T2'][0]['ValorTotal'] = float(sum(t2['Valor'] for t2 in data_cpomT2))
        for pcs in data_cpomT2:
            t2ValorPc += float(sum(pc['VlrBrutoPedido'] for pc in pcs['Pedidos']))
            t2ValorFaturado += float(sum(pc['VlrFaturado'] for pc in pcs['Pedidos']))
        resumes['T2'][0]['ValorPC'] = t2ValorPc
        resumes['T2'][0]['ValorFaturado'] = t2ValorFaturado
    else:
        resumes['T2'] = [{'ValorTotal': t2ValorTotal, 'ValorPC': t2ValorPc, 'ValorFaturado': t2ValorFaturado}]

    oes_oms = getElements(data_oe, 'TipoElemento', ['OMS'])
    oes_och = getElements(data_oe, 'TipoElemento', ['OCH'])
    oes_odu = getElements(data_oe, 'TipoElemento', ['ODU'])
    oes_elementos = getElements(data_oe, 'TipoElemento', ['PLACA', 'MUX'])
    oes_circuito = getElements(data_oe, 'TipoElemento', ['EILD'])
    oes_eild_legado = getElements(data_oe, 'TipoElemento', ['LEGADO'])

    ############################## DEFINE CIRCUITOS LIST ADJUSTMENT ##############################
    oes_rotas = defineListEquipments(copy.deepcopy(oes_circuito) + copy.deepcopy(oes_eild_legado))

    ############################## DEFINE CIRCUITOS LINE DETAILS ##############################
    omss_rotas = []
    for omss in oes_rotas:
        omss_rotas += omss['idsWDMOMS'].split(',')
    omss_rotas = list(set(omss_rotas))

    for oms in omss_rotas:
        eilds_in = []
        html = '<li class="list-group-item">OMS 99' + str(oms).zfill(8) + '<ul>'
        for eild in oes_rotas:
            if oms in eild['idsWDMOMS'].split(','):
                eilds_in.append(eild['id'])
                html += '<li>EILD ' + eild['id'] + '</li>'
        html += '</ul></li>'

        for eild in oes_rotas:
            if eild['id'] in eilds_in:
                eild['Details'] += html
    ############################## DEFINE CIRCUITOS LINE DETAILS ##############################

    circuitos_equipamentos = {}
    INFO_EQUIP = sorted(oes_rotas, key=lambda i: i['Rota'])
    for key, value in groupby(INFO_EQUIP, lambda i: i['Rota']):
        circuitos_equipamentos[key] = list(value)
        # new_key = circuitos_equipamentos[key][0]['Rota'] if len(circuitos_equipamentos[key])>0 else '-'
        # circuitos_equipamentos[new_key] = circuitos_equipamentos.pop(key)
    resumes['CIRCUITOS'] = circuitos_equipamentos

    plots = []
    # for val in (oes_oms + oes_och + oes_odu + oes_circuito + oes_eild_legado):
    for val in (oes_oms + oes_och + oes_odu + oes_rotas):
        plots.append({
            'id': val['id'],
            'type': 'line',
            'element': val['TipoElemento'],
            'status': val['Status'],
            'siteA': val['SiteA'],
            'siteB': val['SiteB'],
            'data': getElements(data_smtx_oms, 'idWDMOMStxt', str(val['idsWDMOMS']).split(',')),
            'L0': val['L0'] if 'L0' in val.keys() else 'N',
            'Rota': val['Rota'] if 'Rota' in val.keys() else 'N',
            # 'Rota': 'ROTA '+val['RotaOrder'] if 'RotaOrder' in val.keys() and val['RotaOrder']>0 else '-',
            'Velocidade': val['Velocidade'] if 'Velocidade' in val.keys() else 'N',
            'Details': val['Details'] if 'Details' in val.keys() else None
        })

    for val in data_smtx_ots:
        plots.append({
            'id': val['ChaveOTS'],
            'type': 'line',
            'element': 'OTS',
            'status': val['Status'],
            'siteA': val['SiteA'],
            'siteB': val['SiteB'],
            'data': [{
                'EquipA': val['EquipA'],
                'EquipA2': val['EquipA'],
                'EquipB': val['EquipB'],
                'EquipB2': val['EquipB'],
                'LatitudeA': val['LatitudeA'],
                'LatitudeB': val['LatitudeB'],
                'LongitudeA': val['LongitudeA'],
                'LongitudeB': val['LongitudeB'],
                'SiteA': val['SiteA'],
                'SiteB': val['SiteB'],
                'Status': val['Status'],
                'UFA': val['UFA'],
                'UFB': val['UFB'],
                'idWDMOMS': val['idWDMOTS'],
                'idWDMOMStxt': str(val['idWDMOTS']),
            }],
            'L0': val['L0'] if 'L0' in val.keys() else 'N',
            'Rota': val['Rota'] if 'Rota' in val.keys() else 'N',
            # 'Rota': 'ROTA '+val['RotaOrder'] if 'RotaOrder' in val.keys() and val['RotaOrder']>0 else '-',
            'Velocidade': val['Velocidade'] if 'Velocidade' in val.keys() else 'N',
            'Details': val['Details'] if 'Details' in val.keys() else None
        })

    plotsSet = []
    for val in oes_elementos:
        plot = {
            'id': val['id'],
            'type': 'marker',
            'element': val['TipoElemento'],
            'status': val['Status']
        }

        result = getElements(data_smtx_oms, 'EquipA', val['id']) + getElements(data_smtx_oms, 'EquipB', val['id'])
        result2 = getElements(data_smtx_oms, 'EquipA2', val['id'][:5]) + getElements(data_smtx_oms, 'EquipB2',
                                                                                     val['id'][:5])
        if len(result) > 0:
            plot['id'] = result[0]['SiteA'] + '.' + result[0]['UFA'] if val['id'] == result[0]['EquipA'] else \
                result[0]['SiteB'] + '.' + result[0]['UFB']
            plot['data'] = {
                'Latitude': result[0]['LatitudeA'] if val['id'] == result[0]['EquipA'] else result[0]['LatitudeB'],
                'Longitude': result[0]['LongitudeA'] if val['id'] == result[0]['EquipA'] else result[0][
                    'LongitudeB']
            }
        elif len(result2) > 0:
            plot['id'] = result2[0]['SiteA'] + '.' + result2[0]['UFA'] if val['id'][:5] == result2[0][
                'EquipA2'] else result2[0]['SiteB'] + '.' + result2[0]['UFB']
            plot['data'] = {
                'Latitude': result2[0]['LatitudeA'] if val['id'][:5] == result2[0]['EquipA2'] else result2[0][
                    'LatitudeB'],
                'Longitude': result2[0]['LongitudeA'] if val['id'][:5] == result2[0]['EquipA2'] else result2[0][
                    'LongitudeB']
            }

        if plot['id'] not in plotsSet:
            plots.append(plot)
            plotsSet.append(plot['id'])

    trataPlots = lambda: [d for d in plots if 'data' in list(d.keys())]
    resumes['PLOTS'] = trataPlots()

    plots_routers = []
    for rota in oes_rotas:
        rota_id = next(item for item in plots if item['id'] == rota['id'])

        try:
            rota_siteA = next(item for item in rota_id['data'] if
                              item['SiteA'] + '-' + item['UFA'] == rota['SiteA'] or item['SiteB'] + '-' + item[
                                  'UFB'] ==
                              rota['SiteA'])
            plotA = {'id': rota['id'], 'type': 'marker', 'element': 'ROUTER', 'status': "Concluida",
                     'Rota': ' '.join(rota['Rota'].split()), 'data': {
                    'Latitude': rota_siteA['LatitudeA'] if rota['SiteA'] == rota_siteA['SiteA'] + '-' + rota_siteA[
                        'UFA'] else rota_siteA['LatitudeB'],
                    'Longitude': rota_siteA['LongitudeA'] if rota['SiteA'] == rota_siteA['SiteA'] + '-' +
                                                             rota_siteA[
                                                                 'UFA'] else rota_siteA['LongitudeB']
                }, 'Camada': rota['CamadaI'], 'Site': rota['SiteI']}
            plots_routers.append(plotA)
        except:
            pass

        try:
            rota_siteB = next(item for item in rota_id['data'] if
                              item['SiteA'] + '-' + item['UFA'] == rota['SiteB'] or item['SiteB'] + '-' + item[
                                  'UFB'] ==
                              rota['SiteB'])
            plotB = {'id': rota['id'], 'type': 'marker', 'element': 'ROUTER', 'status': "Concluida",
                     'Rota': ' '.join(rota['Rota'].split()), 'data': {
                    'Latitude': rota_siteB['LatitudeA'] if rota['SiteB'] == rota_siteB['SiteA'] + '-' + rota_siteB[
                        'UFA'] else rota_siteB['LatitudeB'],
                    'Longitude': rota_siteB['LongitudeA'] if rota['SiteB'] == rota_siteB['SiteA'] + '-' +
                                                             rota_siteB[
                                                                 'UFA'] else rota_siteB['LongitudeB']
                }, 'Camada': rota['CamadaF'], 'Site': rota['SiteF']}
            plots_routers.append(plotB)
        except:
            pass

    resumes['PLOTS'] = resumes['PLOTS'] + plots_routers

    #### INFORMAÇÕES PARA CRIAR PLANILHAS DE APOIO FIBRAS
    fibras_info = []
    fibras_info_resume = []
    for plot in resumes['PLOTS']:
        if plot['type'] == 'line':
            for d in plot['data']:
                fibras_info.append(d['idWDMOMS'])

    if len(fibras_info) > 0 and 'Eng. de Rede Externa' in [ped['LabelRequisitada'] for ped in data_ssiped]:
        qry_fibras_info = """
            SELECT  
            ChaveOTS, 
            LEFT(SiteA, 3)+UFA AS 'PontaA', 
            LEFT(SiteB, 3)+UFB AS 'PontaB' 
            FROM smtx_ots 
            WHERE idWDMOMS in ({})
            GROUP BY ChaveOTS, LEFT(SiteA, 3)+UFA, LEFT(SiteB, 3)+UFB 
            ORDER BY ChaveOTS
        """.format(str(fibras_info).replace('[', '').replace(']', ''))
        data_fibras_info = qry_db(qry_fibras_info, 'portaltx')
        data_fibras_info = [dict(row) for row in data_fibras_info]

        c = 0
        for f in data_fibras_info:
            for r in range(2):
                c += 1
                line = {
                    'Sigla Fibra': 'DESIGNADOR|OTS'+f['ChaveOTS']+'_F'+str(c),
                    'Numero da Fibra': str(c),
                    'Ponta A (Site+UF)': f['PontaA'],
                    'Ponta B (Site+UF)': f['PontaB']
                }
                for field in ['Sigla do cabo', 'Proprietário', 'Acordo Swap', 'DGO A', 'DGO B', 'Distancia KM']:
                    line[field] = ''
                fibras_info_resume.append(line)


    resumes['FIBRAS_INFO'] = fibras_info_resume
    ######################################################

    # Avaliação de Status (Etp's Offline)
    if atributes and 'status' in atributes.keys():
        etpStatus = atributes['status']
    else:
        pedImplantacao = getElements(resumes['PED'], 'id', 'Impl. BACKBONE TX')
        etpStatus = 'Em Engenharia'

        if len(pedImplantacao) > 0 and 'Devolvida' not in pedImplantacao[0]['status'].keys():
            if 'Associada' in pedImplantacao[0]['status'].keys():
                etpStatus = 'Em O&M'
            elif 'Em Análise' in pedImplantacao[0]['status'].keys():
                etpStatus = 'Em Implantação'
            elif 'Devolvida' in pedImplantacao[0]['status'].keys():
                etpStatus = 'Em Engenharia'
            elif 'Concluída' in pedImplantacao[0]['status'].keys():
                etpStatus = 'Concluída'
            elif 'Cancelada' in pedImplantacao[0]['status'].keys():
                etpStatus = 'Em Engenharia'
            else:
                etpStatus = 'Em Engenharia'

    resumes['ETP']['status'] = etpStatus

    for ped in resumes['PED']:
        status = list(ped['status'].keys())
        if len(status) > 0 and len(status) > 1:
            if 'Cancelada' in status:
                status.remove('Cancelada')
            ped['resultado'] = status[0]
        elif len(status) == 1:
            ped['resultado'] = status[0]
        else:
            ped['resultado'] = 'Em Análise'

    details = {
        'ATRIBUTOS': atributes,
        'EDIT_VALIDATION': bool(
            current_user.has_role('etps_edit') and atributes and atributes['status'] in ['Em Engenharia', 'Em Implantação']),
        'EDIT_VALIDATION_WRITE': bool(
            current_user.has_role('etps_edit')),
        'OES': data_oe,
        'PEDS': data_ssiped,
        'T2S': data_cpom,
        'COTACAO': data_cpomITEM
    }

    # OES DE DESATIVAÇÃO
    for oe in data_smtx_oe_desativacao:
        if 'numOE' not in oe:
            oe['numOE'] = oe['NumOE']
            del oe['NumOE']
    details['OES'] = details['OES'] + data_smtx_oe_desativacao

    # DEFINIR SITES DO PROJETO
    site_checklist = []
    if atributes:
        for atribute in atributes['checklist']:
            if atribute['k'] == 'site_science':
                site_checklist = atribute['v']
                while '' in site_checklist: site_checklist.remove('')

    sites_projeto = list(set(
        [site['id'] if site['id'].split('.')[0][-2:] != site['id'].split('.')[1] else site['id'].split('.')[0][
                                                                                      :3] + '.' +
                                                                                      site['id'].split('.')[1] for
         site in resumes['PLOTS'] if site['element'] in ['MUX', 'PLACA']] + \
        site_checklist
    ))

    # site_financeiro = [pedido['Pep_Id'].split('-')[3][2:5] + '.' + pedido['Pep_Id'].split('-')[0][1:] if pedido['Pep_Id'].split('-')[0][:1] == 'V' else pedido['Pep_Id'].split('-')[3][1:4] + '.' + pedido['Pep_Id'].split('-')[0][1:] for pedido in data_cpomPC]
    site_financeiro_check = []
    for item in data_cpomITEM:
        projeto = [proj['Projeto'] for proj in data_cpom if proj['T2'] == item['IdT2']][0]
        if len(item['Site']) > 3:
            site = item['Site']
            tipo = 'F'
        else:
            site = item['Site'] + '.' + projeto.split('-')[0][1:]
            tipo = 'M'
        if site not in sites_projeto and site not in site_financeiro_check:
            sites_projeto.append([site, tipo])
            site_financeiro_check.append(site)

    sites, sites_plot = getEtpSites(
        sites_projeto,
        [site['id'] if site['id'].split('.')[0][-2:] != site['id'].split('.')[1] else site['id'].split('.')[0][
                                                                                      :3] + '.' + site['id'].split('.')[
                                                                                          1] for site in
         resumes['PLOTS'] if site['element'] in ['MUX', 'PLACA']]
    )

    details['SITES'] = sites
    resumes['PLOTS'] = resumes['PLOTS'] + sites_plot

    return resumes, details


def defineListEquipments(list_oes_rotas):
    # del_keys = ['TipoOE', 'Status', 'Descricao', 'idsWDMOMS']
    del_keys = []
    for eild in list_oes_rotas:
        for k in del_keys:
            del eild[k]
        try:
            eild['SiteI'] = (
                    eild['EquipamentoI'].split('-')[4] + '-' + eild['EquipamentoI'].split('-')[2]).upper() if \
                eild['EquipamentoI'] else ''
            eild['SiteF'] = (
                    eild['EquipamentoF'].split('-')[4] + '-' + eild['EquipamentoF'].split('-')[2]).upper() if \
                eild['EquipamentoF'] else ''
            eild['CamadaI'] = (eild['EquipamentoI'].split('-')[5]).upper() if eild['EquipamentoI'] else ''
            eild['CamadaF'] = (eild['EquipamentoF'].split('-')[5]).upper() if eild['EquipamentoF'] else ''
            eild['EquipamentoI'] = eild['EquipamentoI'] if eild['EquipamentoI'] else ''
            eild['InterfaceI'] = eild['InterfaceI'] if eild['InterfaceI'] else ''
            eild['EquipamentoF'] = eild['EquipamentoF'] if eild['EquipamentoF'] else ''
            eild['InterfaceF'] = eild['InterfaceF'] if eild['InterfaceF'] else ''
        except:
            eild['SiteI'] = ''
            eild['SiteF'] = ''
            eild['CamadaI'] = ''
            eild['CamadaF'] = ''
        try:
            eild['Rota'] = 'ROTA ' + str(int(eild['Rota'].lower().replace('rota', ''))).zfill(2)
            eild['Details'] = ''
        except:
            eild['Rota'] = eild['Rota']
            eild['Details'] = ''

    # Agrupamento
    list_oes_rotas_fix = copy.deepcopy(list_oes_rotas)
    list_fields_clearA = ['siglaA', 'shelfA', 'slotA', 'portaA', 'dgoTxA', 'dgoRxA']
    list_fields_clearB = ['siglaB', 'shelfB', 'slotB', 'portaB', 'dgoTxB', 'dgoRxB']
    list_fields_clear = list_fields_clearA + list_fields_clearB

    for fix in list_oes_rotas_fix:
        for c in list_fields_clear:
            fix[c] = ''
    list_oes_rotas_fix = list({frozenset(item.items()):item for item in list_oes_rotas_fix}.values())

    for eild in list_oes_rotas_fix:
        list_eild_filter = [rota for rota in list_oes_rotas if rota['Rota'] == eild['Rota'] and rota['id'] == eild['id']]
        for i in list_eild_filter:
            for k in list(list_eild_filter[0].keys()):
                i[k] = '' if i[k] is None else i[k]
        iOk = False
        fOk = False

        for rota in list_eild_filter:
            if eild['SiteI'] == rota['siglaA'][:3]+'-'+rota['siglaA'][3:5] and not iOk:
                iOk = True
                for c in list_fields_clearA:
                    eild[c] = rota[c]
            if eild['SiteI'] == rota['siglaB'][:3]+'-'+rota['siglaB'][3:5] and not iOk:
                iOk = True
                for c in list_fields_clearA:
                    eild[c] = rota[c[:-1]+'B']

            if eild['SiteF'] == rota['siglaB'][:3]+'-'+rota['siglaB'][3:5] and not fOk:
                fOk = True
                for c in list_fields_clearB:
                    eild[c] = rota[c]
            if eild['SiteF'] == rota['siglaA'][:3]+'-'+rota['siglaA'][3:5] and not fOk:
                fOk = True
                for c in list_fields_clearB:
                    eild[c] = rota[c[:-1]+'A']
    # --------------------------------------------

    return list_oes_rotas_fix


def qry_site_science(site, sitex, tipo):
    qry = """select top 1 
            uf, nome, sigla, id_financeiro, situacao, 
            municipio, bairro, endereco, cep, utilizacao, 
            CAST(latitude AS CHAR(18)) AS latitude, CAST(longitude AS CHAR(18)) AS longitude, 
            sigla_fixa 
            from science_sites """
    if tipo == 'M':
        qry = qry + """where sigla+'.'+uf in ('{0}', '{1}')""".format(site, sitex)
    elif tipo == 'F':
        qry = qry + """where sigla_fixa = '{0}'""".format(site)

    return qry


def getEtpSites(sites_list, sites_oes):
    sites = []
    sites_plot = []
    # sites_list = list(sites_list)
    # sites_list.sort()

    for site in sites_list:
        if type(site) == list:
            siteTemp = site[0]
            qry = qry_site_science(site[0], site[0], site[1])
        else:
            siteTemp = site
            qry = qry_site_science(
                site, site.split('.')[0][:3] + '.' + site.split('.')[1], 'M')

        response = qry_db(qry, 'portaltx')
        response = [dict(row) for row in response]

        if response:
            if len(response) > 0:
                site_dict = response[0]
                site_dict['origem'] = 'SMTX' if site in sites_oes else 'OUTROS'
                sites.append(response[0])

                # INSERIR SITES DO PROJETO EM PLOT
                if siteTemp not in sites_oes:
                    sites_plot.append(
                        {
                            "data": {
                                "Latitude": response[0]['latitude'],
                                "Longitude": response[0]['longitude']
                            },
                            "element": "ENVOLVIDOS",
                            "id": siteTemp,
                            "status": "-",
                            "type": "marker"
                        }
                    )
            else:
                sites.append({'uf': siteTemp.split('.')[1],
                              'sigla': siteTemp.split('.')[0],
                              'origem': 'SMTX' if siteTemp in sites_oes else 'OUTROS'})

    return sites, sites_plot
