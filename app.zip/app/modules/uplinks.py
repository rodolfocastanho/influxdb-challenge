from flask import Blueprint

from flask_login import login_required
from flask import render_template, jsonify, request
from flask_security import roles_accepted
from flask_pymongo import PyMongo

from models import qry_db

# MongoDB RSNAC
rsnacDb = PyMongo()

uplinks_bp = Blueprint('uplinks', __name__)


@uplinks_bp.route('/uplinks', methods=['GET'])
@login_required
@roles_accepted('uplinks')
def uplinks():
    municipios = rsnacDb.db.supports.find({'title': 'Places'}, {'name': 1, '_id': 0})
    municipios = municipios[0]['name']
    return render_template('/uplinks.html', municipios=municipios)


@uplinks_bp.route('/ajax-uplinks', methods=['GET'])
@login_required
def ajax_uplinks():
    filtro = request.args.get('filtro')
    idsRota = []
    idsRotaOMS = []

    resumo = rsnacDb.db.elements.find({
        '$or':[{'CIDADE_A': filtro, 'CamadaA': 'HL3', 'CamadaB': 'HL2'},
               {'CIDADE_B': filtro, 'CamadaB': 'HL3', 'CamadaA': 'HL2'}]
    }, {'_id': 0})
    resumo = [dict(row) for row in resumo]

    eilds = []
    for i in resumo:
        if i['Designador'][:4] == 'EILD':
            eilds.append(i['Designador'].replace('EILD', ''))
    if len(eilds) > 0:
        ids = str(eilds).replace('[', '').replace(']', '')

        sqlIdsRota = "SELECT eild.NumEILD AS idRota, eild.rotaSiteA AS SiteA, eild.rotaSiteB AS SiteB, " + \
                     "eild.L1 AS L1, eild.L0 AS L0, " + \
                     "CASE WHEN SUM(eng.Latencia) IS NULL THEN 0 ELSE SUM(eng.Latencia) END AS Latencia " + \
                     "FROM smtx_eild as eild LEFT JOIN smtx_odu as odu ON eild.idWDMODU = odu.idWDMODU " + \
                     "LEFT JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                     "LEFT JOIN smtx_eng as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                     "WHERE eild.NumEILD IN (" + ids + ") " + \
                     "GROUP BY eild.NumEILD, eild.rotaSiteA, eild.rotaSiteB, eild.L1, eild.L0"
        sqlIdsRotaOMS = "SELECT " + \
                        "eild.NumEILD AS idRota, " + \
                        "eng.idWDMOMS AS idWDMOMS, " + \
                        "eng.SiteA AS SiteA, " + \
                        "eng.UFA AS UFA, " + \
                        "eng.LatitudeA AS LatitudeA, " + \
                        "eng.LongitudeA AS LongitudeA, " + \
                        "eng.SiteB AS SiteB, " + \
                        "eng.UFB AS UFB, " + \
                        "eng.LatitudeB AS LatitudeB, " + \
                        "eng.LongitudeB AS LongitudeB, " + \
                        "eng.Status AS Status " + \
                        "FROM smtx_eild as eild INNER JOIN smtx_odu as odu ON eild.idWDMODU = odu.idWDMODU " + \
                        "INNER JOIN smtx_och as och ON odu.idWDMOCH = och.idWDMOCH " + \
                        "INNER JOIN vw_smtx_map_coordinate_web as eng ON och.idWDMOMS = eng.idWDMOMS " + \
                        "WHERE eild.NumEILD IN (" + ids + ") " + \
                        "GROUP BY " + \
                        "eild.NumEILD, " + \
                        "eng.idWDMOMS, " + \
                        "eng.SiteA, eng.UFA, " + \
                        "eng.LatitudeA, eng.LongitudeA, " + \
                        "eng.SiteB, eng.UFB, " + \
                        "eng.LatitudeB, eng.LongitudeB, " + \
                        "eng.Status " + \
                        "ORDER BY eild.NumEILD"
        idsRota = qry_db(sqlIdsRota, 'portaltx')
        idsRota = [dict(row) for row in idsRota]
        idsRotaOMS = qry_db(sqlIdsRotaOMS, 'portaltx')
        idsRotaOMS = [dict(row) for row in idsRotaOMS]

    #df = pd.DataFrame({'from': ['A', 'B', 'C', 'A'], 'to': ['D', 'A', 'E', 'C']})
    #g = nx.from_pandas_edgelist(df, 'from', 'to')
    #nx.draw(g, with_labels=True)

    #img = BytesIO()  # file-like object for the image
    #plt.savefig(img)  # save the image to the stream
    #img.seek(0)  # writing moved the cursor to the end of the file, reset
    #plt.clf()  # clear pyplot

    response = {
        'resumo': resumo,
        'idsRota': [dict(row) for row in idsRota],
        'idsRotaOMS': [dict(row) for row in idsRotaOMS]#,
        #'diagrama': send_file(img, mimetype='image/png')
    }
    return jsonify(response)