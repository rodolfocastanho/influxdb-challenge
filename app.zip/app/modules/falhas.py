from flask import Blueprint

from flask_login import login_required
from flask import render_template, jsonify
from flask_security import roles_accepted

import pymysql
import pandas as pd

from models import qry_db

falhas_bp = Blueprint('falhas', __name__)


@falhas_bp.route('/falhas', methods=['GET'])
@login_required
@roles_accepted('falhas')
def falhas():
    return render_template('falhas.html')


@falhas_bp.route('/ajax-falhas', methods=['GET'])
@login_required
def ajax_falhas():
    topology = qry_db("SELECT * FROM vw_smtx_map_coordinate_web", 'portaltx')
    topology = [dict(row) for row in topology]

    ticketsQry = "SELECT * FROM cad_operadora"
    mesa_host = '10.40.9.221'
    mesa_port = 3306
    mesa_user = 'backbone'
    mesa_passw = 'CDpwVQq6Xajea8yF'
    mesa_database = 'mesa_controle'
    mesa_conn = pymysql.connect(host=mesa_host,
                                port=mesa_port,
                                user=mesa_user,
                                passwd=mesa_passw,
                                db=mesa_database,
                                charset='utf8')
    df_tickets = pd.read_sql(ticketsQry, mesa_conn)
    mesa_conn.close()
    tickets = df_tickets.to_dict('records')


    #tickets = []
    #with mesa_db_engine.connect() as connection:
    #    result = connection.execute(ticketsQry)
    #    for row in result:
    #        tickets.append(dict(row))

    response = {
        'topology': topology,
        'tickets': tickets
    }

    return jsonify(response)
