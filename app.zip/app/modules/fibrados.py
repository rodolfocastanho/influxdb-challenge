from flask import Blueprint

from flask import url_for, render_template, redirect, jsonify, request
from flask_login import login_required, current_user
from flask_security import roles_accepted
from flask_pymongo import PyMongo

from itertools import groupby
from collections import Counter
import datetime

from models import qry_db, municipios_uri, MongoAPI

# MongoDB ETP
etpDb = PyMongo()

fibrados_bp = Blueprint('fibrados', __name__)


@fibrados_bp.route('/fibrados', methods=['GET'])
@login_required
@roles_accepted('fibrados')
def etps():
    obj_fibrados = MongoAPI(municipios_uri, 'fibrados')
    fibrados = obj_fibrados.collection.find({},
                                            {'_id': 0,
                                             'chave': 1,
                                             'codigo_ibge': 1,
                                             'nome': 1,
                                             'latitude': 1,
                                             'longitude': 1,
                                             'nome_uf': 1,
                                             'uf': 1,
                                             'populacao': 1,
                                             'classifica_populacao': 1,
                                             'final': 1})
    fibrados = [dict(row) for row in fibrados]
    for f in fibrados:
        if f['final'] == 'CADASTRO':
            f['final'] = 'FIBRADO'

    obj_municipios = MongoAPI(municipios_uri, 'fibrados')
    municipios = obj_municipios.collection.aggregate([
        {
            '$project': {
                '_id': 0,
                'chave': 1,
                'latitude': 1,
                'longitude': 1
            }
        }, {
            '$addFields': {
                'Site': '$chave'
            }
        }
    ])
    municipios = [dict(row) for row in municipios]

    obj_grupos = MongoAPI(municipios_uri, 'fibrados')
    grupos = obj_grupos.collection.aggregate([
        {
            '$project': {
                '_id': 0,
                'classifica_populacao': 1,
                'final': 1,
                'uf': 1
            }
        }, {
            '$group': {
                '_id': {
                    'classifica_populacao': '$classifica_populacao',
                    'final': '$final',
                    'uf': '$uf'
                },
                'count': {
                    '$sum': 1
                }
            }
        }
    ])
    grupos = [dict(row) for row in grupos]
    for g in grupos:
        if g['_id']['final'] == 'CADASTRO':
            g['_id']['final'] = 'FIBRADO'

    return render_template('fibrados.html',
                           fibrados=[dict(row) for row in fibrados],
                           municipios=[dict(row) for row in municipios],
                           grupos=[dict(row) for row in grupos])

