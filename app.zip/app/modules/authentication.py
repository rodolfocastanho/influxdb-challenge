from flask import Blueprint

from flask_login import login_required, current_user, login_user, logout_user
from flask import url_for, render_template, redirect, request, flash, session
from flask_security import roles_accepted
from flask_wtf.csrf import CSRFError

import datetime

import forms as forms
from models import db, User, Role, RolesUsers, qry_db

import distutils.util
from ldap3 import Server, Connection, SAFE_SYNC, ALL

auth_bp = Blueprint('authentication', __name__)


@auth_bp.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@auth_bp.errorhandler(CSRFError)
def handle_csrf_error(e):
    return render_template('csrf_error.html', reason=e.description), 400


@auth_bp.route('/login_user', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('topology.index'))

    login_form = forms.LoginForm(request.form)

    if request.method == 'POST' and login_form.validate():
        username = login_form.username.data
        password = login_form.password.data
        domain = login_form.domain.data

        dominios = {
            'REDECORP': {'nome': "redecorp", 'endereco': "redecorp.br", 'dc': "dc=redecorp,dc=br"},
            'GVT': {'nome': "gvt", 'endereco': "gvt.net.br", 'dc': "dc=gvt,dc=net,dc=br"}
        }
        dominio = dominios[domain]

        try:
            server = Server('ldap://{0}'.format(dominio['endereco']), get_info=ALL)
            conn = Connection(server,
                              '{0}\{1}'.format(dominio['nome'], username),
                              password,
                              client_strategy=SAFE_SYNC, auto_bind=True)
            status, result, response, _ = conn.search(dominio['dc'], '(objectclass=*)')
            authOK = status
        except:
            authOK = False

        #authOK = True  # TODO: (SOMENTE PARA TESTE LOCAL)
        user = User.query.filter_by(username=username).first()
        if user is not None and authOK:
            login_user(user)
            session.permanent = True

            user.last_access = datetime.datetime.now()
            db.session.commit()
            db.session.flush()

            return redirect(url_for('topology.index'))
        else:
            error_message = 'Erro ao autenticar!!'
            flash(error_message, 'alert-danger')

    return render_template('user/login.html', form=login_form)


@auth_bp.route('/login_user2', methods=['GET', 'POST'])
def login2():
    if current_user.is_authenticated:
        return redirect(url_for('topology.index'))

    login_form = forms.LoginForm2(request.form)

    if request.method == 'POST' and login_form.validate():
        username = login_form.username.data
        password = login_form.password.data

        user = User.query.filter_by(username=username).first()
        if user is not None and user.verify_password(password):
            login_user(user)
            return redirect(url_for('topology.index'))
        else:
            error_message = 'Login ou senha incorreto!!'
            flash(error_message, 'alert-danger')

    return render_template('user/login.html', form=login_form)


@auth_bp.route('/user/password', methods=['GET', 'POST'])
@login_required
# @roles_accepted('change_password')
def password():
    return redirect(url_for('topology.index'))
    # return str(current_user.id)
    change_password_form = forms.ChangePasswordForm(request.form)

    if request.method == 'POST' and change_password_form.validate():
        user = User.query.get(current_user.id)
        user.password = user.__create_password__(change_password_form.password.data)
        db.session.commit()
        db.session.flush()

        success_message = 'Senha alterada'
        flash(success_message, 'alert-success')

    return render_template('user/change_password.html', form=change_password_form)


@auth_bp.route('/user/logout')
def logout():
    logout_user()

    return redirect(url_for('.login'))


@auth_bp.route('/usuario/criar', methods=['GET', 'POST'])
@login_required
@roles_accepted('create_user')
def create_user():
    create_form = forms.CreateUserForm(request.form)
    roles_list = db.session.query(Role)
    if request.method == 'POST' and create_form.validate():
        user = User(create_form.username.data,
                    'backbone',
                    create_form.name.data,
                    current_user.id)
        db.session.add(user)
        db.session.commit()
        # db.session.flush()

        roles = request.form.getlist("roles")
        if len(roles) > 0:
            for role in roles:
                db.session.add(RolesUsers(user.id, role))
                db.session.commit()

        db.session.flush()
        success_message = 'Usuario registrado'
        flash(success_message, 'alert-success')

    return render_template('user/create.html', form=create_form, roles_list=roles_list)


@auth_bp.route('/usuario/adm', methods=['GET', 'POST'])
@login_required
@roles_accepted('create_user')
def adm_user():
    id_user = request.args.get('id_user')

    if id_user is not None:
        user = User.query.get(id_user)
        user.name = request.args.get('name')
        #if distutils.util.strtobool(request.args.get('resetSenha')):
            #user.password = user.__create_password__('backbone')
        db.session.commit()

        userRoles = [int(x.id) for x in user.roles]

        rolesAdd = [int(x) for x in request.args.get('rolesAdd').split("_")] if request.args.get('rolesAdd')!='' else []
        try:
            rolesAdd.remove('')
        except:
            pass
        rolesAdd = [w for w in rolesAdd if w not in userRoles]

        rolesDel = [int(x) for x in request.args.get('rolesDel').split("_")] if request.args.get('rolesDel')!='' else []
        try:
            rolesDel.remove('')
        except:
            pass
        rolesDel = [w for w in rolesDel if w in userRoles]

        if len(rolesAdd) > 0:
            for role in rolesAdd:
                db.session.add(RolesUsers(user.id, role))
                db.session.commit()

        db.session.flush()

        if len(rolesDel) > 0:
            for role in rolesDel:
                x = "delete from roles_users where user_id = " + str(user.id) + " and role_id = " + str(role)
                qry_db("delete from roles_users where user_id = " + str(user.id) + " and role_id = " + str(role), 'portaltx')

        return user.id
    else:
        usuarios = db.session.query(User.id, User.username, User.name).order_by(User.name.asc())
        usersPermission = qry_db("SELECT user_id, role_id FROM roles_users", 'portaltx')
        roles = qry_db("SELECT * FROM roles", 'portaltx')
        return render_template('user/adm.html',
                               usuarios=usuarios,
                               usersPermission=[dict(row) for row in usersPermission],
                               roles=[dict(row) for row in roles])
