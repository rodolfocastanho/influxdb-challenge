from flask import Blueprint

from flask import url_for, render_template, redirect, jsonify, request
from flask_login import login_required, current_user
from flask_security import roles_accepted
from flask_pymongo import PyMongo

from itertools import groupby
from operator import itemgetter

from models import qry_db, spam_monitor_uri, MongoAPI

from datetime import datetime

# MongoDB ETP
etpDb = PyMongo()

spam_monitor_bp = Blueprint('spammonitor', __name__)


@spam_monitor_bp.route('/spanmonitor', methods=['GET'])
@login_required
@roles_accepted('spanmonitor')
def spam_monitor():
    def cleanData(array):
        spam_fields = list(array[0].keys()).copy()
        count = 0

        for row in array:

            timestamp = row['timestamp']
            date_time = datetime.fromtimestamp(timestamp)
            row['timestamp_format'] = date_time.strftime("%d/%m/%Y - %H:%M")

            for k in spam_fields:
                try:
                    if str(row[k]).lower() == 'none':
                        row[k] = ""
                    elif str(row[k]).lower() in ['true', 'false']:
                        row[k] = 'Sim' if int(row[k]) > 0 else 'Não'
                    else:
                        row[k] = str(row[k])
                except:
                    row[k] = str(row[k])
            row['id_frontend'] = count
            count = count + 1
        return array

    obj_spam = MongoAPI(spam_monitor_uri, 'base_span_monitor')
    spam = obj_spam.collection.find({'$nor': [
        {'lat_a': 'Not Found'},
        {'lat_z': 'Not Found'},
        {'long_a': 'Not Found'},
        {'long_z': 'Not Found'}
    ]}, {'_id': 0})
    spam = cleanData([dict(row) for row in spam])

    # REPORT
    list_report = [
        ['Status', 'status', 'Geral (por status)', '', ['Status', 'Qtd']],
        ['Vendor', 'vendor', 'Geral (por vendor)', '', ['Vendor', 'Qtd']],
        ['Ciena', 'status', 'Ciena', 'Ciena', ['Status', 'Qtd']],
        ['Nokia', 'status', 'Nokia', 'Nokia', ['Status', 'Qtd']],
        #['Huawei SP', 'status', 'Huawei_SP', 'Huawei_SP', ['Status', 'Qtd']],
        #['Huawei BBN', 'status', 'Huawei', 'Huawei_BBN', ['Status', 'Qtd']],
        ['Huawei', 'status', 'Huawei', 'Huawei', ['Status', 'Qtd']],
    ]

    obj_report = {}

    for r in list_report:
        span_d = spam.copy() if r[3] == '' else [span_ for span_ in spam if span_['vendor'] == r[3]]
        resume = sorted(span_d, key=itemgetter(r[1]))

        obj = {
            'title': r[2],
            'data': [r[4]]
        }

        if len(span_d) > 0:
            for key, value in groupby(resume, key=itemgetter(r[1])):
                obj['data'].append([key, len(list(value))])
        else:
            obj['data'].append(['-', 0])

        obj_report[r[0]] = obj

    return render_template('spam_monitor.html',
                           spam=spam,
                           report=obj_report)
