from wtforms import Form
from wtforms import StringField, PasswordField, IntegerField, TextAreaField, DateTimeField, SelectField
from wtforms import validators

from models import User, qry_db


def validate_username(form, field):
    username = field.data
    user = User.query.filter_by(username=username).first()
    if user is not None:
        raise validators.ValidationError('Usuário já está cadastrado!')


class LoginForm2(Form):
    username = StringField('',
                           [
                               validators.Required(message='Insira o login!'),
                               validators.length(min=6, max=10, message='Login inválido! (6 a 10 caract)')
                           ])
    password = PasswordField('',
                             [
                                 validators.Required('Insira a senha!'),
                                 validators.length(min=6, max=10, message='Senha inválida! (6 a 10 caract)')
                             ])


class LoginForm(Form):
    username = StringField('',
                           [
                               validators.Required(message='Insira o login!')
                           ])
    password = PasswordField('',
                             [
                                 validators.Required('Insira a senha!')
                             ])
    domain = SelectField('',
                          choices=[('REDECORP', 'REDECORP'), ('GVT', 'GVT')])


class CreateUserForm(Form):
    username = StringField('',
                           [
                               validators.Required(message='Insira o login!'),
                               #validators.length(min=6, max=10, message='Login inválido! (6 a 10 caract)'),
                               validate_username
                           ])
    name = StringField('',
                       [
                           validators.Required(message='Insira o nome completo!'),
                           validators.length(min=5, max=200, message='Nome inválido! (6 a 200 caract)')
                       ])


class ChangePasswordForm(Form):
    password = PasswordField('',
                             [
                                 validators.Required('Insira uma nova senha!'),
                                 validators.length(min=6, max=10, message='Senha inválida! (6 a 10 caract)')
                             ])


class B2bCotacao(Form):
    produto = SelectField('', choices=[('PRODUTO1', 'PRODUTO1'), ('PRODUTO2', 'PRODUTO2')])
    cidadeA = SelectField('', coerce=str)
    siteA = SelectField('', coerce=str)
    cidadeB = SelectField('', coerce=str)
    siteB = SelectField('', coerce=str)

def formB2bCotacao():
    pass
