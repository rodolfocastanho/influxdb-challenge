from flask import Config
import os
import urllib
from datetime import timedelta

from sqlalchemy import create_engine

basedir = os.path.abspath(os.path.dirname(__file__))


class Config(object):
    SECRET_KEY = 'PORT@LB@CKBON&TX'
    WTF_CSRF_SECRET_KEY = 'PORT@LB@CKBON&TX'
    # SECURITY_LOGIN_USER_TEMPLATE = 'user/login_redirect.html'
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=360)


class DevelopmentConfig(Config):
    # DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://' + os.getenv('DB_USER_PORTAL') + ':' + urllib.parse.quote(os.getenv('DB_PASS_PORTAL')) + '@' + os.getenv('DB_HOST_PORTAL') + '/' + os.getenv('DB_BASE_PORTAL') + '?driver=ODBC+Driver+17+for+SQL+Server'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_BINDS = {
        'portaltx': 'mssql+pyodbc://' + os.getenv('DB_USER_PORTAL') + ':' + urllib.parse.quote(os.getenv('DB_PASS_PORTAL')) + '@' + os.getenv('DB_HOST_PORTAL') + '/' + os.getenv('DB_BASE_PORTAL') + '?driver=ODBC+Driver+17+for+SQL+Server',
        'cpom': 'mssql+pyodbc://' + os.getenv('DB_USER_CPOM') + ':' + urllib.parse.quote(os.getenv('DB_PASS_CPOM')) + '@' + os.getenv('DB_HOST_CPOM') + '/' + os.getenv('DB_BASE_CPOM') + '?driver=ODBC+Driver+17+for+SQL+Server',
        'ssi': 'mssql+pyodbc://' + os.getenv('DB_USER_SSI') + ':' + urllib.parse.quote(os.getenv('DB_PASS_SSI')) + '@' + os.getenv('DB_HOST_SSI') + '/' + os.getenv('DB_BASE_SSI') + '?driver=ODBC+Driver+17+for+SQL+Server',
    }

    #mesa_db_engine = create_engine('sqlite:///' + os.path.join(basedir, '../mesa_controle_bd.db'))
    #mesa_db_engine = create_engine('mysql+pymysql://backbone:CDpwVQq6Xajea8yF@10.40.9.221/mesa_controle', encoding="utf8")
    