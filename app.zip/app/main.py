from flask import Flask
from flask_security import Security, SQLAlchemySessionUserDatastore
from flask_wtf import CsrfProtect
from flask_login import LoginManager

from config import DevelopmentConfig
#from config import mesa_db_engine
from models import db, User, Role

from modules.authentication import auth_bp
from modules.topology import topology_bp
from modules.idrota import idrota_bp
from modules.inventario import inventario_bp
from modules.per import per_bp
from modules.uplinks import uplinks_bp
from modules.falhas import falhas_bp
from modules.etps import etps_bp
from modules.fibrados import fibrados_bp
from modules.b2b import b2b_bp
from modules.spammonitor import spam_monitor_bp

app = Flask(__name__)

app.config.from_object(DevelopmentConfig)

csrf = CsrfProtect()
csrf.exempt("modules.etps.ajax_etp_atributos")
csrf.exempt("modules.etps.ajax_etp_new")

login_manager = LoginManager()
login_manager.login_view = 'authentication.login'
user_datastore = SQLAlchemySessionUserDatastore(db, User, Role)
security = Security(app, user_datastore)

csrf.init_app(app)
login_manager.init_app(app)
db.init_app(app)

app.register_blueprint(auth_bp)
app.register_blueprint(topology_bp)
app.register_blueprint(idrota_bp)
app.register_blueprint(inventario_bp)
app.register_blueprint(per_bp)
app.register_blueprint(uplinks_bp)
app.register_blueprint(falhas_bp)
app.register_blueprint(etps_bp)
app.register_blueprint(fibrados_bp)
app.register_blueprint(b2b_bp)
app.register_blueprint(spam_monitor_bp)


@login_manager.user_loader
def load_user(id):
    return User.query.get(id)


if __name__ == '__main__':
    with app.app_context():
        #db.create_all()
        db.create_all(bind=['portaltx'])
    #app.run(port=80)
    app.run()
