var idsOtssExcel = new Array(0);
var idsOtssFields = new Object();

function ajax_otss(map){
    if(event.keyCode == 13){

        txtOtss = document.getElementById("txtSearchOts").value;
        filtroOtss = 'OTS';
        titleOtss = 'OTS';

        document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

        if(markersOts.length==0){
            initZoom(map);
        }

        var ids = "'" + txtOtss.split(" ").join("', '") + "'";
        var idsC = txtOtss;

        $.ajax({
            url: '/ajax-idrota',
            data: {
              ids_form: String(ids),
              ids_form_c: String(idsC),
              filtro: String(filtroOtss)
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                document.getElementById("progress").innerHTML = "";
                if(response['idsRota'].length == 0){
                    swal("", "Nenhum elemento encontrado na pesquisa!!", "warning", {buttons: false, timer: 1500});
                    //alert("Nenhum idRota encontrado!!!");
                } else {
                    idsOtssExcel = idsOtssExcel.concat(response['idsRotaExcel']);
                    idsOtssFields = response['idsRotaFields'];
                    addOtssTopology(titleOtss, ids, filtroOtss, response['idsRota'], response['idsRotaOMS'], map, markersOts.length);
                    document.getElementById("txtSearchOts").value = "";
                }
            },
            error: function(error){
                document.getElementById("progress").innerHTML = "";
                swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                //alert("Nenhum idRota encontrado!!!");
            }
        });

    }
}

function addOtssTopology(title, ids, filtro, idsFilters, idsFiltersCoordinates, map, status){

    if(status>0){
        for(var c=0; c<idsFilters.length; c++){
            oms = idsFiltersCoordinates.filter(function(obj){return obj.idRota == idsFilters[c].idRota});
            //color = (filtro == 'OMS' || filtro == 'OTS') ? '#696969' : '#'+Math.floor(Math.random()*16777215).toString(16);
            color = '#696969';

            for(var i=0; i<oms.length; i++){
                createMarkerFilters(oms[i], map, idsFilters[c].SiteA, idsFilters[c].SiteB);
                createLineFilters(oms[i], idsFilters[c].idRota, color, map);
            };

            var table = document.getElementById("tbOtss");
            var row = table.insertRow(0);
            row.setAttribute('id',idsFilters[c].idRota);
            row.style.color = color;
            row.classList.add('0');

            row.insertCell(0).innerHTML = '<input class="form-check-input" type="checkbox" checked id="'+idsFilters[c].idRota+'" value="'+idsFilters[c].idRota+'" onclick="showOtss(this, '+idsFilters[c].idRota+', \''+idsFilters[c].SiteA+'\', \''+idsFilters[c].SiteB+'\')">';
            row.insertCell(1).innerHTML = idsFilters[c].idRota;
            row.insertCell(2).innerHTML = idsFilters[c].SiteA;
            row.insertCell(3).innerHTML = idsFilters[c].SiteB;
            row.insertCell(4).innerHTML = idsFilters[c].Latencia.toFixed(3) * 2;
            row.insertCell(5).innerHTML = '<span style="cursor:pointer" onclick="changeColor(' + idsFilters[c].idRota + ')">***</span>';
        }
    } else {
        var html_table = '<table class="table table-borderless table-sm"><thead>';

        html_table = html_table + '<tr>';
        html_table = html_table + '<th colspan="6" scope="col">';
        html_table = html_table + '<button type="button" class="btn btn-outline-dark btn-sm btn-block" onclick="CleanOtss()">Limpar</button>';
        html_table = html_table + '</th>';
        html_table = html_table + '</tr>';

        html_table = html_table + '<tr><th scope="col"></th>';
        html_table = html_table + '<th scope="col">' + title + '</th>';
        html_table = html_table + '<th scope="col">Site A</th><th scope="col">Site B</th>';
        html_table = html_table + '<th scope="col">Latencia (RTD)</th>';
        html_table = html_table + '<th scope="col">Cor</th>';


        html_table = html_table + '</tr></thead><tbody id="tbOtss">';
        for(var c=0; c<idsFilters.length; c++){
            oms = idsFiltersCoordinates.filter(function(obj){return obj.idRota == idsFilters[c].idRota});
            //color = (filtro == 'OMS' || filtro == 'OTS') ? '#696969' : '#'+Math.floor(Math.random()*16777215).toString(16);
            color = '#696969';

            for(var i=0; i<oms.length; i++){
                createMarkerFilters(oms[i], map, idsFilters[c].SiteA, idsFilters[c].SiteB);
                createLineFilters(oms[i], idsFilters[c].idRota, color, map);
            };

            html_table = html_table + '<tr id="' + idsFilters[c].idRota + '" style="color:' + color + ';" class="0" >';

            html_table = html_table + '<td><input class="form-check-input" type="checkbox" checked id="'+idsFilters[c].idRota+'" value="'+idsFilters[c].idRota+'" onclick="showOtss(this, '+idsFilters[c].idRota+', \''+idsFilters[c].SiteA+'\', \''+idsFilters[c].SiteB+'\')"></td>';
            html_table = html_table + '<td>' + idsFilters[c].idRota + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].SiteA + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].SiteB + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].Latencia.toFixed(3) * 2 + '</td>';
            html_table = html_table + '<td><span style="cursor:pointer" onclick="changeColor(' + idsFilters[c].idRota + ')">***</span></td>';
            html_table = html_table + '</tr>';
        }
        html_table = html_table + '</tbody></table>';
        document.getElementById("otssLegend").innerHTML+=html_table;

        var html = '<table>' +
            '<tr>' +
            '<td align="left" width="80">Detalhes: </td>' +
            '<td align="left" width="20">' +
            '<a id="detalhesIdRota" onclick="geraXLS(idsOtssExcel, idsOtssFields)"><span style="cursor:pointer"><i class="material-icons">archive</i></span></a>' +
            '</td>' +
            '</tr>'+
            '</table>'
        document.getElementById("otssLegend").innerHTML+=html;
    }

    function createMarkerFilters(coord, map, ptA, ptB){
        labelA = null;
        labelB = null;

        if(coord.SiteA + '-' + coord.UFA == ptA || coord.SiteA + '-' + coord.UFA == ptB) labelA = coord.SiteA + '.' + coord.UFA;
        if(coord.SiteB + '-' + coord.UFB == ptA || coord.SiteB + '-' + coord.UFB == ptB) labelB = coord.SiteB + '.' + coord.UFB;

        var markerA = new google.maps.Marker({
            label: labelA,
            site: coord.SiteA + '.' + coord.UFA,
            title: coord.SiteA + '.' + coord.UFA + ' (idRota: ' + coord.idRota + ')',
            icon: {
                //url: iconBase + '/vendor/ECI/TOADM.png',
                url: iconBase + '/vendor/'+ coord.FabricanteA +'/'+ coord.ReleaseHWA +'.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            label: labelB,
            site: coord.SiteB + '.' + coord.UFB,
            title: coord.SiteB + '.' + coord.UFB + ' (idRota: ' + coord.idRota + ')',
            icon: {
                //url: iconBase + '/vendor/ECI/TOADM.png',
                url: iconBase + '/vendor/'+ coord.FabricanteB +'/'+ coord.ReleaseHWB +'.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        if(!(markerA.label == null)){
            markersOtsPt.push(markerA);
        } else {
            markerA.addListener('click', function() {
              if(markerA.label == null){
                markerA.setLabel(markerA.site);
              } else  {
                markerA.setLabel(null);
              }
            });
        }

        if(!(markerB.label == null)){
            markersOtsPt.push(markerB);
        } else {
            markerB.addListener('click', function() {
              if(markerB.label == null){
                markerB.setLabel(markerB.site);
              } else  {
                markerB.setLabel(null);
              }
            });
        }

        markersOts.push(markerA);
        markersOts.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLineFilters(coord, id, color, map){

        iconLine = []
        if(coord.Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 3,
            icons: iconLine,
            idRota: id
        })

        addListenerVendors(line, {'LatitudeA': Number(coord.LatitudeA),
                                  'LongitudeA': Number(coord.LongitudeA),
                                  'LatitudeB': Number(coord.LatitudeB),
                                  'LongitudeB': Number(coord.LongitudeB)})
        linesOts.push(line);
        line.setMap(map);
    }
}

function labelOtss(map, condition){
    if(condition){
        for (var i = 0; i < markersOts.length; i++){
            markersOts[i].setLabel(markersOts[i].site);
        }
    } else {
        for (var i = 0; i < markersOts.length; i++){
            markersOts[i].setLabel(null);
        }
        for (var i = 0; i < markersOtsPt.length; i++){
            markersOtsPt[i].setLabel(markersOtsPt[i].site);
        }
    }
}

function CleanOtss(){
    document.getElementById("otssLegend").innerHTML = "";
    document.getElementById("txtSearchOts").value = "";
    addMarkers(markersOts, null);
    addNetworkCoordinates(linesOts, null);

    markersOts = new Array(0);
    linesOts = new Array(0);
    markersOtsPt = new Array(0);

    idsOtssExcel = new Array(0);
    idsOtssFields = new Object();

    initZoom(map);
}

function changeColor(id){
    colors = {
      0: "#696969",
      1: "#00008B",
      2: "#228B22",
      3: "#FF8C00",
      4: "#8B008B",
      5: "#8B0000"
    }
    colorNow = parseInt(document.getElementById(id).className);
    colorNow = (colorNow === 5) ? 0 : colorNow+1;
    document.getElementById(id).className = colorNow
    document.getElementById(id).style.color = colors[colorNow];

    lines = linesOts.filter(function(obj){return obj.idRota == id});
    for(var i=0; i<lines.length; i++){
        lines[i].setOptions({strokeColor: colors[colorNow]});
    };
}

function showOtss(cb, id, siteA, siteB){
    var visible;
    var ptA = siteA.replace('-', '.') + ' (idRota: ' + String(id) + ')';
    var ptB = siteB.replace('-', '.') + ' (idRota: ' + String(id) + ')';

    if(cb.checked){
        visible = map;
    } else {
        visible = null;
    }

    addMarkers(markersOts.filter(function(obj){return obj.title == ptA || obj.title == ptB}), visible);
    addNetworkCoordinates(linesOts.filter(function(obj){return obj.idRota == id}), visible);
}