// @Author: Rodolfo Castanho - Maio/2019
function defineMarkers(loc, changeSize=0){
    var markers = [];

    for(var i=0; i<loc.length; i++){
        var icon = {
            url: iconBase + '/vendor/' + loc[i].Fabricante + '/' + loc[i].ReleaseHW + '.png',
            labelOrigin: new google.maps.Point(0, -4)
        }
        if(changeSize>0){
            icon.scaledSize = { height: changeSize, width: changeSize };
            icon.url = iconBase + '/vendor/Outros/Outros.png';
            icon.opacity = 0.2;
        }

        var marker = new google.maps.Marker({
            /*
            label: {
                text: loc[i].Site + '.' + loc[i].UF,
                color: 'black',
                fontSize: "8px"
            },
            */
            label: null,
            site: loc[i].Site,
            uf: loc[i].UF,
            title: loc[i].Site + '.' + loc[i].UF + ' (' + loc[i].ReleaseHW + ' ' + loc[i].Fabricante + ')',
            lat: loc[i].Latitude,
            lng: loc[i].Longitude,
            icon: icon,
            vendor: loc[i].Fabricante,
            position: new google.maps.LatLng(loc[i].Latitude, loc[i].Longitude)
        });

        addClickMarker(marker);

        markers.push(marker);
    };

    return markers;
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

var lineSymbol = {
    path: 'M 0,-1 0,1',
    //strokeOpacity: 1,
    strokeColor: '#DCDCDC',
    scale: 4
};

function defineNetworkCoordinates(coordinates, lineColor, lineStrokeWeight, lineStrokeOpacity){
    var networkCoordinates = [];

    for(var i=0; i<coordinates.length; i++){
        iconLine = []
        if(coordinates[i].Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coordinates[i].LatitudeA), 'lng': Number(coordinates[i].LongitudeA)}, {'lat': Number(coordinates[i].LatitudeB), 'lng': Number(coordinates[i].LongitudeB)}],
            geodesic: true,
            strokeColor: lineColor,
            strokeOpacity: lineStrokeOpacity,
            strokeWeight: lineStrokeWeight,
            vendor: coordinates[i].FabricanteA,
            icons: iconLine,
            originCoordinate: coordinates[i]
        });

        addListener(line, coordinates[i]);
        networkCoordinates.push(line);

    }
    return networkCoordinates;
}

function addListener(line, coordinate){
    line.addListener('click', function() {
        //showInfoOms(coordinate.LatitudeA, coordinate.LongitudeA, coordinate.LatitudeB, coordinate.LongitudeB);
        showDetailsOms(coordinate.LatitudeA, coordinate.LongitudeA, coordinate.LatitudeB, coordinate.LongitudeB);
    });   
}

function addClickMarker(marker){
    marker.addListener('click', function() {
      if(marker.label == null){
        marker.setLabel({text: marker.site + '.' + marker.uf, fontWeight: 'bold', color: '#363636'});
      } else  {
        marker.setLabel(null);
      }
    });
}

function addNetworkCoordinates(networkCoordinates, visible){
    for(var i=0; i<networkCoordinates.length; i++){
        networkCoordinates[i].setMap(visible);
    }
}

function createLegendTitle(legend){
    var div = document.createElement('div');
    div.innerHTML = '<h7>Legenda</h7>';
    legend.appendChild(div);
}

function createLegend(icons, legend, checkbox){
    for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var vendor = type.vendor;
        var div = document.createElement('div');
        var checkboxDiv = "";
        //div.innerHTML = '<img src="' + icon + '"> ' + name;
        if(checkbox){
        checkboxDiv = '' +
        '<div class="form-check">' +
        '<label class="form-check-label" for="' + vendor + '">&nbsp;</label>' +
        '<input class="form-check-input" type="checkbox" id="' + vendor + '" checked="checked" value="' + vendor + '" onclick="layerVisible(this)">' +
        '</div>'
        }

        var html = '<table>' +
        '<tr>' +
        '<td align="center" width="20"><img src="' + icon + '"></td>' +
        '<td align="left" width="80">' + name + '</td>' +
        '<td align="left" width="20">' +
        checkboxDiv +
        '</td>' +
        '</tr>' +
        '</table>'
        div.innerHTML = html; 
        legend.appendChild(div);
    }
}

function createShowSites(legend){
    var html = '<table>' +
    '<tr>' +
    '<td align="center" width="20"></td>' +
    '<td align="left" width="80">Todos os Sites</td>' +
    '<td align="left" width="20">' +
    '<div class="form-check">' +
    '<label class="form-check-label" for="marcadores">&nbsp;</label>' +
    '<input class="form-check-input" type="checkbox" id="marcadores" checked="checked" value="marcadores" onclick="layerVisible(this)">' +
    '</div>' +
    '</td>' +
    '</tr>' +
    '</table>'
    var div = document.createElement('div');
    div.innerHTML = html;
    legend.appendChild(div);
}

function createShowLabel(legend){
    var html = '<table><tr>' +
        '<td align="center" width="80">Labels</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="showLabel(map)">add</i></a>' +
        '</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="hideLabel(map)">remove</i></a>' +
        '</td>' +
        '</tr></table>'
        var div = document.createElement('div');
        div.innerHTML = html;
        legend.appendChild(div);
}

function createLineLegend(legend){
    var div = document.createElement('div');
    //div.innerHTML = '<hr>';
    div.innerHTML = '<table><tr><td colspan="3">&nbsp</td></tr>';
    legend.appendChild(div);
}

function createSearchSite(legend){
    var div = document.createElement('div');
    var html = '' +
    '<div class="form-group">' +
    '<input id="txtSearchSiteByName" type="text" class="validate" onkeydown="searchSiteByName(this, map)" placeholder="Busca por site">' +
    '</div>'

    //'<input size="17" type="text" id="txtSearchSiteByName" placeholder="Busca por site" onkeydown="searchSiteByName(this, map)"/>'
    div.innerHTML = html;
    legend.appendChild(div);
    //autocomplete(document.getElementById("txtSearchSiteByName"), [document.getElementById("sites").value]);
    autocomplete(document.getElementById("txtSearchSiteByName"), sites);
}

function createCustomControls(customControls){
    var div = document.createElement('div');
    var html = '' +
    //'<img id="reportIcon" src="img/icons/report.png" alt="Resumo" onclick="showReport(map, report)">' +
    //'<hr>' +
    '<img id="zoomIcon" src="static/map/img/icons/zoom.png" alt="Visão Geral" onclick="initZoom(map)">'
    div.innerHTML = html;
    customControls.appendChild(div);
}

function createMenuFloat(menuFloat){
    var div = document.createElement('div');
    var html = '' +
    '<div class="dropdown">' +
    '<button class="btn btn-sm" type="button" id="menuMap" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' +
    '<i class="material-icons text-danger">menu</i>' +
    '</button>' +
    '<div class="dropdown-menu" aria-labelledby="menuMap">' +
    '<a style="cursor:pointer" class="dropdown-item" title="Topologia" onclick="floatClick(this, map)"><i class="material-icons text-primary">location_on</i> Topologia</a>' +
    '<a style="cursor:pointer" class="dropdown-item" title="IdRota" onclick="floatClick(this, map)"><i class="material-icons text-success">compare_arrows</i> Filtros</a>' +
    '<a style="cursor:pointer" class="dropdown-item" title="PER" onclick="floatClick(this, map)"><i class="material-icons text-warning">border_clear</i> PER</a>' +
    '</div>' +
    '</div>'
    div.innerHTML = html;
    menuFloat.appendChild(div);
}

function createSearchIdRota(idRota){
    var div = document.createElement('div');
    var html = '' +
    '<h7>Filtros</h7><hr>' +
    '<div class="form-group">' +
    '<input id="txtSearchIdRota" type="text" class="validate" onkeydown="ajax_idRota(map)" placeholder="...separados por espaço...">' +
    '<p>' +
    '<p>' +
    'Tipo: ' +
    '<select id="selectIdRota" class="validate" onkeydown="ajax_idRota(map)">' +
    '<option value="NumEILD">EILD(s)</option>' +
    '<option value="idRota">idRota(s)</option>' +
    '<option value="OE">OE(s)</option>' +
    '<option value="OMS">OMS(s)</option>' +
    '<option value="OCH">OCH(s)</option>' +
    '<option value="ODU">ODU(s)</option>' +
    //'<option value="SiglaRota">Sigla(s) Rota</option>' +
    '</select>' +
    '</div>' +
    '<div id="idRotaLegend">' +
    '</div>'
    div.innerHTML = html;
    idRota.appendChild(div);
}

//TOPOLOGIA IDROTA
function addIdRotaTopology(title, ids, filtro, idsRota, idsRotaCoordinates, map){

    markersIdRota = [];
    networkCoordinatesIdRota = [];
    markersIdRotaPt = [];

    var html_table = '<table class="table table-borderless table-sm"><thead><tr>';
    html_table = html_table + '<th scope="col">' + title + '</th>';

    if (filtro == 'OE') {
        html_table = html_table + '<th scope="col">Tipo</th><th scope="col"></th>';
    } else {
        html_table = html_table + '<th scope="col">Site A</th><th scope="col">Site B</th>';
    }
    html_table = html_table + '<th scope="col">Latencia (RTD)</th>';

    if (filtro == 'OCH') {
        html_table = html_table + '<th scope="col">Rest. L0</th>';
    } else if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
        html_table = html_table + '<th scope="col">Rest. L1</th>';
        html_table = html_table + '<th scope="col">Rest. L0</th>';
        html_table = html_table + '<th scope="col">Caminho</th>';
    } else if (filtro == 'OMS') {
        html_table = html_table + '<th scope="col">Cor</th>';
    }


    html_table = html_table + '</tr></thead><tbody>';
    for(var c=0; c<idsRota.length; c++){
        if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
            oms = idsRotaCoordinates.filter(function(obj){return obj.idRota == idsRota[c].idRota && obj.Caminho == idsRota[c].Caminho});
        } else {
            oms = idsRotaCoordinates.filter(function(obj){return obj.idRota == idsRota[c].idRota});
        }
        color = (filtro == 'OMS') ? '#696969' : '#'+Math.floor(Math.random()*16777215).toString(16);

        for(var i=0; i<oms.length; i++){
            createMarkerIdRota(oms[i], map, idsRota[c].SiteA, idsRota[c].SiteB);
            createLineIdRota(oms[i], idsRota[c].idRota, color, map);
        };

        if (filtro == 'OMS'){
            html_table = html_table + '<tr id="' + idsRota[c].idRota + '" style="color:' + color + ';" class="0" onclick="changeColor(' + idsRota[c].idRota + ')" >';
        } else {
            html_table = html_table + '<tr id="' + idsRota[c].idRota + '" style="color:' + color + ';" >';
        }

        html_table = html_table + '<td>' + idsRota[c].idRota + '</td>';
        html_table = html_table + '<td>' + idsRota[c].SiteA + '</td>';
        html_table = html_table + '<td>' + idsRota[c].SiteB + '</td>';
        html_table = html_table + '<td>' + idsRota[c].Latencia.toFixed(3) * 2 + '</td>';

        if (filtro == 'OCH') {
            html_table = html_table + '<td>' + idsRota[c].L0 + '</td>';
        } else if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
            html_table = html_table + '<td>' + idsRota[c].L1 + '</td>';
            html_table = html_table + '<td>' + idsRota[c].L0 + '</td>';
            caminho = (idsRota[c].Caminho == 'Alternativo') ? 'P' : 'W';
            html_table = html_table + '<td>' + caminho + '</td>';
        } else if (filtro == 'OMS') {
            html_table = html_table + '<td><span style="cursor:pointer">***</span></td>';
        }

        html_table = html_table + '</tr>';
    }
    html_table = html_table + '</tbody></table>';
    document.getElementById("idRotaLegend").innerHTML+=html_table;

    var html = '<table>' +

        '<tr>' +
        '<td align="left" width="80">Detalhes: </td>' +
        '<td align="left" width="20">' +
        '<a id="detalhesIdRota" onclick="geraXLS(idsRotaExcel, idsRotaFields)"><span style="cursor:pointer"><i class="material-icons">archive</i></span></a>' +
        '</td>' +
        '</tr>'+

        '<tr>' +
        '<td align="left" width="80">Labels</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="labelIdRota(map, true)">add</i></a>' +
        '</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="labelIdRota(map, false)">remove</i></a>' +
        '</td>' +
        '</tr>'+
        '</table>'
    document.getElementById("idRotaLegend").innerHTML+=html;

    function createMarkerIdRota(coord, map, ptA, ptB){
        labelA = null;
        labelB = null;

        if(coord.SiteA + '-' + coord.UFA == ptA || coord.SiteA + '-' + coord.UFA == ptB) labelA = coord.SiteA + '.' + coord.UFA;
        if(coord.SiteB + '-' + coord.UFB == ptA || coord.SiteB + '-' + coord.UFB == ptB) labelB = coord.SiteB + '.' + coord.UFB;

        var markerA = new google.maps.Marker({
            label: labelA,
            site: coord.SiteA + '.' + coord.UFA,
            title: coord.SiteA + '.' + coord.UFA + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            label: labelB,
            site: coord.SiteB + '.' + coord.UFB,
            title: coord.SiteB + '.' + coord.UFB + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        if(!(markerA.label == null)){
            markersIdRotaPt.push(markerA);
        } else {
            markerA.addListener('click', function() {
              if(markerA.label == null){
                markerA.setLabel(markerA.site);
              } else  {
                markerA.setLabel(null);
              }
            });
        }

        if(!(markerB.label == null)){
            markersIdRotaPt.push(markerB);
        } else {
            markerB.addListener('click', function() {
              if(markerB.label == null){
                markerB.setLabel(markerB.site);
              } else  {
                markerB.setLabel(null);
              }
            });
        }

        markersIdRota.push(markerA);
        markersIdRota.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLineIdRota(coord, id, color, map){

        iconLine = []
        if(coord.Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 3,
            icons: iconLine,
            idRota: id
        })

        networkCoordinatesIdRota.push(line);
        line.setMap(map);
    }
}

function createIdRotaControl(map){
    var divIdRota = document.getElementById('legend');
    createSearchIdRota(divIdRota);
    addNetworkCoordinates(networkCoordinatesIdRotaBase, map);
    addMarkers(markersIdRotaBase, map);
    //map.controls[google.maps.ControlPosition.TOP_CENTER].push(divIdRota);
}

// CHAMAR TOPOLOGIA
function createVariables(map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    $.ajax({
        url: '/ajax-topology',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            markers = defineMarkers(response['locations']);
            markersIdRotaBase = defineMarkers(response['locations'], 4);
            networkCoordinates = defineNetworkCoordinates(response['networkTopologyCoordinates'], '#8B8989', 3, 1);
            networkCoordinatesIdRotaBase = defineNetworkCoordinates(response['networkTopologyCoordinates'], '#778899', 1, 0.5);

            document.getElementById("progress").innerHTML = '';

            createTopologyMap(markers, networkCoordinates, map);
        },
        error: function(error){
            console.log(error);

            document.getElementById("progress").innerHTML = '';
        }
    });
}



function createTopologyMap(markers, networkCoordinates, map){
// Call functions

    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    //Controls********************************************************************
    var legend = document.getElementById('legend');
    createLegendTitle(legend);
    createLineLegend(legend);
    createLegend(iconsEquip, legend, false);
    createLineLegend(legend);
    createLegend(iconsVendor, legend, true);
    createLineLegend(legend);
    createShowSites(legend);
    createLineLegend(legend);
    createLegend(iconsLink, legend, false)
    createLineLegend(legend);
    createShowLabel(legend);
    createLineLegend(legend);
    createSearchSite(legend);

    addMarkers(markers, map);
    addNetworkCoordinates(networkCoordinates, map);

    document.getElementById("progress").innerHTML = '';
}

//TOPOLOGIA PER
function createPerTopology(map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    $.ajax({
        url: '/ajax-per',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            perCoordinates = response['per'];

            var perDiv = document.createElement('div');
            perDiv.id = 'per';
            createPerDiv(perDiv);
            perDiv.setAttribute('class', 'w-50');
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(perDiv);

            var perSelected;
            var perTopology;

            $.extend( true, $.fn.dataTable.defaults, {
                retrieve: true,
                lengthChange: false,
                paging: false,
                info: false
            } );

            $( "#accordionPer" ).on("shown.bs.collapse", function() {
                $.each($.fn.dataTable.tables(true), function(){
                $(this).DataTable().columns.adjust().draw();
                });
            });

            var table = $('#tablePer').DataTable({
                data: perCoordinates,
                columns: [
                    { title: '', defaultContent: '' },
                    { title: 'PER', data: 'Per' },
                    { title: 'Id Rota', data: 'IdRota' },
                    { title: 'Propriedade Fibra', data: 'PropriedadeFibra' },
                    { title: 'Site A', data: 'SiteA' },
                    { title: 'Site B', data: 'SiteB' }
                ],
                columnDefs: [{
                    orderable: false,
                    targets: [0, 2, 3]
                }, {
                    targets: [1],
                    orderData: [1, 2]
                }, {
                    targets: [4],
                    orderData: [4, 5]
                }, {
                    targets: 0,
                    checkboxes: {
                        selectRow: true
                    }
                }],
                select: {
                    style: 'multi'
                },
                scrollY: '400px',
                scrollCollapse: true,
                language: {
                    //url: "http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
                    search: 'Pesquisar:',
                    zeroRecords: 'Nenhum registro encontrado...'
                },
                dom: 'Bfrtip',
                select: true,
                buttons: [
                    {
                        text: 'Plotar PER(s) selecionados',
                        action: function () {
                            perSelected = table.rows( { selected: true } );
                            perTopology = [];

                            if(perSelected.count() == 0){
                                alert("Nenhuma Rota PER selecionada...")
                            } else {
                                for(i=0; i<perSelected.count(); i++){
                                    perTopology.push(perSelected.data()[i]);
                                }
                                //chama função para plotar
                                addPerTopology(perTopology, map);
                                //fecha accordion
                                document.getElementById("btnSelectPer").click();
                            }
                        }
                    }
                ]
            });
            //document.getElementById("collapsePer").setAttribute('class', 'collapse w-100');
            perDiv.setAttribute('class', 'w-100');
            perDiv.setAttribute('class', 'w-50');
            document.getElementById("progress").innerHTML = '';
        },
        error: function(error){
            console.log(error);
            document.getElementById("progress").innerHTML = '';
        }
    });
}

function createPerDiv(perDiv){
    var html = '' +
    '<div class="accordion" id="accordionPer">' +
    '<div class="card">' +
    '<div class="card-header" id="headingPer">' +
    '<h2 class="mb-0">' +
    //'<button id="btnSelectPer" class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsePer" aria-expanded="false" aria-controls="collapsePer">' +
    '<button id="btnSelectPer" class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapsePer" aria-expanded="true" aria-controls="collapsePer">' +
    'Topologia PER' +
    '</button>' +
    '<a class="close" href="#!">' +
    '<i class="material-icons" onclick="hidePer()">close</i>' +
    '</a>' +
    '</h2>' +
    '</div>' +
    //'<div id="collapsePer" class="collapse" aria-labelledby="headingPer" data-parent="#accordionPer">' +
    '<div id="collapsePer" class="collapse show" aria-labelledby="headingPer" data-parent="#accordionPer">' +
    '<div class="card-body">' +
    '<table id="tablePer" class="display compact card-table table"></table>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'
    perDiv.innerHTML = html;
}

function hidePer(){
   if(markersPer != undefined){
        addMarkers(markersPer, null);
        addNetworkCoordinates(networkCoordinatesPer, null);
    }
    document.getElementById("per").innerHTML = "";
    map.controls[google.maps.ControlPosition.TOP_CENTER].pop(document.getElementById('per'));
    perCoordinates = [];
    markersPer = [];
    networkCoordinatesPer = [];
}

function addPerTopology(idsPerCoordinates, map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    if(markersPer != undefined){
        addMarkers(markersPer, null);
        addNetworkCoordinates(networkCoordinatesPer, null);
    }

    markersPer = [];
    networkCoordinatesPer = [];
    color = '#EE0000';

    for(var i=0; i<idsPerCoordinates.length; i++){
        createMarkerPer(idsPerCoordinates[i], map);
        createLinePer(idsPerCoordinates[i], color, map);
    }

    function createMarkerPer(coord, map){
        var scaleIcon = 8;

        var markerA = new google.maps.Marker({
            //label: coord.SiteA,
            title: coord.SiteA,
            icon: {
                url: iconBase + '/vendor/Outros/PER.png',
                scaledSize: { height: scaleIcon, width: scaleIcon }
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            //label: coord.SiteB,
            title: coord.SiteB,
            icon: {
                url: iconBase + '/vendor/Outros/PER.png',
                scaledSize: { height: scaleIcon, width: scaleIcon }
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        markersPer.push(markerA);
        markersPer.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLinePer(coord, color, map){
        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 1.5
        })

        networkCoordinatesPer.push(line);
        line.setMap(map);
    }

    document.getElementById("progress").innerHTML = '';
}

