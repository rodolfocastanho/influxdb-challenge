function OtsUpdateCreate(ots){
    document.getElementById('slcOts-' + ots).style.display = 'block';
    document.getElementById('spanOts-' + ots).style.display = 'none';
    document.getElementById('btGravaOts-' + ots).style.display = 'block';
    document.getElementById('inputOtsEdit-' + ots).style.display = 'none';
}

function saveOtsUpdate(ots){
    var otssList = document.getElementById('hidOts-' + ots).value + '|' + document.getElementById('slcOts-' + ots).value;

    $.ajax({
        url: '/ajax-etp-update-ots',
        type: 'GET',
        data: {
            otss: otssList,
            etp: ''
        },
        //contentType: 'application/json',
        success: function(response){
            document.getElementById('slcOts-' + ots).style.display = 'none';
            document.getElementById('spanOts-' + ots).style.display = 'block';
            document.getElementById('btGravaOts-' + ots).style.display = 'none';
            document.getElementById('inputOtsEdit-' + ots).style.display = 'block';
            document.getElementById('spanOts-' + ots).textContent = document.getElementById('slcOts-' + ots).value;

            linesVendors.filter(function(obj){
                return (obj.originCoordinate.idWDMOTS == ots)
            })[0].originCoordinate.PropriedadeFibra = document.getElementById('slcOts-' + ots).value
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao atualizar as OTSs!", "error");
        }
    });
}

