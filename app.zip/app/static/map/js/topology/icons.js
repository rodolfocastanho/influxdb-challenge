// @Author: Rodolfo Castanho - Maio/2019

var iconBase = 'static/map/img/icons/';
var iconsVendor = {
    ciena: {
        name: 'Ciena',
        icon: iconBase + 'vendor/ciena.png',
        vendor: 'Ciena'
    },
    coriant: {
        name: 'Coriant',
        icon: iconBase + 'vendor/coriant.png',
        vendor: 'Coriant'
    },
    huawei: {
        name: 'Huawei',
        icon: iconBase + 'vendor/huawei.png',
        vendor: 'Huawei'
    },
    nokia: {
        name: 'Nokia',
        icon: iconBase + 'vendor/nokia.png',
        vendor: 'Nokia'
    },
    padtec: {
        name: 'Padtec',
        icon: iconBase + 'vendor/padtec.png',
        vendor: 'Padtec'
    },
    eci: {
        name: 'ECI',
        icon: iconBase + 'vendor/eci.png',
        vendor: 'ECI'
    }
};

var iconsEquip = {
    foadm: {
        name: 'FOADM',
        icon: iconBase + 'equip/FOADM.png'
    },
    roadm: {
        name: 'ROADM',
        icon: iconBase + 'equip/ROADM.png'
    },
    toadm: {
        name: 'TOADM',
        icon: iconBase + 'equip/TOADM.png'
    },
    ola: {
        name: 'OLA',
        icon: iconBase + 'equip/OLA.png'
    },
    outros: {
        name: 'Outros',
        icon: iconBase + 'equip/OUTROS.png'
    }
};

var iconsLink = {
    ativo: {
        name: 'Link Ativo',
        icon: iconBase + 'link/Ativo.png'
    },
    Planejado: {
        name: 'Link Planejado',
        icon: iconBase + 'link/Planejado.png'
    }
};