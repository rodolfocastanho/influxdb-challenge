function createScienceDiv(scienceDiv){
    ufs = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB',
          'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO'];

    html = '' +
    '<table>' +
    '<thead>' +
    '<tr>' +
    '<th scope="col">Base</th>' +
    //'<th scope="col">Planejados</th>' +
    '<th scope="col">|</th>' +
    '<th scope="col">Science</th>'
    for(i=0; i<ufs.length; i++){
        html = html + '<th scope="col">' + ufs[i] + '</th>';
    }
    html = html +
    '</tr>' +
    '</thead>' +
    '<tbody>' +
    '<tr>' +
    '<td>' +
    '<div class="form-check">' +
    '<label class="form-check-label" for="Base">&nbsp;</label>' +
    '<input class="form-check-input" type="checkbox" checked="checked" id="Base" value="base" onclick="layerVisible(this)">' +
    '</div>' +
    '</td>' +
    /*
    '<td>' +
    '<div class="form-check">' +
    '<label class="form-check-label" for="BasePlanejados">&nbsp;</label>' +
    '<input class="form-check-input" type="checkbox" id="BasePlanejados" value="basePlanejados" onclick="layerVisibleBase(this)">' +
    '</div>' +
    '</td>' +
    */
    '<td>|</td>' +
    '<td></td>'
    for(i=0; i<ufs.length; i++){
        var checkUf = '' +
        '<div class="form-check">' +
        '<label class="form-check-label" for="' + ufs[i] + '">&nbsp;</label>' +
        '<input class="form-check-input" type="checkbox" id="' + ufs[i] + '" value="' + ufs[i] + '" onclick="showScience(this)">' +
        '</div>'
        html = html + '<td>' + checkUf + '</td>';
    }
    '</tr>' +
    '</tbody>' +
    '</table>'

    document.getElementById('ufs').innerHTML = html;
}

function showScience(cb){
    if(cb.checked){
        if(tempScience.includes(cb.value)){
            addMarkers(markersScience.filter(function(obj){return obj.uf == cb.value}), map);
        } else {
            tempScience.push(cb.value)
            createScienceMarker(map, cb.value);
        }
    } else {
        addMarkers(markersScience.filter(function(obj){return obj.uf == cb.value}), null);
    }
}

function createScienceMarker(map, ufCheck){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    $.ajax({
        url: '/ajax-science',
        type: 'GET',
        data: {
              uf: String(ufCheck)
            },
        contentType: 'application/json',
        success: function(response){
            markersScienceTemp = defineMarkers(response['marker'], 8, 'science', 1, baseIcon=false);
            addMarkers(markersScienceTemp, map);
            markersScience = markersScience.concat(markersScienceTemp);

            document.getElementById("progress").innerHTML = '';
        },
        error: function(error){
            console.log(error);
            document.getElementById("progress").innerHTML = '';
        }
    });
}

function createScienceMarkerFilter(map, site){
    var siteSigla = site.split('.')[0];
    var siteUf = site.split('.')[1];

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    var checkScience = document.getElementById(siteUf);

    async function sleepClick(checkScience){
        if(!checkScience.checked){
            await checkScience.click();
            await sleep(3000);
        }
        var siteScience = markersScience.find(function(obj){return obj.site == siteSigla && obj.uf == siteUf});
        var noClickSiteScience = markersScience.filter(function(obj){return obj.site + '.' + obj.uf  !== siteSigla + '.' + siteUf});

        map.setCenter(new google.maps.LatLng(siteScience["lat"], siteScience["lng"]));
        map.setZoom(30);
        siteScience.setLabel({text: siteScience.site+'.'+siteScience.uf, fontSize: '12px', color: '#363636'});

        addMarkers(noClickSiteScience, null);
        checkScience.checked = false;
    }
    sleepClick(checkScience);
}

function layerVisibleBase(cb){
    var visible;

    if(cb.checked){
        visible = map;
    } else {
        visible = null;
    }

    if(cb.value === 'base'){
        addMarkers(markersBase, visible);
        //addNetworkCoordinates(linesBase.filter(function(obj){return obj.statusLink !== 'Planejado'}), visible);
        addNetworkCoordinates(linesBase, visible);
    } else if (cb.value === 'basePlanejados'){
        addNetworkCoordinates(linesBase.filter(function(obj){return obj.statusLink == 'Planejado'}), visible);
    }

}