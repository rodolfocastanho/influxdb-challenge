function createCustomControls(customControls){
    var div = document.createElement('div');
    var html = '' +
    '<img id="zoomIcon" src="static/map/img/icons/zoom.png" alt="Visão Geral" onclick="initZoom(map)">'
    div.innerHTML = html;
    customControls.appendChild(div);
}

function initZoom(map){
    map.setCenter(new google.maps.LatLng(-15.7797203, -47.9297218));
    map.setZoom(5);
    //hideLabel(map);
}

function changeControlsApiStyle(){
    document.getElementsByClassName('gm-fullscreen-control')[0].style.border='1px solid #778899';
    document.getElementsByClassName('gm-fullscreen-control')[0].style.borderRadius='5px';
    document.getElementsByClassName('gm-fullscreen-control')[0].style.boxShadow='3px 3px 3px #888888';
}

function createBasesTopology(map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';
    $.ajax({
        url: '/ajax-topology',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            markersBase = defineMarkers(response['locationsOts'], 6, 'base', 0.5, true);
            linesBase = defineNetworkCoordinates(response['networkTopologyCoordinatesOts'], 'base', 1, 0.5, 4);
            markersVendors = defineMarkers(response['locationsOts'], 12, 'vendors', 1, false);
            linesVendors = defineNetworkCoordinates(response['networkTopologyCoordinatesOts'], 'vendors', 3, 1, 4);
            markersCamadasHL = defineMarkers(response['locationsHl'], 14, 'router', 1, false);

            addMarkers(markersBase, map);
            //addNetworkCoordinates(linesBase.filter(function(obj){return obj.statusLink !== 'Planejado'}), map);
            addNetworkCoordinates(linesBase, map);

            autocomplete(document.getElementById("txtSearchSiteByName"), sites);
            autocomplete(document.getElementById("txtSearchOts"), siglasOts);

            document.getElementById("progress").innerHTML = "";
        },
        error: function(error){
            console.log(error);
            document.getElementById("progress").innerHTML = "";
        }
    });

}