// @Author: Rodolfo Castanho - Maio/2019

var map;
var markersBase;
var linesBase;
var markersVendors;
var linesVendors;
var markersOts = new Array(0);
var markersOtsPt = new Array(0);
var linesOts = new Array(0);
var markersFilters;
var markersFiltersPt;
var linesFilters;
var markersScience = new Array(0);
var tempScience = new Array(0);
var markersCamadasHL;


function initMap() {

    var styledMapType = new google.maps.StyledMapType(
            [{ "elementType": "geometry", "stylers": [ { "color": "#f5f5f5" } ] },
            { "elementType": "geometry.fill", "stylers": [ { "visibility": "simplified" } ] },
            //{ "elementType": "geometry.fill", "stylers": [ { "color": "#FFFAFA" } ] },
            { "elementType": "geometry.stroke", "stylers": [ { "visibility": "on" }, { "weight": 1 } ] },
            { "elementType": "labels.icon", "stylers": [ { "visibility": "off" } ] },
            { "elementType": "labels.text.fill", "stylers": [ { "color": "#9a9a9a" } ] },
            { "elementType": "labels.text.stroke", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [ { "color": "#bdbdbd" } ] },
            { "featureType": "poi", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "poi.park", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "road", "elementType": "geometry", "stylers": [ { "color": "#ffffff" } ] },
            { "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "road.highway", "elementType": "geometry", "stylers": [ { "color": "#dadada" } ] },
            { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [ { "color": "#616161" } ] },
            { "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "transit.line", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "transit.station", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "water", "elementType": "geometry", "stylers": [ { "color": "#c9c9c9" } ] },
            //{ "featureType": "water", "elementType": "geometry.fill", "stylers": [ {"color": "#F0FFFF"} ] },
            { "featureType": "water", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] } ],
            {name: 'Simples'});

    map = new google.maps.Map(document.getElementById('map'), {
      zoom: 5,
      center: new google.maps.LatLng(-15.7797203, -47.9297218), //Brasília
      //mapTypeId: 'roadmap',
      //gestureHandling: 'cooperative',
      streetViewControl: false,
      zoomControl: false,
      fullscreenControl: true,
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain',
                'styled_map']
      }
    });

    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');

    var customControls = document.getElementById('customControls');
    createCustomControls(customControls);
    map.controls[google.maps.ControlPosition.TOP_RIGHT].push(customControls);

    var scienceUfs = document.getElementById('ufs');
    createScienceDiv(scienceUfs);
    map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(scienceUfs);

    map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('legend-minmax'));
    //map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('legend'));
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('infoPolyline'));
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('progress'));

    //changeControlsApiStyle();

    // Base
    createBasesTopology(map);

    // Add a marker clusterer to manage the markers.
    // var markerCluster = new MarkerClusterer(map, markers,{imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});

}

