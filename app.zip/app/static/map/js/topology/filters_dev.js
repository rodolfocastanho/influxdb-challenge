var idsFiltersExcel = new Array(0);
var idsFiltersFields = new Object();

function ajax_idRota(map){
    if(event.keyCode == 13){

        txtFilters = document.getElementById("txtSearchIdRota").value;
        select = document.getElementById("selectIdRota");
        filtroFilters = select.value;
        titleFilters = select.options[select.selectedIndex].text;

        document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

        if(markersFilters.length==0){
            initZoom(map);
        }

        initZoom(map);
        //var ids = txt.split(" ");
        var ids = "'" + txtFilters.split(" ").join("', '") + "'";

        if(markersFilters != undefined){
            addMarkers(markersFilters, null);
            addNetworkCoordinates(linesFilters, null);
        }

        $.ajax({
            url: '/ajax-idrota',
            data: {
              ids_form: String(ids),
              filtro: String(filtroFilters)
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                document.getElementById("progress").innerHTML = "";
                if(response['idsRota'].length == 0){
                    swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                    //alert("Nenhum idRota encontrado!!!");
                } else {
                    idsFiltersExcel = idsOtssExcel.concat(response['idsRotaExcel']);
                    idsFiltersFields = response['idsRotaFields'];
                    addFilterTopology(titleFilters, ids, filtroFilters, response['idsRota'], response['idsRotaOMS'], map, markersFilters.length);
                    document.getElementById("txtSearchIdRota").value = "";
                }
            },
            error: function(error){
                document.getElementById("progress").innerHTML = "";
                swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                //alert("Nenhum idRota encontrado!!!");
            }
        });

    }
}

function addFilterTopology(title, ids, filtro, idsFilters, idsFiltersCoordinates, map, status){

    if(status>0){
        for(var c=0; c<idsFilters.length; c++){
            oms = idsFiltersCoordinates.filter(function(obj){return obj.idRota == idsFilters[c].idRota});
            color = (filtro == 'OMS' || filtro == 'OTS') ? '#696969' : '#'+Math.floor(Math.random()*16777215).toString(16);
            //color = '#696969';

            for(var i=0; i<oms.length; i++){
                createMarkerFilters(oms[i], map, idsFilters[c].SiteA, idsFilters[c].SiteB);
                createLineFilters(oms[i], idsFilters[c].idRota, color, map);
            };

            var table = document.getElementById("tbFilters");
            var row = table.insertRow(0);
            row.setAttribute('id',idsFilters[c].idRota);
            row.style.color = color;
            row.classList.add('0');

            row.insertCell(0).innerHTML = '<input class="form-check-input" type="checkbox" checked id="'+idsFilters[c].idRota+'" value="'+idsFilters[c].idRota+'" onclick="showOtss(this, '+idsFilters[c].idRota+', \''+idsFilters[c].SiteA+'\', \''+idsFilters[c].SiteB+'\')">';
            row.insertCell(1).innerHTML = idsFilters[c].idRota;
            row.insertCell(2).innerHTML = idsFilters[c].SiteA;
            row.insertCell(3).innerHTML = idsFilters[c].SiteB;
            row.insertCell(4).innerHTML = idsFilters[c].Latencia.toFixed(3) * 2;
            row.insertCell(5).innerHTML = '<span style="cursor:pointer" onclick="changeColor(' + idsFilters[c].idRota + ')">***</span>';
        }
    } else {
        var html_table = '<table class="table table-borderless table-sm"><thead>';

        html_table = html_table + '<tr>';
        html_table = html_table + '<th colspan="5" scope="col">';
        html_table = html_table + '<button type="button" class="btn btn-outline-dark btn-sm btn-block" onclick="CleanFilters()">Limpar</button>';
        html_table = html_table + '</th>';
        html_table = html_table + '</tr>';

        html_table = html_table + '<tr><th scope="col">' + title + '</th>';

        if (filtro == 'OE') {
            html_table = html_table + '<th scope="col">Tipo</th><th scope="col"></th>';
        } else {
            html_table = html_table + '<th scope="col">Site A</th><th scope="col">Site B</th>';
        }
        html_table = html_table + '<th scope="col">Latencia (RTD)</th>';

        if (filtro == 'OCH') {
            html_table = html_table + '<th scope="col">Rest. L0</th>';
        } else if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
            html_table = html_table + '<th scope="col">Rest. L1</th>';
            html_table = html_table + '<th scope="col">Rest. L0</th>';
            html_table = html_table + '<th scope="col">Caminho</th>';
        } else if (filtro == 'OMS' || filtro == 'OTS') {
            html_table = html_table + '<th scope="col">Cor</th>';
        }


        html_table = html_table + '</tr></thead><tbody id="tbFilters">';
        for(var c=0; c<idsFilters.length; c++){
            if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
                oms = idsFiltersCoordinates.filter(function(obj){return obj.idRota == idsFilters[c].idRota && obj.Caminho == idsFilters[c].Caminho});
            } else {
                oms = idsFiltersCoordinates.filter(function(obj){return obj.idRota == idsFilters[c].idRota});
            }
            color = (filtro == 'OMS' || filtro == 'OTS') ? '#696969' : '#'+Math.floor(Math.random()*16777215).toString(16);

            for(var i=0; i<oms.length; i++){
                createMarkerFilters(oms[i], map, idsFilters[c].SiteA, idsFilters[c].SiteB);
                createLineFilters(oms[i], idsFilters[c].idRota, color, map);
            };

            if (filtro == 'OMS' || filtro == 'OTS'){
                html_table = html_table + '<tr id="' + idsFilters[c].idRota + '" style="color:' + color + ';" class="0" onclick="changeColor(' + idsFilters[c].idRota + ')" >';
            } else {
                html_table = html_table + '<tr id="' + idsFilters[c].idRota + '" style="color:' + color + ';" >';
            }

            html_table = html_table + '<td>' + idsFilters[c].idRota + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].SiteA + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].SiteB + '</td>';
            html_table = html_table + '<td>' + idsFilters[c].Latencia.toFixed(3) * 2 + '</td>';

            if (filtro == 'OCH') {
                html_table = html_table + '<td>' + idsFilters[c].L0 + '</td>';
            } else if (filtro == 'ODU' || filtro == 'NumEILD' || filtro == 'idRota') {
                html_table = html_table + '<td>' + idsFilters[c].L1 + '</td>';
                html_table = html_table + '<td>' + idsFilters[c].L0 + '</td>';
                caminho = (idsFilters[c].Caminho == 'Alternativo') ? 'P' : 'W';
                html_table = html_table + '<td>' + caminho + '</td>';
            } else if (filtro == 'OMS' || filtro == 'OTS') {
                html_table = html_table + '<td><span style="cursor:pointer">***</span></td>';
            }

            html_table = html_table + '</tr>';
        }
        html_table = html_table + '</tbody></table>';
        document.getElementById("filtersLegend").innerHTML+=html_table;

        var html = '<table>' +

            '<tr>' +
            '<td align="left" width="80">Detalhes: </td>' +
            '<td align="left" width="20">' +
            '<a id="detalhesIdRota" onclick="geraXLS(idsFiltersExcel, idsFiltersFields)"><span style="cursor:pointer"><i class="material-icons">archive</i></span></a>' +
            '</td>' +
            '</tr>'+

            '<tr>' +
            '<td align="left" width="80">Labels</td>' +
            '<td align="left" width="20">' +
            '<a href="#"><i class="material-icons" onclick="labelFilters(map, true)">add</i></a>' +
            '</td>' +
            '<td align="left" width="20">' +
            '<a href="#"><i class="material-icons" onclick="labelFilters(map, false)">remove</i></a>' +
            '</td>' +
            '</tr>'+
            '</table>'
        document.getElementById("filtersLegend").innerHTML+=html;
    }

    function createMarkerFilters(coord, map, ptA, ptB){
        labelA = null;
        labelB = null;

        if(coord.SiteA + '-' + coord.UFA == ptA || coord.SiteA + '-' + coord.UFA == ptB) labelA = coord.SiteA + '.' + coord.UFA;
        if(coord.SiteB + '-' + coord.UFB == ptA || coord.SiteB + '-' + coord.UFB == ptB) labelB = coord.SiteB + '.' + coord.UFB;

        var markerA = new google.maps.Marker({
            label: labelA,
            site: coord.SiteA + '.' + coord.UFA,
            title: coord.SiteA + '.' + coord.UFA + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/ECI/TOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            label: labelB,
            site: coord.SiteB + '.' + coord.UFB,
            title: coord.SiteB + '.' + coord.UFB + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/ECI/TOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        if(!(markerA.label == null)){
            markersFiltersPt.push(markerA);
        } else {
            markerA.addListener('click', function() {
              if(markerA.label == null){
                markerA.setLabel(markerA.site);
              } else  {
                markerA.setLabel(null);
              }
            });
        }

        if(!(markerB.label == null)){
            markersFiltersPt.push(markerB);
        } else {
            markerB.addListener('click', function() {
              if(markerB.label == null){
                markerB.setLabel(markerB.site);
              } else  {
                markerB.setLabel(null);
              }
            });
        }

        markersFilters.push(markerA);
        markersFilters.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLineFilters(coord, id, color, map){

        iconLine = []
        if(coord.Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 3,
            icons: iconLine,
            idRota: id
        })

        addListenerVendors(line, {'LatitudeA': Number(coord.LatitudeA),
                                  'LongitudeA': Number(coord.LongitudeA),
                                  'LatitudeB': Number(coord.LatitudeB),
                                  'LongitudeB': Number(coord.LongitudeB)})
        linesFilters.push(line);
        line.setMap(map);
    }
}

function labelFilters(map, condition){
    if(condition){
        for (var i = 0; i < markersFilters.length; i++){
            markersFilters[i].setLabel(markersFilters[i].site);
        }
    } else {
        for (var i = 0; i < markersFilters.length; i++){
            markersFilters[i].setLabel(null);
        }
        for (var i = 0; i < markersFiltersPt.length; i++){
            markersFiltersPt[i].setLabel(markersFiltersPt[i].site);
        }
    }
}

function CleanFilters(){
    document.getElementById("filtersLegend").innerHTML = "";
    document.getElementById("txtSearchIdRota").value = "";
    addMarkers(markersFilters, null);
    addNetworkCoordinates(linesFilters, null);
    initZoom(map);
}

function geraXLS (datas, fields){
    orderedData = orderExcelObject(datas, Object.values(fields));
    downloadXLS(orderedData);
}

function orderExcelObject(datas, fields){
	orderedData = [];
	for (const row of datas) {
		orderedDict = {};
		for (const key of fields) {
			orderedDict[key] = row[key];
		}
		orderedData.push(orderedDict);
	}
	return orderedData;
}

function downloadXLS(data) {

    let myExcelXML = (function() {
        let Workbook, WorkbookStart = '<?xml version="1.0"?><ss:Workbook  xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">';
        const WorkbookEnd = '</ss:Workbook>';
        let fs, SheetName = 'SHEET 1',
            styleID = 1, columnWidth = 80,
            fileName = "PortalBBTX_Filtros_"+String(Date.now()), uri, link;

        class myExcelXML {
            constructor(o) {
                let respArray = JSON.parse(o);
                let finalDataArray = [];

                for (let i = 0; i < respArray.length; i++) {
                    finalDataArray.push(flatten(respArray[i]));
                }

                let s = JSON.stringify(finalDataArray);
                fs = s.replace(/&/gi, '&amp;');
            }

            downLoad() {
                const Worksheet = myXMLWorkSheet(SheetName, fs);

                WorkbookStart += myXMLStyles(styleID);

                Workbook = WorkbookStart + Worksheet + WorkbookEnd;

                uri = 'data:text/xls;charset=utf-8,' + encodeURIComponent(Workbook);
                link = document.createElement("a");
                link.href = uri;
                link.style = "visibility:hidden";
                link.download = fileName + ".xls";

                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }

            get fileName() {
                return fileName;
            }

            set fileName(n) {
                fileName = n;
            }

            get SheetName() {
                return SheetName;
            }

            set SheetName(n) {
                SheetName = n;
            }

            get styleID() {
                return styleID;
            }

            set styleID(n) {
                styleID = n;
            }
        }

        const myXMLStyles = function(id) {
            let Styles = '<ss:Styles><ss:Style ss:ID="' + id + '"><ss:Font ss:Bold="1"/></ss:Style></ss:Styles>';

            return Styles;
        }

        const myXMLWorkSheet = function(name, o) {
            const Table = myXMLTable(o);
            let WorksheetStart = '<ss:Worksheet ss:Name="' + name + '">';
            const WorksheetEnd = '</ss:Worksheet>';

            return WorksheetStart + Table + WorksheetEnd;
        }

        const myXMLTable = function(o) {
            let TableStart = '<ss:Table>';
            const TableEnd = '</ss:Table>';

            const tableData = JSON.parse(o);

            if (tableData.length > 0) {
                const columnHeader = Object.keys(tableData[0]);
                let rowData;
                for (let i = 0; i < columnHeader.length; i++) {
                    TableStart += myXMLColumn(columnWidth);

                }
                for (let j = 0; j < tableData.length; j++) {
                    rowData += myXMLRow(tableData[j], columnHeader);
                }
                TableStart += myXMLHead(1, columnHeader);
                TableStart += rowData;
            }

            return TableStart + TableEnd;
        }

        const myXMLColumn = function(w) {
            return '<ss:Column ss:AutoFitWidth="0" ss:Width="' + w + '"/>';
        }


        const myXMLHead = function(id, h) {
            let HeadStart = '<ss:Row ss:StyleID="' + id + '">';
            const HeadEnd = '</ss:Row>';

            for (let i = 0; i < h.length; i++) {
                //const Cell = myXMLCell(h[i].toUpperCase());
                const Cell = myXMLCell(h[i]);
                HeadStart += Cell;
            }

            return HeadStart + HeadEnd;
        }

        const myXMLRow = function(r, h) {
            let RowStart = '<ss:Row>';
            const RowEnd = '</ss:Row>';
            for (let i = 0; i < h.length; i++) {
                const Cell = myXMLCell(r[h[i]]);
                RowStart += Cell;
            }

            return RowStart + RowEnd;
        }

        const myXMLCell = function(n) {
            let CellStart = '<ss:Cell>';
            const CellEnd = '</ss:Cell>';

            const Data = myXMLData(n);
            CellStart += Data;

            return CellStart + CellEnd;
        }

        const myXMLData = function(d) {
            let DataStart = '<ss:Data ss:Type="String">';
            const DataEnd = '</ss:Data>';

            return DataStart + d + DataEnd;
        }

        const flatten = function(obj) {
            var obj1 = JSON.parse(JSON.stringify(obj));
            const obj2 = JSON.parse(JSON.stringify(obj));
            if (typeof obj === 'object') {
                for (var k1 in obj2) {
                    if (obj2.hasOwnProperty(k1)) {
                        if (typeof obj2[k1] === 'object' && obj2[k1] !== null) {
                            delete obj1[k1]
                            for (var k2 in obj2[k1]) {
                                if (obj2[k1].hasOwnProperty(k2)) {
                                    obj1[k1 + '-' + k2] = obj2[k1][k2];
                                }
                            }
                        }
                    }
                }
                var hasObject = false;
                for (var key in obj1) {
                    if (obj1.hasOwnProperty(key)) {
                        if (typeof obj1[key] === 'object' && obj1[key] !== null) {
                            hasObject = true;
                        }
                    }
                }
                if (hasObject) {
                    return flatten(obj1);
                } else {
                    return obj1;
                }
            } else {
                return obj1;
            }
        }

        return myExcelXML;
    })();

    var dataJson = JSON.stringify(data)
    var dataXML = new myExcelXML(dataJson);
    dataXML.downLoad();
}

function changeColor(id){
    colors = {
      0: "#696969",
      1: "#00008B",
      2: "#228B22",
      3: "#FF8C00",
      4: "#8B008B",
      5: "#8B0000"
    }
    colorNow = parseInt(document.getElementById(id).className);
    colorNow = (colorNow === 5) ? 0 : colorNow+1;
    document.getElementById(id).className = colorNow
    document.getElementById(id).style.color = colors[colorNow];

    lines = linesFilters.filter(function(obj){return obj.idRota == id});
    for(var i=0; i<lines.length; i++){
        lines[i].setOptions({strokeColor: colors[colorNow]});
    };
}