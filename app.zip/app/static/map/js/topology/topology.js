var testemarker = null;
function defineMarkers(loc, scaleIcon, typeIcon, opacityIcon, baseIcon=false){
    var markers = [];

    for(var i=0; i<loc.length; i++){
        //var labelObj = (baseIcon) ? null : {text: loc[i].idWDMOMS, color: 'black', fontSize: "14px"};
        //labelObj = (typeIcon == 'router' && loc[i].Camada !== '') ? {text: loc[i].Camada+' ('+loc[i].Site+')', color: 'black', fontSize: "14px"} : labelObj;
        //var rota = loc[i].Rota !== undefined ? loc[i].Rota : '';

        switch(typeIcon){
            case 'router':
                locIcon = 'vendor/' + loc[i].ReleaseHW + '/Outros.png';
                break;
            case 'base':
                locIcon = 'vendor/Outros/Outros.png';
                break;
            case 'vendors':
                locIcon = 'vendor/' + loc[i].Fabricante + '/' + loc[i].ReleaseHW + '.png';
                break;
            case 'science':
                locIcon = '/vendor/Outros/Science.png';
                break;
            default:
                locIcon = 'vendor/Outros/Outros.png';
        };
        locIcon = (['TIWCE.CE', 'TIWBA.BA', 'TWS.RJ', 'TWS.SP', 'PTW.SP', 'TIW.CE', 'TIW.BA'].includes(loc[i].Site+'.'+loc[i].UF)) ? 'vendor/Outros/TIWS.png' : locIcon;

        var icon = {
            url: iconBase + locIcon,
            scaledSize: { height: scaleIcon, width: scaleIcon },
            labelOrigin: new google.maps.Point(0, -4)
        }

        var marker = new google.maps.Marker({
            //label: labelObj,
            label: null,
            site: loc[i].Site,
            uf: loc[i].UF,
            //title: loc[i].Site + '.' + loc[i].UF + ' (' + loc[i].ReleaseHW + ' ' + loc[i].Fabricante + ')',
            equip: loc[i].ReleaseHW,
            lat: loc[i].Latitude,
            lng: loc[i].Longitude,
            icon: icon,
            vendor: loc[i].Fabricante,
            position: new google.maps.LatLng(loc[i].Latitude, loc[i].Longitude),
            opacity: opacityIcon
        });

        switch(typeIcon){
            case 'base':
                addClickMarkerBase(marker, loc[i].Site+'.'+loc[i].UF, icon, {url: iconBase + locIcon, scaledSize: { height: 12, width: 12 }, labelOrigin: new google.maps.Point(0, -4)}, opacityIcon);
                break;
            case 'vendors':
                addClickMarkerLabel(marker, loc[i].Site+'.'+loc[i].UF);
                break;
            case 'router':
                addClickMarkerLabel(marker, loc[i].Site+'.'+loc[i].UF+' ('+loc[i].ReleaseHW+')');
                break;
            case 'science':
                addClickMarkerBase(marker, loc[i].Site+'.'+loc[i].UF, icon, {url: iconBase + locIcon, scaledSize: { height: 12, width: 12 }, labelOrigin: new google.maps.Point(0, -4)}, opacityIcon);
                break;
            default:
                //addClickMarkerBase(marker, loc[i].Site+'.'+loc[i].UF);
        };

        markers.push(marker);
    };

    return markers;
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

function addClickMarkerBase2(marker, label, icon, icon2, opacity){
    marker.addListener('click', function() {
      if(marker.label == null){
        marker.setLabel({text: label, color: '#363636', fontSize: '12px'});
        marker.setIcon(icon2);
        marker.setOptions({'opacity': 1});
      } else  {
        marker.setLabel(null);
        marker.setIcon(icon);
        marker.setOptions({'opacity': opacity});
      }
    });
}

function addClickMarkerBase(marker, label, icon, icon2, opacity){
    marker.addListener('click', function() {
      if(marker.opacity < 1) {
        marker.setIcon(icon2);
        marker.setOptions({'opacity': 1});
      } else if (marker.label == null) {
        marker.setLabel({text: label, color: '#363636', fontSize: '12px'});
      } else  {
        marker.setLabel(null);
        marker.setIcon(icon);
        marker.setOptions({'opacity': opacity});
      }
    });
}

function addClickMarkerLabel(marker, label){
    marker.addListener('click', function() {
      if(marker.label == null){
        marker.setLabel({text: label, color: '#363636', fontWeight: 'bold', fontSize: '12px'});
      } else  {
        marker.setLabel(null);
      }
    });
}

function defineNetworkCoordinates(coordinates, lineType, lineStrokeWeight, lineStrokeOpacity, linePlan){
    var networkCoordinates = [];

    for(var i=0; i<coordinates.length; i++){
        iconLine = []

        switch(lineType){
            case 'base':
                colorLine = '#778899';
                break;
            case 'vendors':
                colorLine = '#8B7E66';
                break;
            default:
                colorLine = '#FFFFFF';
        }

        if(coordinates[i].Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol(colorLine, linePlan),
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coordinates[i].LatitudeA), 'lng': Number(coordinates[i].LongitudeA)}, {'lat': Number(coordinates[i].LatitudeB), 'lng': Number(coordinates[i].LongitudeB)}],
            geodesic: true,
            strokeColor: colorLine,
            strokeOpacity: lineStrokeOpacity,
            strokeWeight: lineStrokeWeight,
            icons: iconLine,
            type: lineType,
            latZoom: coordinates[i].LatitudeA,
            lngZoom: coordinates[i].LongitudeA,
            vendor: coordinates[i].FabricanteA,
            originCoordinate: coordinates[i],
            statusLink: coordinates[i].Status
        });

        switch(lineType){
            case 'base':
                addListenerBase(line, lineStrokeOpacity, lineStrokeWeight, 1, lineStrokeWeight+3)
                break;
            case 'vendors':
                addListenerVendors(line, coordinates[i])
                break;
            default:
                colorLine = '#FFFFFF';
        }

        networkCoordinates.push(line);
    }
    return networkCoordinates;
}

function addNetworkCoordinates(networkCoordinates, visible){
    for(var i=0; i<networkCoordinates.length; i++){
        networkCoordinates[i].setMap(visible);
    }
}

function addListenerBase(line, originalOpacity, originalWeight, toOpacity, toWeight){
    line.addListener('click', function() {
        if(line.strokeOpacity == originalOpacity){
            line.setOptions({strokeOpacity: toOpacity, strokeWeight: toWeight});
            //strokeColor: 'red'
        } else {
            line.setOptions({strokeOpacity: originalOpacity, strokeWeight: originalWeight});
        }
    });
}

function addListenerVendors(line, coordinate){
    line.addListener('click', function() {
        showDetailsOts(coordinate.LatitudeA, coordinate.LongitudeA, coordinate.LatitudeB, coordinate.LongitudeB);
    });
}

function lineSymbol(color, scale) {
    return {
        path: 'M 0.5,-1 -0.5,1',
        //strokeOpacity: 1,
        strokeColor: color,
        scale: scale
    };
}

function showDetailsOts(latA, lngA, latB, lngB){
    var routesFiltered = linesVendors.filter(function(obj){
        return (obj.originCoordinate.LatitudeA == latA && obj.originCoordinate.LongitudeA == lngA && obj.originCoordinate.LatitudeB == latB && obj.originCoordinate.LongitudeB == lngB) || (obj.originCoordinate.LatitudeA == latB && obj.originCoordinate.LongitudeA == lngB && obj.originCoordinate.LatitudeB == latA && obj.originCoordinate.LongitudeB == lngA)
    })

    //html Detalhes OTS
    infosOTS = fillDetalhesOTS(routesFiltered);
    //htmlDetalhesOTS = infosOTS[0];
    //document.getElementById("modalDetalhesOTS").innerHTML = htmlDetalhesOTS;

    //document.getElementById('ModalOTS').style.display = "block"
}

function hideDetailsOts(){
   document.getElementById("modalDetalhesOMS").innerHTML = '';
   document.getElementById("modalCircuitosOMS").innerHTML = '';
   document.getElementById("collapseOne").classList.add("show");
   document.getElementById("collapseTwo").classList.remove("show");
   document.getElementById('ModalOMS').style.display = "none"

   document.getElementById("modalDetalhesOTS").innerHTML = '';
   document.getElementById('ModalOTS').style.display = "none"
}

function fillDetalhesOTS(coordinates){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';
    var otssNetw = '';
    var otssNetwInfos = [];

    for(var i=0; i<coordinates.length; i++){
        otssNetw = otssNetw + coordinates[i].originCoordinate.idWDMOTS + ','
    }
    otssNetw = otssNetw.slice(0, -1)
    $.ajax({
        url: '/ajax-network-ots',
        data: {
          otss: String(otssNetw)
        },
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            if(response['NetworkOtsInfos'].length == 0){otssNetwInfos = [];} else {otssNetwInfos = response['NetworkOtsInfos'];}
            otssNetwInfosEtps = response['NetworkOtsEtps'];
            infosOTS = fillDetalhesOTSNetwork(coordinates, otssNetwInfos, otssNetwInfosEtps, response['validation'], response['supportsedit']);
            htmlDetalhesOTS = infosOTS[0];
            document.getElementById("modalDetalhesOTS").innerHTML = htmlDetalhesOTS;
            document.getElementById('ModalOTS').style.display = "block"

            //console.log(response['NetworkOtsAtenuacao']);
            fillCaracterizacao(response['NetworkOtsCaracterizacao'])
            fillAtenuaGraph(response['NetworkOtsAtenuacao']);

            document.getElementById("progress").innerHTML = '';
        },
        error: function(error){
        document.getElementById("progress").innerHTML = '';
            //alert("Nenhum idRota encontrado!!!");
        }
    });
}

function fillCaracterizacao(ots_data){
    Object.keys(ots_data).forEach(function(ots){
        //console.log(ots_data[ots]);
        if(ots_data[ots].length > 0){
            html = '<h7>Caracterização de Fibra</h7>' +
            '<table id="detalhesCaracterizacao_'+ots+'" class="table table-sm table-hover table-bordered">'
            for(var i=0; i<ots_data[ots].length; i++){
                html = html +
                '<thead>' +
                '<tr class="table-active">' +
                '<th scope="col">SiteA NumFibra</th>' +
                '<th scope="col">SiteA DGO</th>' +
                '<th scope="col">SiteA Conector</th>' +
                '<th scope="col">SiteA TipoConector</th>' +
                '<th scope="col">SiteA Fabricante</th>' +
                '<th scope="col">Distância Medida AB</th>' +
                '<th scope="col">Atenuação AB</th>' +
                '<th scope="col">ORL AB</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>' +
                '<tr>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteA_NumFibra'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteA_DGO'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteA_Conector'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteA_TipoConector'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteA_Fabricante'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_DistanciaMedidaKm_AB'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_AtenuacaoTotalDb_AB'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_ORL_AB'] + '</td>' +
                '</tr>' +
                '</tbody>' +

                '<thead>' +
                '<tr class="table-active">' +
                '<th scope="col">SiteB NumFibra</th>' +
                '<th scope="col">SiteB DGO</th>' +
                '<th scope="col">SiteB Conector</th>' +
                '<th scope="col">SiteB TipoConector</th>' +
                '<th scope="col">SiteB Fabricante</th>' +
                '<th scope="col">Distância Medida BA</th>' +
                '<th scope="col">Atenuação BA</th>' +
                '<th scope="col">ORL BA</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>' +
                '<tr>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteB_NumFibra'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteB_DGO'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteB_Conector'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteB_TipoConector'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PosicaoFisica_SiteB_Fabricante'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_DistanciaMedidaKm_BA'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_AtenuacaoTotalDb_BA'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_ORL_BA'] + '</td>' +
                '</tr>' +
                '</tbody>' +

                '<thead>' +
                '<tr class="table-active">' +
                '<th scope="col">Distância Teórica</th>' +
                '<th scope="col">Distância Medida</th>' +
                '<th scope="col">Atenuação Média</th>' +
                '<th scope="col">ORL Média</th>' +
                '<th scope="col">SiteA Potência</th>' +
                '<th scope="col">Site B Nivel RX</th>' +
                '<th scope="col" colspan="2">Atenuação Total</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>' +
                '<tr>' +
                '<td scope="row">' + ots_data[ots][i]['Distancia_Teorica_KM'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_DistanciaMedidaKm_Media'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_AtenuacaoTotalDb_Media'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['OTDR_ORL_Media'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PowerMeter_SiteA_Potencia_Dbm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['PowerMeter_SiteB_NivelRX_Dbm'] + '</td>' +
                '<td scope="row" colspan="2">' + ots_data[ots][i]['PowerMeter_AtenuacaoTotal_Db'] + '</td>' +
                '</tr>' +
                '</tbody>' +

                '<thead>' +
                '<tr class="table-active">' +
                '<th scope="col">Lambda Zero nm</th>' +
                '<th scope="col">1530nm</th>' +
                '<th scope="col">1540nm</th>' +
                '<th scope="col">1550nm</th>' +
                '<th scope="col">1560nm</th>' +
                '<th scope="col">1550nm Total</th>' +
                '<th scope="col" colspan="2">Tipo da Fibra</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>' +
                '<tr>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_LambdaZero_Nm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_1530nm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_1540nm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_1550nm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_1560nm'] + '</td>' +
                '<td scope="row">' + ots_data[ots][i]['DispersaoCromatica_Total_1550nm'] + '</td>' +
                '<td scope="row" colspan="2">' + ots_data[ots][i]['DispersaoCromatica_TipoFibra'] + '</td>' +
                '</tr>' +
                '</tbody>' +

                '<thead>' +
                '<tr class="table-active">' +
                '<th scope="col">PMD Máximo</th>' +
                '<th scope="col" colspan="7">Coeficiente PMD Máximo</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>' +
                '<tr>' +
                '<td scope="row">' + ots_data[ots][i]['PMD_Maximo_ps'] + '</td>' +
                '<td scope="row" colspan="7">' + ots_data[ots][i]['PMD_CoeficienteMaximo_psPorVkm'] + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td scope="row" colspan="8">&nbsp;</td>' +
                '</tr>' +
                '</tbody>'
            }
            html = html + '</table>'

            document.getElementById('Caracterizacao_'+ots).innerHTML = html;
        }
    })
}

function fillAtenuaGraph(ots_data){
    Object.keys(ots_data).forEach(function(ots){
        if(ots_data[ots].length > 1){
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable(ots_data[ots]);
                var options = {
                  curveType: 'function',
                  width: '100%',
                  height: 200,
                  legend: { position: 'top' },
                  hAxis: {textPosition: 'none', slantedText:true }
                };
                var chart = new google.visualization.LineChart(document.getElementById('Atenuacao_'+ots)).draw(data, options);
            }
        }
    })
}

function fillDetalhesOTSNetwork(coordinates, otssNetwInfos, otssNetwInfosEtps, validation, supportsedit){
    var detalhesHtml = '';
    var ots = '';
    var infos = [];
    //var otssNetwInfos = fillDetalhesOTSNetwork(coordinates);

    for(var i=0; i<coordinates.length; i++){
        ots = ots + coordinates[i].originCoordinate.idWDMOTS + ' ';
        var omss = (coordinates[i].originCoordinate.omss) ? coordinates[i].originCoordinate.omss : 'Sem Informação';

        var ochs = '';
        var odus = '';
        var eilds = '';

        var otsNetwInfo = otssNetwInfos.filter(function(obj){
            return (obj.idWDMOTS == coordinates[i].originCoordinate.idWDMOTS)
        })
        var otssNetwInfoEtps = otssNetwInfosEtps.filter(function(obj){
            return (obj.idWDMOTS == coordinates[i].originCoordinate.idWDMOTS)
        })

        if(otsNetwInfo.length > 0){
            ochs = otsNetwInfo[0].ochs;
            odus = otsNetwInfo[0].odus;
            eilds = otsNetwInfo[0].eilds;
        }
        etps = (otssNetwInfoEtps[0]['etps'] !== '') ? otssNetwInfoEtps[0]['etps'] : "";

        detalhesHtml = detalhesHtml +
        '<h5>' + coordinates[i].originCoordinate.SiteA + '-' + coordinates[i].originCoordinate.UFA + ' <-> ' + coordinates[i].originCoordinate.SiteB + '-' + coordinates[i].originCoordinate.UFB + '</h5>' +
        '<table id="detalhesOTS" class="table table-sm table-hover table-bordered">' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Id OTS</th>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">Status</th>' +
        '<th scope="col">Tipo da Fibra</th>' +
        '<th scope="col" colspan="2">Tipo de Rede Optica</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.idWDMOTS + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Sigla + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Status + '</td>' +
        '<td>' + coordinates[i].originCoordinate.TipoFibra + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.TipoRedeOptica + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Site</th>' +
        '<th scope="col">Equipamento</th>' +
        '<th scope="col">Fabricante</th>' +
        '<th scope="col">Latitude</th>' +
        '<th scope="col" colspan="2">Longitude</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteA + '.' + coordinates[i].originCoordinate.UFA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.FabricanteA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LatitudeA + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.LongitudeA + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteB + '.' + coordinates[i].originCoordinate.UFB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.FabricanteB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LatitudeB + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.LongitudeB + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Site</th>' +
        '<th scope="col">Sh/Sl/Po RX</th>' +
        '<th scope="col">Sh/Sl/Po TX</th>' +
        '<th scope="col">Modelo</th>' +
        '<th scope="col" colspan="2">Release HW</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteA + '.' + coordinates[i].originCoordinate.UFA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfARX + '/' + coordinates[i].originCoordinate.SlotARX + '/' + coordinates[i].originCoordinate.PortaARX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfATX + '/' + coordinates[i].originCoordinate.SlotATX + '/' + coordinates[i].originCoordinate.PortaATX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ModeloA + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.ReleaseHWA + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteB + '.' + coordinates[i].originCoordinate.UFB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfBRX + '/' + coordinates[i].originCoordinate.SlotBRX + '/' + coordinates[i].originCoordinate.PortaBRX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfBTX + '/' + coordinates[i].originCoordinate.SlotBTX + '/' + coordinates[i].originCoordinate.PortaBTX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ModeloB + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.ReleaseHWB + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Dist. Teór.</th>' +
        '<th scope="col">Dist. Basel.</th>' +
        '<th scope="col">Atenu. Teór.</th>' +
        '<th scope="col">Atenu. Basel. TX</th>' +
        '<th scope="col" colspan="2">Atenu. Basel. RX</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.DistanciaTeorica + '</td>' +
        '<td>' + coordinates[i].originCoordinate.DistanciaReal + '</td>' +
        '<td>' + coordinates[i].originCoordinate.AtenuacaoTeorica + '</td>' +
        '<td>' + coordinates[i].originCoordinate.AtenuacaoRealTX + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.AtenuacaoRealRX + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">dB KM</th>' +
        '<th scope="col">Coerente</th>' +
        '<th colspan="2" scope="col">OMS(s)</th>' +
        '<th colspan="2" scope="col">ETP(s)</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.dB_Km + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Coerente + '</td>' +
        '<td colspan="2">' + omss + '</td>' +
        '<td colspan="2">' + etps + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th colspan="2" scope="col">Proprietário da Fibra</th>' +
        '<th colspan="4" scope="col">Nome da Rota</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td colspan="2"  scope="row">' +
        '<span id="spanOts-' + coordinates[i].originCoordinate.idWDMOTS + '">' + coordinates[i].originCoordinate.PropriedadeFibra + '</span>'
        if(validation){
            detalhesHtml = detalhesHtml + '<i id="inputOtsEdit-' + coordinates[i].originCoordinate.idWDMOTS +'" class="material-icons" style="cursor:pointer" onclick="OtsUpdateCreate(\'' + coordinates[i].originCoordinate.idWDMOTS +  '\')">edit_note</i>' +
            '<button style="display: none" class="btn btn-outline-secondary" type="button" id="btGravaOts-' + coordinates[i].originCoordinate.idWDMOTS +'" onclick="saveOtsUpdate(\'' + coordinates[i].originCoordinate.idWDMOTS +  '\')">Gravar</button>'
        }
        detalhesHtml = detalhesHtml +
        '<select style="display: none" class="form-control" id="slcOts-' + coordinates[i].originCoordinate.idWDMOTS + '">' +
        '<option selected></option>'
        supportsedit['fiber_owner'].forEach(function(owner){
            var prop = (coordinates[i].originCoordinate.PropriedadeFibra) ? coordinates[i].originCoordinate.PropriedadeFibra.toLowerCase() : '';
            var slctd = (prop == owner.toLowerCase()) ? 'selected' : '';
            detalhesHtml = detalhesHtml + '<option '+slctd+'>' + owner + '</option>';
        })
        detalhesHtml = detalhesHtml + '</select>' +
        '<input type="hidden" id="hidOts-' + coordinates[i].originCoordinate.idWDMOTS + '" value="' + coordinates[i].originCoordinate.idWDMOTS +'" />'+
        '</td>' +

        '<td colspan="4">' + coordinates[i].originCoordinate.NomeRotaNovo + '</td>' +
        '</tr>' +
        '</tbody>' +

        '<thead>' +
        '<tr class="table-active">' +
        '<th colspan="2" scope="col">OCH(s)</th>' +
        '<th colspan="2" scope="col">ODU(s)</th>' +
        '<th colspan="2" scope="col">EILD(s)</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td colspan="2"  scope="row">' + ochs + '</td>' +
        '<td colspan="2"  scope="row">' + odus + '</td>' +
        '<td colspan="2"  scope="row">' + eilds + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td id="Atenuacao_' + coordinates[i].originCoordinate.idWDMOTS + '" colspan="6" scope="row"></td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +
        '<div id="Caracterizacao_' + coordinates[i].originCoordinate.idWDMOTS + '"></div>'
    }

    infos.push(detalhesHtml);
    infos.push(ots.trim());
    return infos;
}

function layerVisible(cb){
    var visible;

    if(cb.checked){
        visible = map;
    } else {
        visible = null;
    }

    if(cb.value === 'base'){
        addMarkers(markersBase, visible);
        addNetworkCoordinates(linesBase, visible);
    } else if (cb.value.startsWith('HL') || cb.value === 'Toogate' || cb.value.startsWith('GW')){
        addMarkers(markersCamadasHL.filter(function(obj){return obj.equip == cb.value}), visible);
    } else {
        addMarkers(markersVendors.filter(function(obj){return obj.vendor == cb.value}), visible);
        addNetworkCoordinates(linesVendors.filter(function(obj){return obj.vendor == cb.value}), visible);

        var visibleBase = (visible === map) ? null : map;
        if(document.getElementById('Base').checked){
            addMarkers(markersBase.filter(function(obj){return obj.vendor == cb.value}), visibleBase);
            addNetworkCoordinates(linesBase.filter(function(obj){return obj.vendor == cb.value}), visibleBase);
        }
    }

}

function searchSiteByName(txt, map){
    if(event.keyCode == 13) {
        var site = markersBase.find(function(obj){return obj.site + "." + obj.uf == txt.value.toUpperCase()});

        if(site == undefined){
            //PROCURAR MUNICÍPIO
            var municipio = municipiosCoordinates.find(function(obj){return obj.nome + " - " + obj.UF == txt.value.toUpperCase()});
            if(municipio == undefined){
                var science = createScienceMarkerFilter(map, txt.value.toUpperCase());
                if(science == false){
                    swal("", "Nenhum local encontrado!!", "warning", {buttons: false, timer: 1500});
                }
            } else {
                map.setCenter(new google.maps.LatLng(municipio["latitude"], municipio["longitude"]));
                map.setZoom(10);
                //showLabel(map);
            }
        } else {
            map.setCenter(new google.maps.LatLng(site["lat"], site["lng"]));
            map.setZoom(10);
            site.setIcon({url: iconBase + 'vendor/Outros/Outros.png', scaledSize: { height: 12, width: 12 }, labelOrigin: new google.maps.Point(0, -4)});
            site.setOpacity(1);
            site.setLabel({text: site.site+'.'+site.uf, fontSize: '12px', color: '#363636'});
            //site.setLabel({text: site.site+'.'+site.uf, fontWeight: "bold", color: '#363636'})
            //showLabel(map);
        }
    }
}

function showLabelBase(map){
    var x = '2.0';

    var markersFilteredBase = markersBase.filter(function(obj){
        return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
    });
    for (var i = 0; i < markersFilteredBase.length; i++){
        markersFilteredBase[i].setLabel({text: markersFilteredBase[i].site+'.'+markersFilteredBase[i].uf, color: '#363636', fontSize: '12px'});
        //markersFiltered[i].setIcon({url: iconBase + 'vendor/Outros/Outros.png', scaledSize: { height: 12, width: 12 }, labelOrigin: new google.maps.Point(0, -4)});
        //markersFilteredBase[i].setOptions({'opacity': 1});
    }

    var markersFilteredVendors = markersVendors.filter(function(obj){
        return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
    });
    for (var i = 0; i < markersFilteredVendors.length; i++){
        markersFilteredVendors[i].setLabel({text: markersFilteredVendors[i].site+'.'+markersFilteredVendors[i].uf, color: '#363636', fontSize: '12px'});
        //markersFiltered[i].setIcon({url: iconBase + 'vendor/Outros/Outros.png', scaledSize: { height: 12, width: 12 }, labelOrigin: new google.maps.Point(0, -4)});
        //markersFilteredBase[i].setOptions({'opacity': 1});
    }
}

function hideLabelBase(map){
    for (var i = 0; i < markersBase.length; i++){
        markersBase[i].setLabel(null);
        //markersBase[i].setIcon({url: iconBase + 'vendor/Outros/Outros.png', scaledSize: { height: 6, width: 6 }});
        //markersBase[i].setOptions({'opacity': 0.5});
    }

    for (var i = 0; i < markersVendors.length; i++){
        markersVendors[i].setLabel(null);
        //markersBase[i].setIcon({url: iconBase + 'vendor/Outros/Outros.png', scaledSize: { height: 6, width: 6 }});
        //markersBase[i].setOptions({'opacity': 0.5});
    }
}

async function HLicons(size){
    var actualSize = markersCamadasHL[0].icon.scaledSize.width;
    var newSize = (actualSize+size < 14) ? 14 : actualSize+size;
    var hlSelected = new Array(0);

    ['GWS', 'GWD', 'GWC', 'HL5', 'HL4', 'HL3', 'HL2', 'HL1', 'Toogate'].forEach(function(l){
        if(document.getElementById(l).checked){
            hlSelected.push(l);
            document.getElementById(l).click();
        }
    })

    markersCamadasHL.forEach(function(m){
        m.icon.scaledSize = new google.maps.Size(newSize, newSize);
        if(m.icon.size){
            m.icon.size = new google.maps.Size(newSize, newSize);
        }
    })

    hlSelected.forEach(function(r){
        document.getElementById(r).click();
    })
}