
function cleanUpSpecialChars(str)
{
    return str
        .replace(/[ÀÁÂÃÄÅ]/g,"A")
        .replace(/[àáâãäå]/g,"a")
        .replace(/[ÈÉÊË]/g,"E")
        .replace(/[é]/g,"e")
        .replace(/[ç]/g,"c")
        .replace(/[Ç]/g,"C")
        .replace(/[óõô]/g,"o")
        .replace(/[ÓÕÔ]/g,"O")
        .replace(/[ú]/g,"u")
        .replace(/[Ú]/g,"U")
        //.... all the rest
        .replace(/[^a-z0-9]/gi,''); // final clean up
}

//search
function search_kml() {
    var input, filter, table, tr, td, i;
    input = document.getElementById("search_route_kmz");
    filter = cleanUpSpecialChars(input.value).toUpperCase();

    table = document.getElementById("kmz-doc-table");
    tr = table.getElementsByTagName("tr");

     var searchColumn=[1]

    for (i = 0; i < tr.length; i++) {

      if($(tr[i]).parent().attr('class')=='head')
        {
            continue;
         }

    var found = false;
      for(var k=0;k<searchColumn.length;k++){

        td = tr[i].getElementsByTagName("td")[searchColumn[k]];
        check = tr[i].getElementsByTagName("input")[0]

        if (td) {
          if (cleanUpSpecialChars(td.innerHTML).toUpperCase().indexOf(filter) > -1 ) {
            found=true;
          } 
        }
    }
    if(found==true)  {
        tr[i].style.display = "";
        handleKmzSelect(check, set=true)
    } 
    else{
        tr[i].style.display = "none";
        handleKmzSelect(check, set=false)
    }
}
}


async function extractGoogleCoords(plainText) {



    let parser = new DOMParser()

    plainText = plainText.replace(/<description>((.|\n)*?)<\/description>/g, "")
    plainText = plainText.replace(/xsi:schemaLocation="(.*?)"/g, "")


    let xmlDoc = parser.parseFromString(plainText, "text/xml")

    let styleMap = []
    let styleSettings = []
    kmlData = {};

    if (xmlDoc.documentElement.nodeName == "kml") {

        for (const item of xmlDoc.getElementsByTagName('StyleMap')) {
            styleMap.push({'id':item.id, 'map':{}})
            for (const pair of item.getElementsByTagName('Pair')){
                styleMap[styleMap.length -1]['map'][pair.getElementsByTagName('key')[0].innerHTML] = pair.getElementsByTagName('styleUrl')[0].innerHTML
                }
            }

        for (const item of xmlDoc.getElementsByTagName('Style')) {
            styleSettings.push({'id':item.id, 'map':{}})
            for (const node of item.childNodes){

                if (node.nodeName == '#text')
                    continue

                let temp = {}
                
                for (const cnd of node.childNodes){
                    
                    if (cnd.nodeName == '#text')
                        continue
                    temp[cnd.nodeName] = cnd.innerHTML
                }
                styleSettings[styleSettings.length -1]['map'][node.nodeName] = temp
            }
        }

        
        

        for (const item of xmlDoc.getElementsByTagName('Placemark')) {
            let googlePolygons = []
            //let googleMarkers = []
            let googleLs = []
            placemarkGoogle = {}
            placemarkGoogle.polygons = new Array();
            placemarkGoogle.markers = new Array();
            placemarkGoogle.lineString = new Array();

            var placeMarkName = ""

            try {
                placeMarkName = item.getElementsByTagName('name')[0].childNodes[0].nodeValue.trim();
            } catch (error) {}
            placemarkGoogle.name = placeMarkName
            //placemarkGoogle.styleUrl = item.getElementsByTagName('styleUrl')[0].innerHTML.replace(/#/g,'')
            
            let polygons = item.getElementsByTagName('Polygon')
            let markers = item.getElementsByTagName('Point')
            let lineString = item.getElementsByTagName('LineString')
            

            /** POLYGONS PARSE **/        
            for (const polygon of polygons) {
                let coords = polygon.getElementsByTagName('coordinates')[0].childNodes[0].nodeValue.trim()
                let points = coords.split(" ")

                let googlePolygonsPaths = []
                for (const point of points) {
                    let coord = point.split(",")
                    googlePolygonsPaths.push({ lat: +coord[1], lng: +coord[0] })
                }
                googlePolygons.push(googlePolygonsPaths)
            }

            /** MARKER PARSE    
            for (const marker of markers) {
                var coords = marker.getElementsByTagName('coordinates')[0].childNodes[0].nodeValue.trim()
                let coord = coords.split(",")
                googleMarkers.push({ lat: +coord[1], lng: +coord[0] })
            }**/
            
            for (const line of lineString) {
                let coords = line.getElementsByTagName('coordinates')
                
                
                for (const coord of coords){
                    let c = coord.childNodes[0].nodeValue.trim()
                    
                    let points = c.split(" ")
                    
                    let googlePaths = []
                    for (const point of points) {
                        let coord = point.split(",")
                        googlePaths.push({ lat: +coord[1], lng: +coord[0] })
                    }
                    googleLs.push(googlePaths)
                }
            }
            if(!kmlData.hasOwnProperty(placeMarkName)){
                kmlData[placeMarkName] = {name: '', lineString: [], styleMap: [], style:[]}
            }
            kmlData[placeMarkName].name = placeMarkName,
            //kmlData[placeMarkName].markers = kmlData[placeMarkName].markers.concat(googleMarkers) 
            //kmlData[placeMarkName].polygons = kmlData[placeMarkName].polygons.concat(googlePolygons) 
            kmlData[placeMarkName].lineString = kmlData[placeMarkName].lineString.concat(googleLs)
            //kmlData[placeMarkName].styleMap = kmlData[placeMarkName].styleMap.concat(styleMap) 
            //kmlData[placeMarkName].style = kmlData[placeMarkName].style.concat(styleSettings)
        }
    }
    else {
        document.getElementById("progress").innerHTML = '';
        //clearKml()
        swal("", "Erro na leitura do arquivo", "warning", {buttons: false, timer: 2000});
        throw "error while parsing"
    }

    return kmlData
}

let docs = new Array();

function clearKml() {
    
    document.getElementById('kmz-doc-table').childNodes[0].innerHTML = "";
    document.getElementById('kmzToggle').childNodes[0].innerHTML = "";
    document.getElementById('search_route_kmz').value = ''
    //document.getElementById('kmlInput').value = ''
    if (docs.length != 0){
        for (var i = 0; i < docs.length; i++) {
            if (docs[i]['path'].length != 0){
                for (var j = 0; j < docs[i]['path'].length; j++) {
                    docs[i]['path'][j].setMap(null);
                }
            }
        }
        docs = new Array();
    }
}

function setPath(dict, operation='redo') {
    //clearKml()
    var index_old = docs.length


    
    for (const item of dict){
        for (const [key, result] of Object.entries(item)){
            var gpaths = new Array();
            for (const coord of result.lineString){
                path = new Array();
                for (const tuple of coord) {
                    path.push(new google.maps.LatLng(tuple.lat, tuple.lng))
                }

                gpaths.push(new google.maps.Polyline({
                    path: path,
                    strokeColor:"#0000FF",
                    strokeOpacity:0.8,
                    strokeWeight:2
                }));
                if (gpaths.length != 0)
                    gpaths[gpaths.length-1].setMap(map);
            }
            if (gpaths.length != 0){    
                docs.push({path: gpaths,
                           name: result.name})
            }
        }
        document.getElementById("progress").innerHTML = '';
    }
    createDocs({operation: operation, doc_index_old: index_old})

}

function addFileListener(files, operation) {

    var extension = files[0].name.match(/\.[0-9a-z]+$/i)[0];
    var name = files[0].name
;
    var fr=new FileReader();
    fr.file = files[0]
    var fr_zip = new FileReader();
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';
    fr.onload = async function(){
        await extractGoogleCoords(fr.result).catch(function(err){document.getElementById("progress").innerHTML = '';
        throw err})
        .then((result) => setPath([result] ,operation=operation));
    }

    async function extract(zip) {
        let result = new Array();
        for(let [filename, file] of Object.entries(zip.files)) {


            if (filename.match(/\.[0-9a-z]+$/i)[0] != '.kml')
                continue
            result.push(await file.async('string')
            .then((fileData) => extractGoogleCoords(fileData))
            .then((r) => {return(r)}))
        }
        
        
        return (result)
    }

    fr_zip.onload = async function(ev) {
        
        await JSZip.loadAsync(ev.target.result).then((zip) => extract(zip).catch(function (err) {document.getElementById("progress").innerHTML = '';
        throw err})
        ).then((result) => {setPath(result,operation=operation)})
    }

    if(operation == 'redo'){
        clearKml();
    }
    var fileInputElement = document.getElementById("kmlInput");

    if (extension == '.kml' || extension == '.KML'){
        fr.readAsText(files[0]);
    } else {
        fr_zip.readAsArrayBuffer(files[0]);
    }
    //document.getElementById("progress").innerHTML = '';
}

function createDocs({operation='redo', doc_index_old = 0}){

    
    if(operation == 'redo'){
        
        if (docs.length != 0){
            var k = '<tbody>'
            for (var i = 0; i < docs.length; i++) {
                    k+= '<tr padding="0">';
                    k+= '<td width="20">' +'<input type="checkbox" id="'+i+'" onchange="handleKmzSelect(this);" checked></input>'+ '</td>';
                    k+= '<td>' +docs[i].name+ '</td>';
                    k+= '</tr>';
            }
            k += '</tbody>'
            var table_input = ''
            table_input+='<td><p align="center">+</p></td>'
            table_input+='<td text-align="center">'
            table_input+='<label for="kmz_input_n">adicionar arquivos</label>'
            table_input+='<input type="file" id="kmz_input_n" accept=".kml,.kmz" value="" style="display:none">'
            table_input+='</td>'
            document.getElementById('kmz-doc-table').innerHTML = k;
            document.getElementById('kmzToggle').childNodes[0].innerHTML += table_input;
            document.getElementById('kmz_input_n').addEventListener('change', function(){addFileListener(this.files, 'add')})
        }
    } else {
        if (docs.length != 0){
            var checked = new Array();
            for (var i = 0; i < doc_index_old; i++) {
                checked.push(document.getElementById(i).checked)
            }
            var k = ''
            for (var i = doc_index_old; i < docs.length; i++) {
                    k+= '<tr padding="0">';
                    k+= '<td width="20">' +'<input type="checkbox" id="'+i+'" onchange="handleKmzSelect(this);" checked></input>'+ '</td>';
                    k+= '<td>' +docs[i].name+ '</td>';
                    k+= '</tr>';
            }
            
            document.getElementById('kmz-doc-table').childNodes[0].innerHTML += k;
            for (var i = 0; i < doc_index_old; i++) {
                document.getElementById(i).checked = checked[i]
            }
        }
    }

}

document.getElementById('kmlInput').addEventListener('change', (event) => {addFileListener(event.target.files, 'redo')})

document.getElementById('kmlInput').value = '';
document.getElementById("search_route_kmz").value = '';
document.getElementById('kmlClear').addEventListener('click', async function() {
    document.getElementById('kmlInput').value = '';
    clearKml();
})

function handleKmzSelect(checkbox, check=null) {
    if (check != null) {
        checkbox.checked = check;
    }
    id = parseInt(checkbox.id)
    if(checkbox.checked == true){
        if (docs[id]['path'].length != 0){
            for (var j = 0; j < docs[id]['path'].length; j++) {
                docs[id]['path'][j].setMap(map);
            }
        }
    }else{
        if (docs[id]['path'].length != 0){
            for (var j = 0; j < docs[id]['path'].length; j++) {
                docs[id]['path'][j].setMap(null);
            }
        }
   }
}