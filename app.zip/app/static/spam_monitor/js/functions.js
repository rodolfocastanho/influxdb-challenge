var map;
var markers;
var networkCoordinates;
var html_spinner = '<div class="spinner-border spinner-border-sm text-secondary" role="status"></div>';
var html_resume_bt = '<img id="resumeIcon" src="static/map/img/icons/table.png" alt="Resumo" onclick="showModal(\'block\', \'modalTabelaDetalhes\')">';

function createCustomControls(customControls){
    var div = document.createElement('div');
    var html = '' +
    //'<img id="reportIcon" src="img/icons/report.png" alt="Resumo" onclick="showReport(map, report)">' +
    //'<hr>' +
    '<img id="zoomIcon" src="static/map/img/icons/zoom.png" alt="Visão Geral" onclick="initZoom(map)">'
    div.innerHTML = html;
    customControls.appendChild(div);
}

function createMenuControls(menuControls){
    var div = document.createElement('div');
    var html = '' +
    '<span>' +
    '<span id="progress_detalhes">' +
    html_resume_bt +
    '</span>' +
    '&nbsp;&nbsp;|&nbsp;&nbsp;' +
    '<img id="reportIcon" src="static/map/img/icons/chart.png" alt="Report" onclick="showModal(\'block\', \'modalReport\')">' +
    '&nbsp;&nbsp;|&nbsp;&nbsp;' +
    '<span id="total_registros"></span>' +
    '</span>'


    div.innerHTML = html;
    menuControls.appendChild(div);
}

function defineMarkers(loc){
    var markers = [];
    var locIcon = '';

    for(var i=0; i<loc.length; i++){
        switch(loc[i].status){
            case 'CRITICAL':
                locIcon = 'Ciena';
                break;
            case 'REALIGN':
                locIcon = 'Ciena';
                break;
            case 'NOK':
                locIcon = 'Nokia';
                break;
            case 'HIGH':
                locIcon = 'Nokia';
                break;
            case 'OK':
                locIcon = 'Huawei';
                break;
            default:
                locIcon = 'Outros';
        }
        scaleIcon = 7;

        var icon = {
            url: iconBase + 'vendor/' + locIcon + '/TOADM.png',
            scaledSize: { height: scaleIcon, width: scaleIcon },
            labelOrigin: new google.maps.Point(0, -4)
        }

        var markerA = new google.maps.Marker({
            //label: {text: loc[i].chave, color: 'black', fontSize: "4px"},
            localidade: loc[i].site_a,
            id_frontend: loc[i].id_frontend,
            lat: loc[i].lat_a,
            lng: loc[i].long_a,
            icon: icon,
            position: new google.maps.LatLng(loc[i].lat_a, loc[i].long_a)
        });
        var markerZ = new google.maps.Marker({
            //label: {text: loc[i].chave, color: 'black', fontSize: "4px"},
            localidade: loc[i].site_z,
            id_frontend: loc[i].id_frontend,
            lat: loc[i].lat_z,
            lng: loc[i].long_z,
            icon: icon,
            position: new google.maps.LatLng(loc[i].lat_z, loc[i].long_z)
        });

        addClickMarker(markerA, loc[i].site_a);
        addClickMarker(markerZ, loc[i].site_z);

        markers.push(markerA);
        markers.push(markerZ);
    };

    return markers;
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

function addClickMarker(marker, label){
    marker.addListener('click', function() {
      if(marker.label == null){
        marker.setLabel({text: label, color: '#363636', fontWeight: 'bold', fontSize: '12px'});
      } else  {
        marker.setLabel(null);
      }
    });
}

function defineNetworkCoordinates(coordinates){
    var networkCoordinates = [];

    for(var i=0; i<coordinates.length; i++){
        var colorLine = '';
        switch(coordinates[i].status){
            case 'CRITICAL':
                colorLine = '#fe0505';
                break;
            case 'REALIGN':
                colorLine = '#d2691e';
                break;
            case 'NOK':
                colorLine = '#cad100';
                break;
            case 'HIGH':
                colorLine = '#1e90ff';
                break;
            case 'OK':
                colorLine = '#189c06';
                break;
            default:
                colorLine = '#6d6860';
        }

        var iconLine = [];

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coordinates[i].lat_a), 'lng': Number(coordinates[i].long_a)}, {'lat': Number(coordinates[i].lat_z), 'lng': Number(coordinates[i].long_z)}],
            geodesic: true,
            strokeColor: colorLine,
            strokeOpacity: 1,
            strokeWeight: 3,
            icons: iconLine,
            id: coordinates[i].ots_id,
            id_frontend: coordinates[i].id_frontend,
            latZoom: coordinates[i].lat_a,
            lngZoom: coordinates[i].long_a,
            lat_a: coordinates[i].lat_a,
            long_a: coordinates[i].long_a,
            lat_z: coordinates[i].lat_z,
            long_z: coordinates[i].long_z
        });

        addClickLine(line);

        networkCoordinates.push(line);
    }
    return networkCoordinates;
}

function addNetworkCoordinates(networkCoordinates, visible){
    for(var i=0; i<networkCoordinates.length; i++){
        networkCoordinates[i].setMap(visible);
    }
}

function addClickLine(line){
    line.addListener('click', function() {
        addInfoLine(line.lat_a, line.long_a, line.lat_z, line.long_z);
    });
}

function initMap() {

    var styledMapType = new google.maps.StyledMapType(
            [{ "elementType": "geometry", "stylers": [ { "color": "#f5f5f5" } ] },
            { "elementType": "geometry.fill", "stylers": [ { "visibility": "simplified" } ] },
            //{ "elementType": "geometry.fill", "stylers": [ { "color": "#FFFAFA" } ] },
            { "elementType": "geometry.stroke", "stylers": [ { "visibility": "on" }, { "weight": 1 } ] },
            { "elementType": "labels.icon", "stylers": [ { "visibility": "off" } ] },
            { "elementType": "labels.text.fill", "stylers": [ { "color": "#9a9a9a" } ] },
            { "elementType": "labels.text.stroke", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [ { "color": "#bdbdbd" } ] },
            { "featureType": "poi", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "poi.park", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "road", "elementType": "geometry", "stylers": [ { "color": "#ffffff" } ] },
            { "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "road.highway", "elementType": "geometry", "stylers": [ { "color": "#dadada" } ] },
            { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [ { "color": "#616161" } ] },
            { "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "transit.line", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "transit.station", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "water", "elementType": "geometry", "stylers": [ { "color": "#c9c9c9" } ] },
            //{ "featureType": "water", "elementType": "geometry.fill", "stylers": [ {"color": "#F0FFFF"} ] },
            { "featureType": "water", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] } ],
            {name: 'Simples'});

    map = new google.maps.Map(document.getElementById('map'), {
      zoom: 4,
      center: new google.maps.LatLng(-18.891333, -48.258014),
      //mapTypeId: 'roadmap',
      //gestureHandling: 'cooperative',
      streetViewControl: false,
      zoomControl: false,
      fullscreenControl: true,
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain', 'styled_map']
        //mapTypeIds: []
      }
    });

    map.mapTypes.set('styled_map', styledMapType);
    //map.setMapTypeId('styled_map');

    var customControls = document.getElementById('customControls');
    createCustomControls(customControls);
    map.controls[google.maps.ControlPosition.TOP_RIGHT].push(customControls);

    var menuControls = document.getElementById('menuControls');
    createMenuControls(menuControls);
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(menuControls);

    map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('filtros'));

    map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(document.getElementById('imgReferencia'));

    markers = defineMarkers(spam);
    addMarkers(markers, map);
    networkCoordinates = defineNetworkCoordinates(spam);
    addNetworkCoordinates(networkCoordinates, map);

    fillResume(spam);
    fillReport();
    fillStatusResume(spam);

    document.getElementById('filterOtsSite').addEventListener("keydown", function(event) {
        if (event.key === "Enter") {
            goFilter();
        }
    });

    // Add a marker clusterer to manage the markers.
    // var markerCluster = new MarkerClusterer(map, markers,{imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
}

function initZoom(map){
    map.setCenter(new google.maps.LatLng(-18.891333, -48.258014));
    map.setZoom(4);
}

function showModal(type, div){
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function showModalProgress(div, type, div_progress){
        document.getElementById(div_progress).innerHTML = html_spinner;
        await sleep(1000);
        document.getElementById(div).style.display = type;
        document.getElementById(div_progress).innerHTML = html_resume_bt;
    }

    if(type === 'block' && div === 'modalTabelaDetalhes'){
        showModalProgress(div, type, 'progress_detalhes');
    } else {
        document.getElementById(div).style.display = type;
    }
}

function fillResume(data){
    /*
    var fields = data.length > 0 ? Object.keys(data[0]) : [];
    var fieldIndex = fields.indexOf('timestamp');
    fields.splice(fieldIndex, 1);
    */
    var fields = [
            'ots_id', 'site_a', 'uf_a', 'ne_a', 'site_z', 'uf_z', 'ne_z',
            'ots_label', 'status',
            'span_loss', 'span_loss_a_z', 'span_loss_z_a',
            'ref_att', 'ref_att_source', 'hist_att',
            'smtx_distance', 'smtx_att', 'smtx_dbkm', 'smtx_status',
            'raman', 'raman_gain_a_z', 'raman_target_a_z', 'raman_gain_z_a', 'raman_target_z_a',
            'port_label_a', 'port_label_z',
            'otdr', 'layer0',
            'vendor',
            'smtx_fiber_type', 'smtx_fiber_way',
            'regional', 'base',
            'site_name_a', 'city_a', 'address_a', 'neighborhood_a', 'lat_a', 'long_a',
            'site_name_z', 'city_z', 'address_z', 'neighborhood_z', 'lat_z', 'long_z'
    ]

    var html = ''
    var html_content_titles = data.length > 0 ? '' : '<th scope="col"></th>';
    var html_content_infos = data.length > 0 ? '' : '<tr><td>Nenhum registro encontrado...</td></tr>';

    for(i=0; i<data.length; i++){
        html_content_infos = html_content_infos + '<tr>';
        for(f=0; f<fields.length; f++){
            if(i==0){
                html_content_titles = html_content_titles + '<th scope="col">' + fields[f] + '</th>';
            }
            html_content_infos = html_content_infos + '<td>' + data[i][fields[f]] + '</td>';
        }
        html_content_infos = html_content_infos + '</tr>';
    }

    html = html + '<table class="table table-sm table-striped">'
    if(data.length > 0){
        html = html + '<thead><tr>' +
        '<th colspan="' + fields.length + '" scope="col">' +
        '<button id="detalhes_xls" class="btn btn-sm text-success" type="button" onclick="createXlsx()">' +
        '<i class="material-icons">file_download</i> Baixar em xlsx...' +
        '</button>' +
        '</th>' +
        '</tr></thead>'
    }
    html = html + '<thead><tr>' +
    html_content_titles +
    '</tr></thead><tbody>' +
    html_content_infos +
    '</tbody></table>'

    document.getElementById("modalTabela").innerHTML = html;
}

function addInfoLine(lat_a, long_a, lat_z, long_z){
    var lines = spam.filter(function(obj){
        return (obj.lat_a == lat_a &&
                obj.long_a == long_a &&
                obj.lat_z == lat_z &&
                obj.long_z == long_z)
    })

    /*
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    //TODO: busca com ajax e cria gráfico (instalar influxdb_client)
    function drawChart(){

    }
    */
    var html = '';
    lines.forEach(function(line){
        var span_loss = line.span_loss == 'N/A' ? 'N/A' : parseFloat(line.span_loss).toFixed(2);
        var ref_att = line.ref_att == 'N/A' ? 'N/A' : parseFloat(line.ref_att).toFixed(2);
        var smtx_distance = line.smtx_distance == 'N/A' ? 'N/A' : parseFloat(line.smtx_distance).toFixed(2);
        var smtx_dbkm = line.smtx_dbkm == 'N/A' ? 'N/A' : parseFloat(line.smtx_dbkm).toFixed(2);

        html = html +
        '<table class="table table-sm"><tbody>' +
        '<tr><th scope="row">OTS</th><td>' + line.ots_id + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Status</th><td>' + line.status + '</td></tr>' +
        '<tr><th scope="row">Site A</th><td>' + line.site_a + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Site Z</th><td>' + line.site_z + '</td></tr>' +
        '<tr><th scope="row">NE A</th><td>' + line.ne_a + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">NE Z</th><td>' + line.ne_z + '</td></tr>' +
        '<tr><th scope="row">Span LOS</th><td>' + span_loss + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Reference LOS</th><td>' + ref_att + '</td></tr>' +
        '<tr><th scope="row">Span length</th><td>' + smtx_distance + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Reference Source</th><td>' + line.ref_att_source + '</td></tr>' +
        '<tr><th scope="row">dB / Km</th><td>' + smtx_dbkm + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Raman</th><td>' + line.raman + '</td></tr>' +
        '<tr><th scope="row">Vendor</th><td>' + line.vendor + '</td>' +
        '<td>&nbsp;&nbsp;</td>' +
        '<th scope="row">Base</th><td>' + line.base.toUpperCase() + '</td></tr>' +

        '<tr><th scope="row">Timestamp</th><td colspan="4">' + line.timestamp_format + '</td>' +

        '</tbody></table>' +
        '<hr>'
    })

    document.getElementById("modalInfo").innerHTML = html;
    showModal('block', 'modalLineInfo');
}

function goFilter(){
    /*
    document.getElementById('filterButton').innerHTML = '';
    document.getElementById('filterButton').classList.add("spinner-border");
    document.getElementById('filterButton').classList.add("text-secondary");
    */

    function listSelected(field){
        var select = document.getElementById(field);
        var selected = [...select.selectedOptions].map(option => option.value);
        return selected;
    }

    var tableF = [];
    var markersF = [];
    var networkCoordinatesF = [];
    var idFrontendF = [];

    var ots = document.getElementById('filterOtsSite').value;

    var regional = listSelected('filterRegional').length > 0 ? listSelected('filterRegional') : ['Centralizado_O&M', 'Centro-Oeste', 'Nordeste', 'Sao Paulo', 'Sudeste', 'Sul'];
    var vendor = listSelected('filterVendor').length > 0 ? listSelected('filterVendor') : ['Ciena', 'Huawei', 'Nokia'];
    var status = listSelected('filterStatus').length > 0 ? listSelected('filterStatus') : ['OK', 'NOK', 'CRITICAL', 'HIGH', 'REALIGN', 'N/A'];
    var otdr = document.getElementById('filterOtdr').value == '' ?  ['Sim', 'Não'] : [document.getElementById('filterOtdr').value];
    var raman = document.getElementById('filterRaman').value == '' ?  ['Sim', 'Não'] : [document.getElementById('filterRaman').value];
    var rede = document.getElementById('filterRede').value == '' ?  ['smtx', 'fenix'] : [document.getElementById('filterRede').value];
    var layer = document.getElementById('filterLayer').value == '' ?  ['Sim', 'Não'] : [document.getElementById('filterLayer').value];

    // Preencher tabela (usar spam)
    if(ots.trim() == ''){
        tableF = spam.filter(function(obj){
                return (vendor.includes(obj.vendor) &&
                        regional.includes(obj.regional) &&
                        status.includes(obj.status) &&
                        otdr.includes(obj.otdr) &&
                        raman.includes(obj.raman) &&
                        rede.includes(obj.base) &&
                        layer.includes(obj.layer0)
                        )
                })
        initZoom(map);
    } else {
        tableF = spam.filter(function(obj){
                return ((obj.ots_label.toUpperCase().includes(ots.toUpperCase()) ||
                            obj.site_a.toUpperCase().includes(ots.toUpperCase()) ||
                            obj.site_z.toUpperCase().includes(ots.toUpperCase()) ||
                            obj.city_a.toUpperCase().includes(ots.toUpperCase()) ||
                            obj.city_z.toUpperCase().includes(ots.toUpperCase())) &&
                        vendor.includes(obj.vendor) &&
                        regional.includes(obj.regional) &&
                        status.includes(obj.status) &&
                        otdr.includes(obj.otdr) &&
                        raman.includes(obj.raman) &&
                        rede.includes(obj.base) &&
                        layer.includes(obj.layer0)
                        )
                })
        if(tableF.length > 0){
            map.setCenter(new google.maps.LatLng(tableF[0].lat_a, tableF[0].long_a));
            map.setZoom(6);
        } else {
            initZoom(map);
        }
    }
    fillResume(tableF);
    fillStatusResume(tableF);
    spam_filtered = tableF;

    tableF.forEach(function(item){
        idFrontendF.push(item.id_frontend);
    })

    // Plotar apenas filtrados (buscar markers e networkCoordinates pelo inverso e chamar addMarkers null)
    markersF = markers.filter(function(obj){
            return (idFrontendF.includes(obj.id_frontend))
            })
    networkCoordinatesF = networkCoordinates.filter(function(obj){
            return (idFrontendF.includes(obj.id_frontend))
            })

    addMarkers(markers, null)
    addMarkers(markersF, map);
    addNetworkCoordinates(networkCoordinates, null)
    addNetworkCoordinates(networkCoordinatesF, map);

    /*
    document.getElementById('filterButton').innerHTML = '<button class="btn btn-outline-secondary btn-sm" onclick="goFilter()"> >> </button>';
    document.getElementById('filterButton').classList.remove("spinner-border");
    document.getElementById('filterButton').classList.remove("text-secondary");

    if(idFrontendF.length == 0){
        swal("", "Nenhum registro encontrado!!!", "warning", {buttons: false, timer: 1000});
    }
    */
}

function fillReport(){
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var colorSlice = ['#ff0000', '#1e90ff', '#6d6860', '#ffff00', '#008000', '#d2691e'];

        var dataStatus = google.visualization.arrayToDataTable(report['Status']['data']);
        var optionsStatus = {title: report['Status']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartStatus = new google.visualization.PieChart(document.getElementById('statusChart')).draw(dataStatus, optionsStatus);

        var dataVendor = google.visualization.arrayToDataTable(report['Vendor']['data']);
        var optionsVendor = {title: report['Vendor']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}};
        var chartVendor = new google.visualization.PieChart(document.getElementById('vendorChart')).draw(dataVendor, optionsVendor);

        var dataCiena = google.visualization.arrayToDataTable(report['Ciena']['data']);
        var optionsCiena = {title: report['Ciena']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartCiena = new google.visualization.PieChart(document.getElementById('cienaChart')).draw(dataCiena, optionsCiena);

        var dataNokia = google.visualization.arrayToDataTable(report['Nokia']['data']);
        var optionsNokia = {title: report['Nokia']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartNokia = new google.visualization.PieChart(document.getElementById('nokiaChart')).draw(dataNokia, optionsNokia);

        var dataHuawei = google.visualization.arrayToDataTable(report['Huawei']['data']);
        var optionsHuawei = {title: report['Huawei']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartHuawei = new google.visualization.PieChart(document.getElementById('huaweiChart')).draw(dataHuawei, optionsHuawei);
        /*
        var dataHuaweiBBN = google.visualization.arrayToDataTable(report['Huawei BBN']['data']);
        var optionsHuaweiBBN = {title: report['Huawei BBN']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartHuaweiBBN = new google.visualization.PieChart(document.getElementById('huaweiBbnChart')).draw(dataHuaweiBBN, optionsHuaweiBBN);

        var dataHuaweiSP = google.visualization.arrayToDataTable(report['Huawei SP']['data']);
        var optionsHuaweiSP = {title: report['Huawei SP']['title'], pieHole: 0.5, pieSliceText: 'none', legend: {position : 'labeled'}, colors: colorSlice};
        var chartHuaweiSP = new google.visualization.PieChart(document.getElementById('huaweiSpChart')).draw(dataHuaweiSP, optionsHuaweiSP);
        */
      }
}

function fillStatusResume(data){

    function reduceFunc(obj, prop) {
      return obj.reduce(function (acc, item) {
        let key = item[prop]
        if (!acc[key]) {
          acc[key] = []
        }
        acc[key].push(item)
        return acc
      }, {})
    }

    var dataReduce = reduceFunc(data, 'status');
    var listStatus = [['REALIGN', 'ref-th-realign'],
                      ['HIGH', 'ref-th-high'],
                      ['OK', 'ref-th-ok'],
                      ['NOK', 'ref-th-nok'],
                      ['CRITICAL', 'ref-th-critical'],
                      ['N/A', 'ref-th-na'],]

    for(i=0; i<listStatus.length; i++){
        if(dataReduce.hasOwnProperty(listStatus[i][0])){
            document.getElementById(listStatus[i][1]).innerHTML = listStatus[i][0] +
                                                                    ' (' +
                                                                    dataReduce[listStatus[i][0]].length +
                                                                    ')';
        } else {
            document.getElementById(listStatus[i][1]).innerHTML = listStatus[i][0] +
                                                                    ' (0)';
        }
    }

    document.getElementById('total_registros').innerHTML = data.length + ' registros...';
}

function cleanSearch(){
    $('.selectpicker').selectpicker('val', '');
    document.getElementById('filterOtsSite').value = '';
    goFilter();
}
