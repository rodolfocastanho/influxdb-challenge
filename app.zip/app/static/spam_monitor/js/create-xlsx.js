function s2ab(s) {
    var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
    var view = new Uint8Array(buf);  //create uint8array as viewer
    for (var i=0; i<s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
    return buf;
}

function createXlsx(){
    var wb = XLSX.utils.book_new();

    var CreatedDateFull = new Date(Date.now());
    var FileName = 'SpanMonitor_'+String(CreatedDateFull.getFullYear())+
                                    String(CreatedDateFull.getMonth()).padStart(2, "0")+
                                    String(CreatedDateFull.getDay()).padStart(2, "0")+'.xlsx'
    wb.Props = {
        Title: "Span Monitor",
        Subject: "Span Monitor",
        Author: "Portal BackboneTX",
        CreatedDate: CreatedDateFull
    };

    wb.SheetNames.push("Detalhes");
    var ws_data = createObjectTable();
    var ws = XLSX.utils.json_to_sheet(ws_data);
    wb.Sheets["Detalhes"] = ws;

    var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), FileName);
}

function createObjectTable(){
    /*
    var fields = Object.keys(spam[0]);
    var fieldsIgnore = ['timestamp', 'id_frontend'];
    fieldsIgnore.forEach(function(item){
        var fieldIndex = fields.indexOf(item);
        fields.splice(fieldIndex, 1);
    })
    */
    var fields = [
            'ots_id', 'site_a', 'uf_a', 'ne_a', 'site_z', 'uf_z', 'ne_z',
            'ots_label', 'status',
            'span_loss', 'span_loss_a_z', 'span_loss_z_a',
            'ref_att', 'ref_att_source', 'hist_att',
            'smtx_distance', 'smtx_att', 'smtx_dbkm', 'smtx_status',
            'raman', 'raman_gain_a_z', 'raman_target_a_z', 'raman_gain_z_a', 'raman_target_z_a',
            'port_label_a', 'port_label_z',
            'otdr', 'layer0',
            'vendor',
            'smtx_fiber_type', 'smtx_fiber_way',
            'regional', 'base',
            'site_name_a', 'city_a', 'address_a', 'neighborhood_a', 'lat_a', 'long_a',
            'site_name_z', 'city_z', 'address_z', 'neighborhood_z', 'lat_z', 'long_z'
    ]

    var data = new Array();

    for(i=0; i<spam_filtered.length; i++){
        var obj = new Object();

        for(f=0; f<fields.length; f++){
            obj[fields[f]] = spam_filtered[i][fields[f]]
        }

        data.push(obj);
    }

    return data;
}
