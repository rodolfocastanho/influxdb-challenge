
function plot(map){
    buscaInfos(map);
    // sleep 1 hora
    // Call plot(map)
}

// 1 - Buscar informações de topologia e tickets (ajax)
function buscaInfos(map){
    $.ajax({
        url: '/ajax-falhas',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            [markers, lines] = addTopology(response['topology'], map);
            console.log(response['tickets']);
        },
        error: function(error){
            swal("", "Erro ao buscar informações!!", "warning", {buttons: false, timer: 1500});
        }
    });
}

function teste(){
    return [37, 'Flavio'];
}

// 2 - Plotar topologia (sem cor)
function addTopology(data, map){

    dataMarkers = [];
    dataLines = [];

    for(var c=0; c<data.length; c++){
        color = '#8B8989';
        createMarker(data[c], map, 6);
        createLine(data[c], map, color);
    }

    // TODO: Filtrar em dataMarkers e dataLines OMS's com ticket
        //var site = markers.find(function(obj){return obj.site + "." + obj.uf == txt.value.toUpperCase()});
    // TODO: Chamar função para alteração das linhas e marcadores
    // TODO: Criar legenda com infos dos tickets e onclick para zoom
        //map.setCenter(new google.maps.LatLng(municipio["latitude"], municipio["longitude"]));
        //map.setZoom(10);

    return [dataMarkers, dataLines]
    // [var ticketsMarkers, ticketLines]

    var lineSymbol = {
        path: 'M 0,-1 0,1',
        //strokeOpacity: 1,
        strokeColor: '#DCDCDC',
        scale: 2
      };

    function createMarker(coord, map, scaleIcon){
        var markerA = new google.maps.Marker({
            label: null,
            site: coord.SiteA + '.' + coord.UFA,
            oms: coord.Numero,
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                scaledSize: { height: scaleIcon, width: scaleIcon },
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            label: null,
            site: coord.SiteB + '.' + coord.UFB,
            oms: coord.Numero,
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                scaledSize: { height: scaleIcon, width: scaleIcon },
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        dataMarkers.push(markerA);
        dataMarkers.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLine(coord, map, color){
        iconLine = []
        if(coord.Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 3,
            strokeWeight: 1,
            icons: iconLine,
            oms: coord.Numero
        })

        dataLines.push(line);
        line.setMap(map);
    }
}



// 3 - Em tickets, alterar cor na topologia plotada
// 4 - na div legend, lista de tickets (onclick = zoom ptA OMS)
// 5 - Aguardar 1 hora, repetir o processo

function initZoom(map){
    map.setCenter(new google.maps.LatLng(-15.7797203, -47.9297218));
    map.setZoom(5);
}

function createCustomControls(customControls){
    var div = document.createElement('div');
    var html = '' +
    //'<img id="reportIcon" src="img/icons/report.png" alt="Resumo" onclick="showReport(map, report)">' +
    //'<hr>' +
    '<img id="zoomIcon" src="static/map/img/icons/zoom.png" alt="Visão Geral" onclick="initZoom(map)">'
    div.innerHTML = html;
    customControls.appendChild(div);
}
