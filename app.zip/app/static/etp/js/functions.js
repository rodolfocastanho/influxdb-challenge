html_spinner = '<div class="d-flex justify-content-center"><div class="spinner-border text-primary" role="status"></div></div>'

var lineSymbol = {
    path: 'M 0,-1 0,1',
    //strokeOpacity: 1,
    strokeColor: '#DCDCDC',
    scale: 4
};

var etps_result;
var topologyBase;
var sitesBase;
var planBase;
var planSitesBase = new Array(0);
var executionErrors;
var map;
var supports;
var newValidation;

var searchEtp = document.getElementById('search-etp');
var topology = document.getElementById('topology');
var statusEtp = document.getElementById('status-etp');
var cpomEtp = document.getElementById('cpom-etp');
var resumeEtp = document.getElementById('resume-etp');

var modalDetailsEtps = document.getElementById('modal-details-etp');
var btNewEtp = document.getElementById('bt-new-etp');
var listEtps = document.getElementById('etp-list');

var statusEtpTxt = document.getElementById('status-etp-text');
//var statusEtpPmts = document.getElementById('status-etp-pmts');
var valorT2Txt = document.getElementById('t2-total-text');
var valorPcTxt = document.getElementById('t2-pc-text');
var valorNfTxt = document.getElementById('t2-nf-text');

var etpMarkers = [];
var etpLines = [];

function defineNetworkCoordinates(coordinates, lineColor, lineStrokeWeight, lineStrokeOpacity, lineType='base'){
    var networkCoordinates = [];

    for(var i=0; i<coordinates.length; i++){
        iconLine = []
        var etp = coordinates[i].etp !== undefined ? coordinates[i].etp : '';
        var rota = coordinates[i].Rota !== undefined ? coordinates[i].Rota : '';

        switch(lineColor){
            case 'etp':
            case 'EILD':
                colorLine = coordinates[i].color;
                break;
            case 'LEGADO':
                colorLine = '#363636';
                break;
            case 'base':
                colorLine = '#778899';
                break;
            case 'plan':
                colorLine = '#FF0000';
                defineMarkers([
                        {'type': 'PLAN', 'idWDMOMS': '0', 'Latitude': coordinates[i].LatitudeA, 'Longitude': coordinates[i].LongitudeA},
                        {'type': 'PLAN', 'idWDMOMS': '0', 'Latitude': coordinates[i].LatitudeB, 'Longitude': coordinates[i].LongitudeB}
                    ], 6, 'plan', true).forEach(function(item){
                        planSitesBase.push(item);
                    });
                break;
            default:
                colorLine = '#778899';
        }

        if(coordinates[i].Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coordinates[i].LatitudeA), 'lng': Number(coordinates[i].LongitudeA)}, {'lat': Number(coordinates[i].LatitudeB), 'lng': Number(coordinates[i].LongitudeB)}],
            geodesic: true,
            strokeColor: colorLine,
            strokeOpacity: lineStrokeOpacity,
            strokeWeight: lineStrokeWeight,
            icons: iconLine,
            type: lineType,
            id: coordinates[i].idWDMOMS,
            latZoom: coordinates[i].LatitudeA,
            lngZoom: coordinates[i].LongitudeA,
            etp: etp,
            Rota: rota
        });

        if(coordinates[i].Details !== undefined){
            addListener(line, coordinates[i], lineType);
        }

        networkCoordinates.push(line);
    }
    return networkCoordinates;
}

function addNetworkCoordinates(networkCoordinates, visible){
    for(var i=0; i<networkCoordinates.length; i++){
        networkCoordinates[i].setMap(visible);
    }
}

function addListener(line, coordinate, type){
    line.addListener('click', function() {
        //showInfoLine(coordinate.LatitudeA, coordinate.LongitudeA, coordinate.LatitudeB, coordinate.LongitudeB);
        document.getElementById('info-line-title').textContent = 'Detalhes ' + type + ' ' + coordinate.idWDMOMS;
        document.getElementById('info-line-body').innerHTML = coordinate.Details;
        document.getElementById('info-line').style.display = "block";
    });
}

function hideInfoLine(){
    document.getElementById('info-line-title').textContent = '';
    document.getElementById('info-line-body').innerHTML = '';
    document.getElementById('info-line').style.display = "none";
}

function defineMarkers(loc, scaleIcon, typeIcon, baseIcon=false){
    var markers = [];

    for(var i=0; i<loc.length; i++){
        var labelObj = (baseIcon) ? null : {text: loc[i].idWDMOMS, color: 'black', fontSize: "14px"};
        labelObj = (typeIcon == 'router' && loc[i].Camada !== '' && baseIcon) ? {text: loc[i].Camada+' ('+loc[i].Site+')', color: 'black', fontSize: "14px"} : labelObj;
        labelObj = (typeIcon == 'router' && !baseIcon) ? null : labelObj;

        var etp = loc[i].etp !== undefined ? loc[i].etp : '';
        var rota = loc[i].Rota !== undefined ? loc[i].Rota : '';

        switch(typeIcon){
            case 'etp':
                locIcon = loc[i].icon;
                break;
            case 'router':
                locIcon = loc[i].icon;
                break;
            case 'base':
                locIcon = 'Outros';
                break;
            case 'plan':
                locIcon = 'Ciena';
                break;
            default:
                locIcon = 'Outros';
        };

        var icon = {
            url: iconBase + 'vendor/' + locIcon + '/Outros.png',
            scaledSize: { height: scaleIcon, width: scaleIcon },
            labelOrigin: new google.maps.Point(0, -4)
        }

        var marker = new google.maps.Marker({
            label: labelObj,
            type: loc[i].type,
            id: loc[i].idWDMOMS,
            lat: loc[i].Latitude,
            lng: loc[i].Longitude,
            icon: icon,
            etp: etp,
            Rota: rota,
            position: new google.maps.LatLng(loc[i].Latitude, loc[i].Longitude)
        });

        if(baseIcon){
            marker.Site = loc[i].Site;
            marker.Uf = loc[i].UF;
            addClickMarker(marker, loc[i].Site+'.'+loc[i].UF)
        }
        markers.push(marker);
    };

    return markers;
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

function addClickMarker(marker, label){
    marker.addListener('click', function() {
      if(marker.label == null){
        marker.setLabel({text: label, color: '#363636', fontSize: '12px'});
      } else  {
        marker.setLabel(null);
      }
    });
}

function showLabel(map){
    var x = '2.0';
    var markersFiltered = sitesBase.filter(function(obj){
        return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
    });

    for (var i = 0; i < markersFiltered.length; i++){
        markersFiltered[i].setLabel({text: markersFiltered[i].Site+'.'+markersFiltered[i].Uf, color: '#363636', fontSize: '12px'});
    }
}

function hideLabel(map){
    for (var i = 0; i < sitesBase.length; i++){
        sitesBase[i].setLabel(null);
    }
}

function visibleElements(status){
    statusEtp.style.display = status;
    cpomEtp.style.display = status;
    resumeEtp.style.display = status;
}

function addTopologyBase(cb){
    var visible;

    if(cb.checked){
        visible = map;
        if(document.getElementById('topology-plan').checked){
            document.getElementById('topology-plan').click();
        }
        document.getElementById('topology-base-label').innerHTML = '(Label' +
                                                         '&nbsp;&nbsp;' +
                                                         '<a style="font-size: 16px" href="#" onclick="showLabel(map)">+</a>' +
                                                         '&nbsp;&nbsp;' +
                                                         '<a style="font-size: 16px" href="#" onclick="hideLabel(map)">-</a>' +
                                                         ')';
    } else {
        visible = null;
        document.getElementById('topology-base-label').innerHTML = '';
    }

    addNetworkCoordinates(topologyBase, visible);
    addMarkers(sitesBase, visible);
}

function addTopologyPlan(cb){
    var visible;

    if(cb.checked){
        visible = map;
        if(document.getElementById('topology-check').checked){
            document.getElementById('topology-check').click();
            document.getElementById('topology-base-label').innerHTML = '';
        }
    } else {
        visible = null;
    }

    addNetworkCoordinates(planBase, visible);
    addMarkers(planSitesBase, visible);
}

function showDetailsEtp(etps_result, len_result){
    //statusEtpPmts.innerHTML = (resumes['PMTS']['status'].length < 13) ? resumes['PMTS']['status'] : resumes['PMTS']['status'].substring(0, 10) + '...';
    //statusEtpPmts.setAttribute('title',resumes['PMTS']['status']);
    vT2 = 0;
    vPc = 0;
    vNf = 0;
    vStatus = [];

    Object.keys(etps_result).forEach(function(item){
        vT2 = vT2 + etps_result[item]['resumes']['T2'][0]['ValorTotal'];
        vPc = vPc + etps_result[item]['resumes']['T2'][0]['ValorPC'];
        vNf = vNf + etps_result[item]['resumes']['T2'][0]['ValorFaturado'];

        vStatus.push(etps_result[item]['resumes']['ETP']['status']);
    });

    if (vStatus.includes('Em Engenharia')){
        vStatusEtp = 'Em Engenharia';
    } else if (vStatus.includes('Em Implantação')){
        vStatusEtp = 'Em Implantação';
    } else if (vStatus.includes('Em O&M')){
        vStatusEtp = 'Em O&M';
    } else if (vStatus.includes('Devolvida')){
        vStatusEtp = 'Devolvida';
    } else if (vStatus.includes('Concluída')){
        vStatusEtp = 'Concluída';
    } else if (vStatus.includes('Cancelada')){
        vStatusEtp = 'Cancelada';
    } else {
        vStatusEtp = 'Em Engenharia';
    }

    if(len_result>1){
        // style="cursor:pointer" onclick="showModalDetails(\'none\', \'status_cpom\')
        statusEtpTxt.innerHTML = '<abbr title="ver detalhes" onclick="showModalDetails(\'block\', \'status_cpom\')">' + vStatusEtp + '</abbr>';
        valorT2Txt.innerHTML = '<abbr title="ver detalhes" onclick="showModalDetails(\'block\', \'status_cpom\')">R$ ' + parseFloat(Math.round(vT2 * 100) / 100).toLocaleString('pt-BR') + '</abbr>';
        valorPcTxt.innerHTML = '<abbr title="ver detalhes" onclick="showModalDetails(\'block\', \'status_cpom\')">R$ ' + parseFloat(Math.round(vPc * 100) / 100).toLocaleString('pt-BR') + '</abbr>';
        valorNfTxt.innerHTML = '<abbr title="ver detalhes" onclick="showModalDetails(\'block\', \'status_cpom\')">R$ ' + parseFloat(Math.round(vNf * 100) / 100).toLocaleString('pt-BR') + '</abbr>';
    } else {
        statusEtpTxt.innerHTML = vStatusEtp;
        valorT2Txt.innerHTML = 'R$ ' + parseFloat(Math.round(vT2 * 100) / 100).toLocaleString('pt-BR')
        valorPcTxt.innerHTML = 'R$ ' + parseFloat(Math.round(vPc * 100) / 100).toLocaleString('pt-BR')
        valorNfTxt.innerHTML = 'R$ ' + parseFloat(Math.round(vNf * 100) / 100).toLocaleString('pt-BR')
    }
}

function cleanInfos(){
    resumeEtp.innerHTML = '';

    modalDetailsEtps.innerHTML = '';

    statusEtpTxt.innerHTML = '';
    //statusEtpPmts.innerHTML = '';
    //statusEtpPmts.setAttribute('title','');
    valorT2Txt.innerHTML = '';
    valorPcTxt.innerHTML = '';
    valorNfTxt.innerHTML = '';
}

function goSearchEtp(map){
    for (var i = 0; i < sitesBase.length; i++){
        sitesBase[i].setLabel(null);
    }

    var etp = (document.getElementById("filter-group").value == 'etp') ? document.getElementById("etp-text").value : document.getElementById("filter-group").value;
    var group = document.getElementById("filter-group").value;

    if(etp.replaceAll(' ', '').length>6){
        document.getElementById("progress").innerHTML = html_spinner;
        etpMarkers.concat(etpLines).forEach(function(item){
            item.setMap(null);
        });
        resumes = null;
        details = null;
        visibleElements('none');
        cleanInfos();
        map.setZoom(5);
        map.setCenter(new google.maps.LatLng(-15.7797203, -47.9297218));

        $.ajax({
            url: '/ajax-etps',
            data: {
              etp: String(etp),
              group: String(group)
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                executionErrors = response['errors'];
                if(Object.keys(response['etps_result']).length == 0){
                    swal("", "Nenhuma informação encontrada!!", "warning", {buttons: false, timer: 2000});
                } else {
                    etps_result = response['etps_result'];
                    newValidation = response['NEW_VALIDATION'];
                    var randomPosition = fillResumeEtp(map, etps_result, Object.keys(etps_result).length);
                    showDetailsEtp(etps_result, Object.keys(etps_result).length);

                    visibleElements('block');
                    map.setCenter(new google.maps.LatLng(randomPosition.lat, randomPosition.lng));
                    map.setZoom(6);
                }
                document.getElementById('progress').innerHTML = '';
            },
            error: function(error){
                console.log(error);
                swal("", "Erro ao buscar informações!!", "warning", {buttons: false, timer: 2000});
                document.getElementById("progress").innerHTML = "";
            }
        });
    }
}

function fillResumeEtp(map, etps_result, len_result){
    var random;
    etpMarkers = [];
    etpLines = [];
    html_table_resume_total = '';
    html_modal_etp = '';
    var expanded = (len_result==1) ? ['true', 'show'] : ['false', ''];

    Object.keys(etps_result).forEach(function(item){
        /*
        if(Object.keys(etps_result[item]['resumes']['CIRCUITOS']).length>0){
            Object.keys(etps_result[item]['resumes']['CIRCUITOS']).forEach(function(circuito) {
                if(circuito === '0'){
                    etps_result[item]['resumes']['CIRCUITOS'][circuito].forEach(function(c_item){
                        c_item['Rota'] = '-';
                    })
                    Object.defineProperty(etps_result[item]['resumes']['CIRCUITOS'], '-', Object.getOwnPropertyDescriptor(etps_result[item]['resumes']['CIRCUITOS'], circuito));
                    delete etps_result[item]['resumes']['CIRCUITOS'][circuito];
                } else {
                    etps_result[item]['resumes']['CIRCUITOS'][circuito].forEach(function(c_item){
                        c_item['Rota'] = 'ROTA '+circuito;
                    })
                    Object.defineProperty(etps_result[item]['resumes']['CIRCUITOS'], 'ROTA '+circuito, Object.getOwnPropertyDescriptor(etps_result[item]['resumes']['CIRCUITOS'], circuito));
                    delete etps_result[item]['resumes']['CIRCUITOS'][circuito];
                }
            })
        }
        */

        var etp = item;
        var fibras_info = (etps_result[item]['resumes']['FIBRAS_INFO'].length>0) ? true : false;
        var plotSites = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['MUX', 'PLACA', 'ENVOLVIDOS'].includes(obj.element)});
        var plotOMS = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['OMS'].includes(obj.element)});
        var plotOTS = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['OTS'].includes(obj.element)});
        var plotOCH = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['OCH'].includes(obj.element)});
        var plotODU = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['ODU'].includes(obj.element)});
        var plotCIRCUITOS = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return ['EILD', 'LEGADO'].includes(obj.element)});
        var rotaCIRCUITOS = etps_result[item]['resumes']['CIRCUITOS']
        var plotSitesCIRCUITOS = etps_result[item]['resumes']['PLOTS'].filter(function(obj){return obj.element == 'ROUTER'});
        var position = false;
        var sites = [];
        var sitesEnvolvidos = [];
        var omss = [];
        var otss = [];
        var ochs = [];
        var odus = [];
        var circuitos = [];
        var routers = [];
        var etps_infos = (etps_result[item]['details'].hasOwnProperty('data_etps_infos')) ? true : false;

        html_table_resume = ''
        html_table_oms = ''
        html_table_ots = ''
        html_table_site = ''
        html_table_och = ''
        html_table_odu = ''
        html_table_circuito = ''
        html_table_ped = ''

        html_table_resume = html_table_resume +
        '<table class="table table-borderless form-check">' +
        '<thead>' +
        '<tr>' +
        '<th style="vertical-align: top" scope="col"><input id="checkElements_'+ etp + '" class="form-check-input" checked type="checkbox" checked onclick="checkPlotElements(this, map, \'' + etp +  '\', \'ETP\')"></th>' +
        '<th style="vertical-align: bottom" colspan="2" scope="col">'
        if(etps_result[item]['details']['ATRIBUTOS'] && etps_result[item]['details']['ATRIBUTOS']['cancelamento']){
            html_table_resume = html_table_resume + '<span class="text-danger">';
        } else {
            html_table_resume = html_table_resume + '<span>';
        }
        var textoResumo = (etps_result[item]['details'].hasOwnProperty('data_etps_infos')) ? document.getElementById('filter-group').options[document.getElementById('filter-group').selectedIndex].text : etp;
        html_table_resume = html_table_resume + 'Resumo ETP ' + textoResumo +
        //details['ATRIBUTOS']
        '<a data-toggle="collapse" href="#collapseETP_' + etp + '" aria-expanded="' + expanded[0] + '" aria-controls="collapseETP_' + etp + '">&nbsp;+</a>' +
        '</span>'+
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody class="collapse multi-collapse ' + expanded[1] + '" id="collapseETP_' + etp + '">'

        if(etps_result[item]['resumes']['ETP']['oes']){
            //SITES
            if(plotSites.length>0){
                html_table_site = html_table_site +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_SITES" class="form-check-input" type="checkbox" checked onclick="checkPlotElements(this, map, \'' + etp +  '\', \'SITE\')"></td>' +
                '<td colspan="2" scope="row">' +
                '<a data-toggle="collapse" href="#collapseSITES_' + etp + '" aria-expanded="false" aria-controls="collapseSITES_' + etp + '">Sites +</a>' +
                '</td>' +
                '</tr>'

                plotSites.forEach(function(item){
                    var statusColor;
                    var statusDesc;
                    var iconDimension;

                    if(item.element === 'ENVOLVIDOS'){
                        statusColor = ['Outros', 'text-black-50'];
                        statusDesc = 'Envolvido';
                    } else {
                        statusColor = (['Concluida'].includes(item.status)) ? ['Huawei', 'text-success'] : ['Nokia', 'text-warning'];
                        statusDesc = item.status;
                    }

                    var siteTemp = {
                        'icon': statusColor[0],
                        'type': item.element,
                        'idWDMOMS': item.id,
                        'Latitude': item.data.Latitude,
                        'Longitude':item.data.Longitude,
                        'etp': etp
                    }

                    if(item.element === 'ENVOLVIDOS'){
                        sitesEnvolvidos.push(siteTemp);
                    } else {
                        sites.push(siteTemp);
                    }

                    html_table_site = html_table_site +
                    '<tr class="collapse multi-collapse" id="collapseSITES_' + etp + '">' +
                    '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" checked onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                    '<td>' + item.id + '</td>' +
                    '<td class="' + statusColor[1] + '">' + statusDesc + '</td>' +
                    '</tr>'
                });

                defineMarkers(sites, 12, 'etp', etps_infos).forEach(function(site){
                    etpMarkers.push(site);
                });
                defineMarkers(sitesEnvolvidos, 8, 'etp', etps_infos).forEach(function(site){
                    etpMarkers.push(site);
                });
                addMarkers(etpMarkers.filter(function(obj){return obj.etp == etp}), map);

                if(!position){
                    position = true;
                    random = etpMarkers[Math.floor(Math.random() * etpMarkers.length)];
                    //map.setCenter(new google.maps.LatLng(random.lat, random.lng));
                }
            }

            // OMS
            if(plotOMS.length>0){
                html_table_oms = html_table_oms +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_OMS" class="form-check-input" type="checkbox" checked onclick="checkPlotElements(this, map, \'' + etp +  '\', \'OMS\')"></td>' +
                '<td colspan="4" scope="row">' +
                '<a data-toggle="collapse" href="#collapseOMS_' + etp + '" aria-expanded="false" aria-controls="collapseOMS_' + etp + '">OMS +</a>' +
                '</td>' +
                '</tr>'

                plotOMS.forEach(function(item){
                    var statusColor = (['Concluida'].includes(item.status)) ? ['#189c06', 'text-success'] : ['#cad100', 'text-warning'];
                    var checkedHtml = '';

                    item.data.forEach(function(data){
                        omss.push({
                            'color': statusColor[0],
                            'type': item.element,
                            'idWDMOMS': item.id,
                            'LatitudeA': data.LatitudeA,
                            'LongitudeA':data.LongitudeA,
                            'LatitudeB': data.LatitudeB,
                            'LongitudeB':data.LongitudeB,
                            'Status': data.Status,
                            'etp': etp,
                            'Rota': 'N'
                        });
                    });

                    if(item.data.length>0){
                        if(item.data[0].SiteA+item.data[0].UFA == item.data[0].SiteB+item.data[0].UFB){
                            checkedHtml = '' +
                            '<td>&nbsp;</td>' +
                            '<td>' + item.id + '</td>'+
                            '<td>' + item.data[0].SiteA+'.'+item.data[0].UFA + '</td>' +
                            '<td>' + item.data[0].SiteB+'.'+item.data[0].UFB + '</td>';
                        } else {
                            checkedHtml = '' +
                            '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" checked onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                            '<td>' + item.id + '</td>' +
                            '<td>' + item.data[0].SiteA+'.'+item.data[0].UFA + '</td>' +
                            '<td>' + item.data[0].SiteB+'.'+item.data[0].UFB + '</td>';
                        }
                    } else {
                        checkedHtml = '' +
                        '<td>&nbsp;</td>' +
                        '<td>' + item.id + '</td>'+
                        '<td>' + item.SiteA + '</td>' +
                        '<td>' + item.SiteB + '</td>';
                    }

                    html_table_oms = html_table_oms +
                    '<tr class="collapse multi-collapse" id="collapseOMS_' + etp + '">' +
                    checkedHtml +
                    '<td class="' + statusColor[1] + '">' + item.status + '</td>' +
                    '</tr>'
                });

                defineNetworkCoordinates(omss, 'etp', 2, 1, 'OMS').forEach(function(oms){
                    etpLines.push(oms);
                });
                addNetworkCoordinates(etpLines.filter(function(obj){return obj.etp == etp && obj.type == 'OMS'}), map);

                if(!position){
                    position = true;
                    random = etpLines[Math.floor(Math.random() * etpLines.length)];
                    //map.setCenter(new google.maps.LatLng(random.latZoom, random.lngZoom));
                }
            }

            // OTS
            if(plotOTS.length>0){
                html_table_ots = html_table_ots +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_OTS" class="form-check-input" type="checkbox" onclick="checkPlotElements(this, map, \'' + etp +  '\', \'OTS\')"></td>' +
                '<td colspan="5" scope="row">' +
                '<a data-toggle="collapse" href="#collapseOTS_' + etp + '" aria-expanded="false" aria-controls="collapseOTS_' + etp + '">OTS +</a>' +
                '</td>' +
                '</tr>'

                plotOTS.forEach(function(item){
                    var statusColor = ['#0000CD', 'text-primary'];

                    item.data.forEach(function(data){
                        otss.push({
                            'color': statusColor[0],
                            'type': item.element,
                            'idWDMOMS': item.id,
                            'LatitudeA': data.LatitudeA,
                            'LongitudeA':data.LongitudeA,
                            'LatitudeB': data.LatitudeB,
                            'LongitudeB':data.LongitudeB,
                            'Status': data.Status,
                            'etp': etp,
                            'Rota': 'N'
                        });
                    });

                    html_table_ots = html_table_ots +
                    '<tr class="collapse multi-collapse" id="collapseOTS_' + etp + '">' +
                    '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                    '<td>' + item.id + '</td>' +
                    '<td>' + item.siteA + '</td>' +
                    '<td>' + item.siteB + '</td>' +
                    '</tr>'
                });

                defineNetworkCoordinates(otss, 'etp', 2, 1, 'OTS').forEach(function(ots){
                    etpLines.push(ots);
                });

                if(!position){
                    position = true;
                    random = etpLines[Math.floor(Math.random() * etpLines.length)];
                    //map.setCenter(new google.maps.LatLng(random.latZoom, random.lngZoom));
                }
            }

            // OCH
            if(plotOCH.length>0){
                html_table_och = html_table_och +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_OCH" class="form-check-input" type="checkbox" onclick="checkPlotElements(this, map, \'' + etp +  '\', \'OCH\')"></td>' +
                '<td colspan="5" scope="row">' +
                '<a data-toggle="collapse" href="#collapseOCH_' + etp + '" aria-expanded="false" aria-controls="collapseOCH_' + etp + '">OCH +</a>' +
                '</td>' +
                '</tr>' /*+

                '<tr class="collapse multi-collapse" id="collapseOCH_' + etp + '">' +
                '<th scope="row"></th>' +
                '<th scope="row">OCH</th>' +
                '<th scope="row">Velocidade</th>' +
                '<th scope="row">Site A</th>' +
                '<th scope="row">Site B</th>' +
                '<th scope="row">Status OE</th>' +
                '</tr>'*/

                plotOCH.forEach(function(item){
                    var statusColor = (['Concluida'].includes(item.status)) ? ['#189c06', 'text-success'] : ['#cad100', 'text-warning'];

                    item.data.forEach(function(data){
                        ochs.push({
                            'color': statusColor[0],
                            'type': item.element,
                            'idWDMOMS': item.id,
                            'LatitudeA': data.LatitudeA,
                            'LongitudeA':data.LongitudeA,
                            'LatitudeB': data.LatitudeB,
                            'LongitudeB':data.LongitudeB,
                            'Status': data.Status,
                            'etp': etp,
                            'Rota': 'N'
                        });
                    });

                    html_table_och = html_table_och +
                    '<tr class="collapse multi-collapse" id="collapseOCH_' + etp + '">' +
                    '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                    '<td>' + item.id + '</td>' +
                    '<td>' + item.Velocidade + '</td>' +
                    '<td>' + item.siteA + '</td>' +
                    '<td>' + item.siteB + '</td>' +
                    '<td class="' + statusColor[1] + '">' + item.status + '</td>' +
                    '</tr>'
                });

                defineNetworkCoordinates(ochs, 'etp', 6, 1, 'OCH').forEach(function(och){
                    etpLines.push(och);
                });

                if(!position){
                    position = true;
                    random = etpLines[Math.floor(Math.random() * etpLines.length)];
                    //map.setCenter(new google.maps.LatLng(random.latZoom, random.lngZoom));
                }
            }

            // CIRCUITOS
            if(Object.keys(rotaCIRCUITOS).length>0){
                Object.keys(rotaCIRCUITOS).forEach(function(rota){
                    var rotaReplace = rota.replace(/\s+/g, '').replace('(', '').replace(')', '').replace('.', '').replace('+', '');
                    var idCircuitos = [];
                    labelRotaA = 'CIRCUITOS +'
                    var labelRotaA = (rota === '-') ? 'CIRCUITOS +' : 'CIRCUITOS ('+rota+') +';
                    html_table_circuito = html_table_circuito +
                    '<tr>' +
                    '<td scope="row"><input id="checkElements_'+ etp + '_CIRCUITO_'+ rotaReplace + '" class="form-check-input" type="checkbox" checked onclick="checkPlotElements(this, map, \'' + etp +  '\', \'EILD-LEGADO\', \'' + rota +  '\')"></td>' +
                    '<td colspan="6" scope="row">' +
                    '<a data-toggle="collapse" href="#collapseCIRCUITO_' + etp + '_'+ rotaReplace + '" aria-expanded="false" aria-controls="collapseCIRCUITO_' + etp + '_' + rotaReplace + '">' + labelRotaA + '</a>' +
                    '</td>' +
                    '</tr>' +

                    '<tr class="collapse multi-collapse" id="collapseCIRCUITO_' + etp + '_'+ rotaReplace + '">' +
                    '<th scope="row"></th>' +
                    '<th scope="row">EILD</th>' +
                    '<th scope="row">Velocidade</th>' +
                    '<th scope="row">Site A</th>' +
                    '<th scope="row">Site B</th>' +
                    '<th scope="row">Restauração</th>' +
                    '<th scope="row">Status OE</th>' +
                    '</tr>'

                    plotCIRCUITOS.filter(function(obj){return obj.Rota === rota}).forEach(function(item){
                        var statusColor = (item.element === 'LEGADO') ? ['#363636', 'text-dark'] : (['Concluida'].includes(item.status)) ? ['#189c06', 'text-success'] : ['#cad100', 'text-warning'];

                        item.data.forEach(function(data){
                            circuito = [{
                                'color': statusColor[0],
                                'type': item.element,
                                'idWDMOMS': item.id,
                                'LatitudeA': data.LatitudeA,
                                'LongitudeA':data.LongitudeA,
                                'LatitudeB': data.LatitudeB,
                                'LongitudeB':data.LongitudeB,
                                'Status': data.Status,
                                'etp': etp,
                                'Rota': rota,
                                'Details': '<ul class="list-group">'+item.Details+'</ul>'
                            }];
                            defineNetworkCoordinates(circuito, item.element, 2, 1, item.element).forEach(function(c){
                                etpLines.push(c);
                            });
                        });

                        if(!idCircuitos.includes(item.id)){
                            html_table_circuito = html_table_circuito +
                            '<tr class="collapse multi-collapse" id="collapseCIRCUITO_' + etp + '_'+ rotaReplace + '">' +
                            '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" checked onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                            '<td>' + item.id + '</td>' +
                            '<td>' + item.Velocidade + '</td>' +
                            '<td>' + item.siteA + '</td>' +
                            '<td>' + item.siteB + '</td>' +
                            '<td>' + item.L0 + '</td>' +
                            '<td class="' + statusColor[1] + '">' + item.status + '</td>' +
                            '</tr>'
                        }

                        idCircuitos.push(item.id);
                    });
                })

                addNetworkCoordinates(etpLines.filter(function(obj){return obj.etp == etp && obj.type == 'EILD'}), map);
                addNetworkCoordinates(etpLines.filter(function(obj){return obj.etp == etp && obj.type == 'LEGADO'}), map);

                if(!position){
                    position = true;
                    random = etpLines[Math.floor(Math.random() * etpLines.length)];
                    //map.setCenter(new google.maps.LatLng(random.latZoom, random.lngZoom));
                }

                plotSitesCIRCUITOS.forEach(function(item){
                    if(item.Camada !== ''){
                        var iconRouter = (['HL5', 'HL4', 'HL3', 'HL2', 'HL1'].includes(item.Camada.substring(0,3))) ? item.Camada.substring(0,3) : 'NoVendor';
                        routers.push({
                            'icon': iconRouter,
                            'type': item.element,
                            'idWDMOMS': item.id,
                            'Latitude': item.data.Latitude,
                            'Longitude':item.data.Longitude,
                            'etp': etp,
                            'Rota': item.Rota,
                            'Camada': item.Camada,
                            'Site': item.Site
                        });
                    }
                });
                defineMarkers(routers, 14, 'router', !etps_infos).forEach(function(router){
                    etpMarkers.push(router);
                });
                addMarkers(etpMarkers.filter(function(obj){return obj.etp == etp && obj.type == 'ROUTER'}), map);
            }

            // ODU
            if(plotODU.length>0){
                html_table_odu = html_table_odu +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_ODU" class="form-check-input" type="checkbox" onclick="checkPlotElements(this, map, \'' + etp +  '\', \'ODU\')"></td>' +
                '<td colspan="4" scope="row">' +
                '<a data-toggle="collapse" href="#collapseODU_' + etp + '" aria-expanded="false" aria-controls="collapseODU_' + etp + '">ODU +</a>' +
                '</td>' +
                '</tr>'

                plotODU.forEach(function(item){
                    var statusColor = (['Concluida'].includes(item.status)) ? ['#189c06', 'text-success'] : ['#cad100', 'text-warning'];

                    item.data.forEach(function(data){
                        odus.push({
                            'color': statusColor[0],
                            'type': item.element,
                            'idWDMOMS': item.id,
                            'LatitudeA': data.LatitudeA,
                            'LongitudeA':data.LongitudeA,
                            'LatitudeB': data.LatitudeB,
                            'LongitudeB':data.LongitudeB,
                            'Status': data.Status,
                            'etp': etp,
                            'Rota': 'N'
                        });
                    });

                    html_table_odu = html_table_odu +
                    '<tr class="collapse multi-collapse" id="collapseODU_' + etp + '">' +
                    '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                    '<td>' + item.id + '</td>' +
                    '<td>' + item.siteA + '</td>' +
                    '<td>' + item.siteB + '</td>' +
                    '<td class="' + statusColor[1] + '">' + item.status + '</td>' +
                    '</tr>'
                });

                defineNetworkCoordinates(odus, 'etp', 6, 1, 'ODU').forEach(function(odu){
                    etpLines.push(odu);
                });

                if(!position){
                    position = true;
                    random = etpLines[Math.floor(Math.random() * etpLines.length)];
                    //map.setCenter(new google.maps.LatLng(random.latZoom, random.lngZoom));
                }
            }

        } else {
            if(plotSites.length>0){
                html_table_site = html_table_site +
                '<tr>' +
                '<td scope="row"><input id="checkElements_'+ etp + '_SITES" class="form-check-input" type="checkbox" checked onclick="checkPlotElements(this, map, \'' + etp +  '\', \'SITE\')"></td>' +
                '<td colspan="2" scope="row">' +
                '<a data-toggle="collapse" href="#collapseSITES_' + etp + '" aria-expanded="false" aria-controls="collapseSITES_' + etp + '">Sites +</a>' +
                '</td>' +
                '</tr>'

                plotSites.forEach(function(item){
                    var statusColor;
                    var statusDesc;
                    var iconDimension;

                    if(item.element === 'ENVOLVIDOS'){
                        statusColor = ['Outros', 'text-black-50'];
                        statusDesc = 'Envolvido';
                    } else {
                        statusColor = (['Concluida'].includes(item.status)) ? ['Huawei', 'text-success'] : ['Nokia', 'text-warning'];
                        statusDesc = item.status;
                    }

                    var siteTemp = {
                        'icon': statusColor[0],
                        'type': item.element,
                        'idWDMOMS': item.id,
                        'Latitude': item.data.Latitude,
                        'Longitude':item.data.Longitude,
                        'etp': etp
                    }

                    if(item.element === 'ENVOLVIDOS'){
                        sitesEnvolvidos.push(siteTemp);
                    } else {
                        sites.push(siteTemp);
                    }

                    html_table_site = html_table_site +
                    '<tr class="collapse multi-collapse" id="collapseSITES_' + etp + '">' +
                    '<td><input id="check_'+ etp + '_' + item.id + '" class="form-check-input" type="checkbox" checked onclick="checkPlot(this, map, \'' + item.element +  '\', \'' + item.id + '\')"></td>' +
                    '<td>' + item.id + '</td>' +
                    '<td class="' + statusColor[1] + '">' + statusDesc + '</td>' +
                    '</tr>'
                });

                defineMarkers(sites, 12, 'etp', etps_infos).forEach(function(site){
                    etpMarkers.push(site);
                });
                defineMarkers(sitesEnvolvidos, 8, 'etp', etps_infos).forEach(function(site){
                    etpMarkers.push(site);
                });
                addMarkers(etpMarkers.filter(function(obj){return obj.etp == etp}), map);

                if(!position){
                    position = true;
                    random = etpMarkers[Math.floor(Math.random() * etpMarkers.length)];
                    //map.setCenter(new google.maps.LatLng(random.lat, random.lng));
                }
            } else {
                html_table_oms = html_table_oms +
                '<tr>' +
                '<th colspan="3" scope="col">Sem OEs de Ativ.</th>' +
                '</tr>'
            }
        }

        // PED
        if(etps_result[item]['resumes']['PED'].length>0){
            //var fibras_info = (etps_result[item]['resumes']['FIBRAS_INFO'].length>0) ? true : false;
            html_table_ped = html_table_ped +
            '<tr>' +
            '<td scope="row"><input style="visibility:hidden" class="form-check-input" type="checkbox" onclick="checkPlotElements(this, map, \'' + etp +  '\', \'PED\')"></td>' +
            '<td colspan="2" scope="row">' +
            '<a data-toggle="collapse" href="#collapsePEDS_' + etp + '" aria-expanded="false" aria-controls="collapsePEDS_' + etp + '">PEDS +</a>' +
            '</td>'
            etps_result[item]['resumes']['PED'].forEach(function(item){
                var statusColor = (['Concluída'].includes(item.resultado)) ? 'text-success' : 'text-warning';
                html_table_ped = html_table_ped +
                '</tr>' +
                '<tr class="collapse multi-collapse" id="collapsePEDS_' + etp + '">' +
                '<td>&nbsp;</td>'

                if(item.id == 'Eng. de Rede Externa' && fibras_info && item.resultado !== 'Cancelada'){
                    html_table_ped = html_table_ped +
                    '<td>' +
                    '<a style="cursor:pointer; text-decoration:underline; color:blue;" onclick="createXlsxFibra(\'' + etp +  '\')">' + item.id + '</a>' +
                    '</td>'
                } else {
                    html_table_ped = html_table_ped +
                    '<td>' + item.id + '</td>'
                }

                html_table_ped = html_table_ped +
                '<td class="' + statusColor + '">' + item.status_orig + '</td>'
            })
        }

        html_table_resume = html_table_resume + html_table_oms + html_table_ots + html_table_site + html_table_och + html_table_circuito + html_table_odu + html_table_ped +
        '<tr>' +
        '<td colspan="3" scope="row">' +
        '<a class="text-muted" style="cursor:pointer" onclick="showModalDetails(\'block\', \'' + etp +  '\')">' +
        'DETALHES <i class="material-icons">content_paste</i></a>' +
        '</td>' +
        '</tr>'

        /*
        //ÍCONES DOS CIRCUITOS-----------
        if(Object.keys(rotaCIRCUITOS).length>0){
            html_table_resume = html_table_resume +
            '<tr>' +
            '<td colspan="3" scope="row">' +
            '<table><tbody>' +
            '<tr>' +
            '<td width="80" align="left">Ícones Circuitos</td>' +
            '<td width="20" align="right"><a href="#"><i class="material-icons" onclick="HLiconsEtp(5, \'' + etp +  '\')">add</i></a></td>' +
            '<td width="20" align="left"><a href="#"><i class="material-icons" onclick="HLiconsEtp(-5, \'' + etp +  '\')">remove</i></a></td>' +
            '</tr>' +
            '</tbody></table>' +
            '</td>' +
            '</tr>'
        }
        //-------------------------------
        */

        html_table_resume = html_table_resume +
        '</tbody>' +
        '</table>'

        html_table_resume_total = html_table_resume_total + html_table_resume
        html_modal_etp = html_modal_etp + fillDetailsEtp(etps_result[item]['details'], etp, etps_result[item]['resumes']);
    })

    if(len_result>1){
        html_modal_etp = html_modal_etp + fillDetailsEtpStatusCpom(etps_result);
    }

    resumeEtp.innerHTML = html_table_resume_total;
    modalDetailsEtps.innerHTML = html_modal_etp;

    if(typeof(random) == 'undefined'){
        random = {
            'lat': '-15.7797203',
            'lng': '-47.9297218'
        }
    }
    if(Object.keys(random).includes('latZoom')){
        random.lat = random.latZoom;
        random.lng = random.lngZoom;
    }
    return random;
}

function fillDetailsEtpStatusCpom(etps_result){
    tr_status = '';
    tr_cpom = '';

    Object.keys(etps_result).forEach(function(item){
        tr_status = tr_status +
        '<tr>' +
        '<td scope="row">' + item + '</td>' +
        '<td scope="row">' + etps_result[item]['resumes']['ETP']['status'] + '</td>' +
        '</tr>'

        tr_cpom = tr_cpom +
        '<tr>' +
        '<td scope="row">' + item + '</td>' +
        '<td scope="row">R$ ' + parseFloat(Math.round(etps_result[item]['resumes']['T2'][0]['ValorTotal'] * 100) / 100).toLocaleString('pt-BR') + '</td>' +
        '<td scope="row">R$ ' + parseFloat(Math.round(etps_result[item]['resumes']['T2'][0]['ValorPC'] * 100) / 100).toLocaleString('pt-BR') + '</td>' +
        '<td scope="row">R$ ' + parseFloat(Math.round(etps_result[item]['resumes']['T2'][0]['ValorFaturado'] * 100) / 100).toLocaleString('pt-BR') + '</td>' +
        '</tr>'


    })

    modal = '' +
    '<div id="ModalDetails_status_cpom" class="modal" tabindex="-1" role="dialog">' +
    '<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-xl" role="document">' +
    '<div class="modal-content">' +
    '<div class="modal-header">' +
    '<h5 class="modal-title">Detalhes</h5>' +
    '<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="showModalDetails(\'none\', \'status_cpom\')">' +
    '<span aria-hidden="true">&times;</span>' +
    '</button>' +
    '</div>' +
    '<div class="modal-body">' +
    //Tabela Status
    '<table class="table">' +
    '<thead>' +
    '<tr>' +
    '<th scope="col">ETP</th>' +
    '<th scope="col">Status</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>' +
    tr_status +
    '</tbody>' +
    '</table>' +
    '<hr/>' +
    //Tabela Cpom
    '<table class="table">' +
    '<thead>' +
    '<tr>' +
    '<th scope="col">ETP</th>' +
    '<th scope="col">T2</th>' +
    '<th scope="col">PC</th>' +
    '<th scope="col">NF</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>' +
    tr_cpom +
    '</tbody>' +
    '</table>' +

    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'

    return modal;
}

function fillDetailsEtp(details, etp, resumes, fiber_owner){

    html_modal_atributes = '';
    html_modal_oe = '';
    html_modal_oe_predecessoras = '';
    html_modal_ots = '';
    html_modal_ped = '';
    html_modal_t2 = '';
    html_modal_cotacao = '';
    html_modal_equipamentos = '';
    html_modal_sites = '';
    html_modal_data_etps_infos = '';
    validation = details['EDIT_VALIDATION_WRITE'];

    if(details['OES'].length>0){
        html_modal_oe = html_modal_oe +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-oe_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'oes\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Num OE</th>' +
        '<th scope="col">Tipo OE</th>' +
        '<th scope="col">Elemento</th>' +
        '<th scope="col">Status OE</th>' +
        '<th scope="col">Descrição</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        idOEs = [];
        details['OES'].forEach(function(item){
            if(item.numOE>0 && !idOEs.includes(item.numOE)){
                html_modal_oe = html_modal_oe +
                '<tr>' +
                '<td scope="row">' + item.numOE + '</td>' +
                '<td scope="row">' + item.TipoOE + '</td>' +
                '<td scope="row">' + item.id + '</td>' +
                '<td scope="row">' + item.Status + '</td>' +
                '<td scope="row" title="' + item.Descricao + '">' + item.Descricao.substring(0, 40) + '...</td>' +
                '</tr>'
            }
            idOEs.push(item.numOE);
        });
        html_modal_oe = html_modal_oe +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_oe = html_modal_oe +
        '<span>Nenhuma OE emitida...</span>'
    }

    if(details['adicionais']['oes_predecessoras'].length>0){
        html_modal_oe_predecessoras = html_modal_oe_predecessoras +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-oe_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'oes_predecessoras\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Num OE</th>' +
        '<th scope="col">Tipo OE</th>' +
        '<th scope="col">Elemento</th>' +
        '<th scope="col">Status OE</th>' +
        '<th scope="col">Descrição</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        idOEsPredecessoras = [];
        details['adicionais']['oes_predecessoras'].forEach(function(item){
            if(item.numOE>0 && !idOEsPredecessoras.includes(item.numOE)){
                html_modal_oe_predecessoras = html_modal_oe_predecessoras +
                '<tr>' +
                '<td scope="row">' + item.numOE + '</td>' +
                '<td scope="row">' + item.TipoOE + '</td>' +
                '<td scope="row">' + item.id + '</td>' +
                '<td scope="row">' + item.Status + '</td>' +
                '<td scope="row" title="' + item.Descricao + '">' + item.Descricao.substring(0, 40) + '...</td>' +
                '</tr>'
            }
            idOEsPredecessoras.push(item.numOE);
        });
        html_modal_oe_predecessoras = html_modal_oe_predecessoras +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_oe_predecessoras = html_modal_oe_predecessoras +
        '<span>Nenhuma OE predecessora emitida...</span>'
    }

    if(resumes['OTS'].length>0){
        html_modal_ots = html_modal_ots +
        '<table class="table table-sm table-striped" id="table-detalhes-ots-' + etp + '">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="6" scope="col">' +
        '<button id="modal-detalhes-ots_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'ots\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Id OTS</th>' +
        '<th scope="col">Num OTS</th>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">Proprietário da Fibra</th>' +
        //'<th scope="col">Nome da Rota</th>' +
        '<th scope="col">'
        if(validation){
            html_modal_ots = html_modal_ots + '<i id="inputOtsEdit-' + etp +'" class="material-icons" style="cursor:pointer" onclick="OtsUpdateCreate(\'' + etp +  '\')">edit_note</i>' +
            '<button style="display: none" class="btn btn-outline-secondary" type="button" id="btGravaOts-' + etp +'" onclick="saveOtsUpdate(\'' + etp +  '\')">Gravar</button>'
        }
        html_modal_ots = html_modal_ots +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        var c_owner = 0;
        resumes['OTS'].forEach(function(item){
            html_modal_ots = html_modal_ots +
            '<tr>' +
            '<td scope="row">' + item.idWDMOTS + '</td>' +
            '<td scope="row">' + item.ChaveOTS + '</td>' +
            '<td scope="row">' + item.Sigla + '</td>' +
            '<td scope="row"><span id="spanOts-' + item.idWDMOTS + '-' + etp + '">' + item.PropriedadeFibra + '</span>' +
            '<select style="display: none" class="form-control" id="slcOts-' + item.idWDMOTS + '-' + etp + '">' +
            '<option selected></option>'
            supportsedit['fiber_owner'].forEach(function(owner){
                var prop = (item.PropriedadeFibra) ? item.PropriedadeFibra.toLowerCase() : '';
                var slctd = (prop == owner.toLowerCase()) ? 'selected' : '';
                html_modal_ots = html_modal_ots + '<option '+slctd+'>' + owner + '</option>';
            })
            html_modal_ots = html_modal_ots + '</select>' +
            '<input type="hidden" id="hidOts-' + item.idWDMOTS + '-' + etp + '" value="' + item.idWDMOTS +'" />' +
            '</td>' +
            //'<td scope="row">' + item.NomeRotaNovo + '</td>' +
            '<td scope="row">'
            if(c_owner==0){
                html_modal_ots = html_modal_ots + '<input style="display: none" type="checkbox" class="form-check-input" id="checkOts-' + item.idWDMOTS + '-' + etp + '" onclick="replication(\'' + etp +  '\', this)">';
            } else {
                html_modal_ots = html_modal_ots + '&nbsp;';
            }
            html_modal_ots = html_modal_ots +
            '</td>' +
            '</tr>'
            c_owner++;
        });
        html_modal_ots = html_modal_ots +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_ots = html_modal_ots +
        '<span>Nenhuma OTS emitida...</span>'
    }

    if(Object.keys(resumes['CIRCUITOS']).length>0){
        html_modal_equipamentos = html_modal_equipamentos +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-circuitos_xls' + etp + '" class="btn btn-sm  text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'equipamentos\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Rota</th>' +
        '<th scope="col">Site A</th>' +
        '<th scope="col">Roteador A</th>' +
        '<th scope="col">Interface A</th>' +
        '<th scope="col">Camada A</th>' +
        '<th scope="col">Sigla A</th>' +
        '<th scope="col">She/Slo/Por A</th>' +
        '<th scope="col">DGOTX A</th>' +
        '<th scope="col">DGORX A</th>' +
        '<th scope="col">Site B</th>' +
        '<th scope="col">Roteador B</th>' +
        '<th scope="col">Interface B</th>' +
        '<th scope="col">Camada B</th>' +
        '<th scope="col">Sigla B</th>' +
        '<th scope="col">She/Slo/Por B</th>' +
        '<th scope="col">DGOTX B</th>' +
        '<th scope="col">DGORX B</th>' +
        '<th scope="col">OE</th>' +
        '<th scope="col">EILD</th>' +
        '<th scope="col">Velocidade</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        Object.keys(resumes['CIRCUITOS']).forEach(function(r){
            resumes['CIRCUITOS'][r].forEach(function(item){
                var num_oe = (item.numOE>0) ? item.numOE : 'Legado';
                var siglaA = (item.siglaA=='') ? '-' : item.siglaA;
                var shelfA = (item.shelfA=='') ? '-' : item.shelfA;
                var slotA = (item.slotA=='') ? '-' : item.slotA;
                var dgoTxA = (item.dgoTxA=='') ? '-' : item.dgoTxA;
                var dgoRxA = (item.dgoRxA=='') ? '-' : item.dgoRxA;
                var siglaB = (item.siglaB=='') ? '-' : item.siglaB;
                var portaA = (item.portaA=='') ? '-' : item.portaA;
                var shelfB = (item.shelfB=='') ? '-' : item.shelfB;
                var slotB = (item.slotB=='') ? '-' : item.slotB;
                var portaB = (item.portaB=='') ? '-' : item.portaB;
                var dgoTxB = (item.dgoTxB=='') ? '-' : item.dgoTxB;
                var dgoRxB = (item.dgoRxB=='') ? '-' : item.dgoRxB;
                html_modal_equipamentos = html_modal_equipamentos +
                '<tr>' +
                '<td scope="row">' + item.Rota + '</td>' +
                '<td scope="row">' + item.SiteI + '</td>' +
                '<td scope="row">' + item.EquipamentoI + '</td>' +
                '<td scope="row">' + item.InterfaceI + '</td>' +
                '<td scope="row">' + item.CamadaI + '</td>' +
                '<td scope="row">' + siglaA + '</td>' +
                '<td scope="row">' + shelfA + '/' + slotA + '/' + portaA + '</td>' +
                '<td scope="row">' + dgoTxA + '</td>' +
                '<td scope="row">' + dgoRxA + '</td>' +
                '<td scope="row">' + item.SiteF + '</td>' +
                '<td scope="row">' + item.EquipamentoF + '</td>' +
                '<td scope="row">' + item.InterfaceF + '</td>' +
                '<td scope="row">' + item.CamadaF + '</td>' +
                '<td scope="row">' + siglaB + '</td>' +
                '<td scope="row">' + shelfB + '/' + slotB + '/' + portaB + '</td>' +
                '<td scope="row">' + dgoTxB + '</td>' +
                '<td scope="row">' + dgoRxB + '</td>' +
                '<td scope="row">' + num_oe + '</td>' +
                '<td scope="row">' + item.id + '</td>' +
                '<td scope="row">' + item.Velocidade + '</td>'
            })
        });
        html_modal_equipamentos = html_modal_equipamentos +
        '</tbody>' +
        '</table>'
    }

    if(details['PEDS'].length>0){
        html_modal_ped = html_modal_ped +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-peds_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'peds\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Num PED</th>' +
        '<th scope="col">Tipo PED</th>' +
        '<th scope="col">Status PED</th>' +
        '<th scope="col">Resp. Técnico</th>' +
        '<th scope="col">Aplicação</th>' +
        '<th scope="col">Referencia</th>' +
        '<th scope="col">Objetivo</th>' +
        '<th scope="col">Associada</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        details['PEDS'].forEach(function(item){
            var aplicacao = (item.APLICACAO) ? item.APLICACAO : '';
            var referencia = (item.REFERENCIA) ? item.REFERENCIA : '';
            var objetivoped = (item.OBJETIVO) ? item.OBJETIVO : '';
            html_modal_ped = html_modal_ped +
            '<tr>' +
            '<td scope="row">' + item.PED + '</td>' +
            '<td scope="row">' + item.LabelRequisitada + '</td>' +
            '<td scope="row">' + item.STATUS_SSI + '</td>' +
            '<td scope="row">' + item.RESPONSAVEL_TECNICO + '</td>' +
            '<td scope="row" title="' + aplicacao + '">' + aplicacao.substring(0, 40) + '...</td>' +
            '<td scope="row" title="' + referencia + '">' + referencia.substring(0, 40) + '...</td>' +
            '<td scope="row" title="' + objetivoped + '">' + objetivoped.substring(0, 40) + '...</td>'
            if(item.PED_ASSOCIADA_DETALHES){
                var infos_associada = '' +
                'Ped: '+ item.PED_ASSOCIADA_DETALHES.PED + ' \n' +
                'Tipo: '+ item.PED_ASSOCIADA_DETALHES.LabelRequisitada + ' \n' +
                'Status: '+ item.PED_ASSOCIADA_DETALHES.STATUS_SSI + ' \n' +
                'Resp. Técnico: '+ item.PED_ASSOCIADA_DETALHES.RESPONSAVEL_TECNICO + ' \n' +
                'Referência: '+ item.PED_ASSOCIADA_DETALHES.REFERENCIA + ' \n' +
                'Aplicação: '+ item.PED_ASSOCIADA_DETALHES.APLICACAO + ' \n' +
                'Objetivo: '+ item.PED_ASSOCIADA_DETALHES.OBJETIVO

                html_modal_ped = html_modal_ped +
                '<td scope="row">' +
                '<button type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infos_associada + '"><i class="material-icons">manage_search</i></button>' +
                '</td>' +
                '</tr>'
            } else {
                html_modal_ped = html_modal_ped + '<td scope="row"></td></tr>'
            }
        });
        html_modal_ped = html_modal_ped +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_ped = html_modal_ped +
        '<span>Nenhuma PED emitida...</span>'
    }

    if(details['T2S'].length>0){
        html_modal_t2 = html_modal_t2 +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-t2_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'pedidos\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">PCs</th>' +
        '<th scope="col">T2</th>' +
        '<th scope="col">Status T2</th>' +
        '<th scope="col">Contrato</th>' +
        '<th scope="col">Fornecedor</th>' +
        '<th scope="col">Escopo</th>' +
        '<th scope="col">Valor Bruto</th>' +
        '<th scope="col">Valor Faturado</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        details['T2S'].forEach(function(item){
            var T2ValorBruto = item.Pedidos.reduce((accumulator, object) => {return accumulator + object.VlrBrutoPedido;}, 0);
            var T2ValorFaturado = item.Pedidos.reduce((accumulator, object) => {return accumulator + object.VlrFaturado;}, 0);

            html_modal_t2 = html_modal_t2 +
            '<tr>' +
            '<td scope="row">' +
            '<a data-toggle="collapse" href="#collapse' + String(item.T2) + '" aria-expanded="false" aria-controls="collapse' + String(item.T2) + '">+</a>' +
            '</td>' +
            '<td scope="row">' + item.T2 + '</td>' +
            '<td scope="row">' + item.Status + '</td>' +
            '<td scope="row" title="' + item.Fornecedor + '">' + item.Contrato + '</td>' +
            '<td scope="row">' + item.FornecedorLabel + '</td>' +
            '<td scope="row" title="' + item.Escopo + '">' + item.Escopo.substring(0, 60) + '...</td>' +
            '<td scope="row">' + 'R$ ' + parseFloat(Math.round(T2ValorBruto * 100) / 100).toLocaleString('pt-BR') + '</td>' +
            '<td scope="row">' + 'R$ ' + parseFloat(Math.round(T2ValorFaturado * 100) / 100).toLocaleString('pt-BR') + '</td>' +
            '</tr>' +
            '<tr class="collapse multi-collapse" id="collapse' + item.T2 + '">' +
            '<td colspan="6">'
            if(item.Pedidos.length>0){
                html_modal_t2 = html_modal_t2 +
                '<table class="table table-sm table-striped">' +
                '<thead>' +
                '<tr>' +
                '<th scope="col">T2</th>' +
                '<th scope="col">Pedido</th>' +
                '<th scope="col">Data PC</th>' +
                '<th scope="col">Pep</th>' +
                //'<th scope="col">Site</th>' +
                '<th scope="col">Valor Bruto</th>' +
                '<th scope="col">Valor Faturado</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>'
                item.Pedidos.forEach(function(pc){
                    html_modal_t2 = html_modal_t2 +
                    '<tr>' +
                    '<td scope="row">' + item.T2 + '</td>' +
                    '<td scope="row">' + pc.Pedido + '</td>' +
                    '<td scope="row">' + pc.DataPc + '</td>' +
                    '<td scope="row">' + pc.Pep_Id + '</td>' +
                    //'<td scope="row">' + pc.SitePC + '</td>' +
                    '<td scope="row">' + 'R$ ' + parseFloat(Math.round(pc.VlrBrutoPedido * 100) / 100).toLocaleString('pt-BR') + '</td>' +
                    '<td scope="row">' + 'R$ ' + parseFloat(Math.round(pc.VlrFaturado * 100) / 100).toLocaleString('pt-BR') + '</td>' +
                    '</tr>'
                });
                html_modal_t2 = html_modal_t2 +
                '</tbody>' +
                '</table>'
            } else {
                html_modal_t2 = html_modal_t2 +
                '<span>Nenhum pedido para a T2 ' + item.T2 + '</span>'
            }
            html_modal_t2 = html_modal_t2 +
            '</td>' +
            '</tr>'
        });
        html_modal_t2 = html_modal_t2 +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_t2 = html_modal_t2 +
        '<span>Nenhuma T2 emitida...</span>'
    }

    if(details['COTACAO'].length>0){
        var tiposTemplate = ['Hardware', 'Software', 'Serviço', 'Material', 'Outros']
        var distinctTiposCotacao = [...new Set(details["COTACAO"].map(t => t.TipoLabel))];
        distinctTiposCotacao = new Set(distinctTiposCotacao);
        distinctTiposCotacao = tiposTemplate.filter(o => distinctTiposCotacao.has(o));

        html_modal_cotacao = html_modal_cotacao +
        '<nav>' +
        '<div class="nav nav-tabs" id="nav-tab-' + etp + '" role="tablist">'
        var countNav = 0;
        var active = '';
        var ariaSelected = false;
        distinctTiposCotacao.forEach(function(item){
            countNav++;
            active = (countNav==1) ? 'active' : '';
            ariaSelected = (countNav==1) ? true : false;
            html_modal_cotacao = html_modal_cotacao +
            '<a class="nav-item nav-link ' + active + '" id="nav-' + etp + '-' + item + '-tab" data-toggle="tab" href="#nav-' + etp + '-' + item + '" role="tab" aria-controls="nav-' + etp + '-' + item + '" aria-selected="true">' + item + '</a>'
        })
        html_modal_cotacao = html_modal_cotacao +
        '</div>' +
        '</nav>' +
        '<div class="tab-content" id="nav-tabContent-' + etp + '">'
        var countNav = 0;
        var active = '';
        distinctTiposCotacao.forEach(function(item){
            countNav++;
            active = (countNav==1) ? 'active show' : '';
            html_modal_cotacao = html_modal_cotacao +
            '<div class="tab-pane fade ' + active + '" id="nav-' + etp + '-' + item + '" role="tabpanel" aria-labelledby="nav-' + etp + '-' + item + '-tab">' +
            '<table class="table table-sm table-striped">' +
            '<thead>' +
            '<tr>' +
            '<th colspan="5" scope="col">' +
            '<button id="modal-detalhes-cotacao_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'cotacao\')"><i class="material-icons">file_download</i> Baixar cotação completa em xlsx...</button>' +
            '</th>' +
            '</tr>' +
            '</thead>' +
            '<thead>' +
            '<tr>' +
            '<th scope="col">Site</th>' +
            '<th scope="col">T2</th>' +
            '<th scope="col">T2 - Código</th>' +
            '<th scope="col">T2 - Descr. Código</th>' +
            '<th scope="col">Fabricante</th>' +
            '<th scope="col">Qtde</th>' +
            '<th scope="col">Unid</th>' +
            '<th scope="col">Vlr Total</th>' +
            //'<th scope="col">Tipo</th>' +
            //'<th scope="col">Categoria</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>' +
            bodyCotacao(etp, item) +
            '</tbody>' +
            '</table>' +
            '</div>'
        })
        html_modal_cotacao = html_modal_cotacao +
        '</div>'
    } else {
        html_modal_cotacao = html_modal_cotacao +
        '<span>Sem cotação para  exibir...</span>'
    }

    if(details['SITES'].length>0){
        html_modal_sites = html_modal_sites +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-sites_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'sites\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">UF</th>' +
        '<th scope="col">Sigla Fixa</th>' +
        '<th scope="col">Nome</th>' +
        '<th scope="col">Endereço</th>' +
        '<th scope="col">Bairro</th>' +
        '<th scope="col">Município</th>' +
        '<th scope="col">CEP</th>' +
        '<th scope="col">Latitude</th>' +
        '<th scope="col">Longitude</th>' +
        '<th scope="col">Id Financeiro</th>' +
        '<th scope="col">Utilização</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        var detailsSitesIn = [];
        details['SITES'].forEach(function(item){
            if(!detailsSitesIn.includes(item.sigla+item.uf)){
                detailsSitesIn.push(item.sigla+item.uf);
                html_modal_sites = html_modal_sites +
                '<tr>' +
                '<td scope="row">' + item.sigla + '</td>' +
                '<td scope="row">' + item.uf + '</td>'
                if(item.latitude !== undefined){
                html_modal_sites = html_modal_sites +
                    '<td scope="row">' + item.sigla_fixa + '</td>' +
                    '<td scope="row">' + item.nome + '</td>' +
                    '<td scope="row">' + item.endereco + '</td>' +
                    '<td scope="row">' + item.bairro + '</td>' +
                    '<td scope="row">' + item.municipio + '</td>' +
                    '<td scope="row">' + item.cep + '</td>' +
                    '<td scope="row">' + item.latitude + '</td>' +
                    '<td scope="row">' + item.longitude + '</td>' +
                    '<td scope="row">' + item.id_financeiro + '</td>' +
                    '<td scope="row">' + item.utilizacao + '</td>' +
                    '</tr>'
                } else {
                    '<td scope="row" colspan="9">&nbsp;</td>' +
                    '</tr>'
                }
            }
        });
        html_modal_sites = html_modal_sites +
        '</tbody>' +
        '</table>'
    } else {
        html_modal_sites = html_modal_sites +
        '<span>Nenhum Site Envolvido...</span>'
    }

    if(details.hasOwnProperty('data_etps_infos')){
        html_modal_data_etps_infos = html_modal_data_etps_infos +
        '<table class="table table-sm table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th colspan="5" scope="col">' +
        '<button id="modal-detalhes-sites_xls' + etp + '" class="btn btn-sm text-success" type="button" onclick="createXlsx(\'' + etp +  '\', \'infos_etp\')"><i class="material-icons">file_download</i> Baixar em xlsx...</button>' +
        '</th>' +
        '</tr>' +
        '</thead>' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">ETP</th>' +
        '<th scope="col">Status</th>' +
        '<th scope="col">Gestor</th>' +
        '<th scope="col">Título</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        details['data_etps_infos'].forEach(function(item){
            html_modal_data_etps_infos = html_modal_data_etps_infos +
            '<tr>' +
            '<td scope="row">' + item.etp + '</td>' +
            '<td scope="row">' + item.status + '</td>' +
            '<td scope="row">' + item.gestor + '</td>' +
            '<td scope="row">' + item.titulo + '</td>' +
            '</tr>'
        });
        html_modal_data_etps_infos = html_modal_data_etps_infos +
        '</tbody>' +
        '</table>'
    }

    var textoDetalhes = (details.hasOwnProperty('data_etps_infos')) ? document.getElementById('filter-group').options[document.getElementById('filter-group').selectedIndex].text : etp;
    modalEtp = '' +
    '<div id="ModalDetails_' + etp + '" class="modal" tabindex="-1" role="dialog">' +
    '<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered" role="document" style="max-width: 95%;">' +
    '<div class="modal-content">' +
    '<div class="modal-header">' +
    '<h5 class="modal-title">Detalhes ' + textoDetalhes + '</h5>'
    if(details['ATRIBUTOS']){
        modalEtp = modalEtp +
        '&nbsp; &nbsp;' +
        '<i id="inputEtpCreatePdf-' + etp +'" class="material-icons text-danger" style="cursor:pointer" onclick="createEtpPDF(\'' + etp +  '\')">picture_as_pdf</i>'
        if(details['EDIT_VALIDATION']){
            modalEtp = modalEtp +
            '&nbsp; &nbsp;' +
            '<i id="inputEtpRefresh-' + etp +'" class="material-icons" style="cursor:pointer" onclick="refreshEtp(\'' + etp +  '\')">refresh</i>'
        }
    }
    modalEtp = modalEtp +
    '<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="showModalDetails(\'none\', \'' + etp +  '\')">' +
    '<span aria-hidden="true">&times;</span>' +
    '</button>' +
    '</div>' +
    '<div class="modal-body">' +
    '<div class="accordion" id="accordionExample_' + etp + '">' +
    '<div class="card">'
    if(details['ATRIBUTOS']){
        html_modal_atributes = createModalAtributes(details['ATRIBUTOS'], etp, details['EDIT_VALIDATION']);
        modalEtp = modalEtp +
        '<div class="card-header" id="headingAtributos_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseAtributos_' + etp + '" aria-expanded="true" aria-controls="collapseAtributos_' + etp + '">' +
        'Atributos da ETP' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseAtributos_' + etp + '" class="collapse" aria-labelledby="headingAtributos" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-atributos_' + etp + '" class="card-body">' +
        //<!-- DETALHES ATRIBUTOS -->
        html_modal_atributes +
        '</div>' +
        '</div>'

        html_modal_checklist = createModalChecklist(details['ATRIBUTOS']["checklist"], etp, newValidation);
        modalEtp = modalEtp +
        '<div class="card-header" id="headingCheckList_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseCheckList_' + etp + '" aria-expanded="true" aria-controls="collapseCheckList_' + etp + '">' +
        'Checklist' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseCheckList_' + etp + '" class="collapse" aria-labelledby="headingCheckList" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-checklist_' + etp + '" class="card-body">' +
        //<!-- DETALHES CHECKLIST -->
        html_modal_checklist +
        '</div>' +
        '</div>'
    } else {
        var textoAtributo = (details.hasOwnProperty('data_etps_infos')) ? document.getElementById('filter-group').options[document.getElementById('filter-group').selectedIndex].text : 'ETP Off-Line';
        modalEtp = modalEtp +
        '<div class="card-header" id="headingAtributos_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-sm" type="button">' +
        textoAtributo +
        '</button>' +
        '</h5>' +
        '</div>'
    }

    if(details['OES'].length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingOE_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseOE_' + etp + '" aria-expanded="true" aria-controls="collapseOE_' + etp + '">' +
        'OE(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseOE_' + etp + '" class="collapse" aria-labelledby="headingOE" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-oe_' + etp + '" class="card-body">' +
        //<!-- DETALHES OE -->
        html_modal_oe +
        '</div>' +
        '</div>'
    }

    if(details['adicionais']['oes_predecessoras'].length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingOEPredecessora_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseOEPredecessora_' + etp + '" aria-expanded="true" aria-controls="collapseOEPredecessora_' + etp + '">' +
        'OE(s) Predecessora(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseOEPredecessora_' + etp + '" class="collapse" aria-labelledby="headingOEPredecessora" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-oe-predecessora_' + etp + '" class="card-body">' +
        //<!-- DETALHES OE -->
        html_modal_oe_predecessoras +
        '</div>' +
        '</div>'
    }

    if(resumes['OTS'].length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingOTS_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseOTS_details_' + etp + '" aria-expanded="true" aria-controls="collapseOTS_details_' + etp + '">' +
        'OTS(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseOTS_details_' + etp + '" class="collapse" aria-labelledby="headingOTS" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-ots_' + etp + '" class="card-body">' +
        //<!-- DETALHES OTS -->
        html_modal_ots +
        '</div>' +
        '</div>'
    }

     //<!-- DETALHES EQUIPAMENTOS -->
    if(Object.keys(resumes['CIRCUITOS']).length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingEquipamentos_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseEquipamentos_' + etp + '" aria-expanded="true" aria-controls="collapseEquipamentos_' + etp + '">' +
        'Equipamento(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseEquipamentos_' + etp + '" class="collapse" aria-labelledby="headingEquipamentos" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-equipamentos_' + etp + '" class="card-body">' +
        html_modal_equipamentos +
        '</div>' +
        '</div>'
    }

    if(details['PEDS'].length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingPED_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm collapsed" type="button" data-toggle="collapse" data-target="#collapsePED_' + etp + '" aria-expanded="false" aria-controls="collapsePED_' + etp + '">' +
        'PED(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapsePED_' + etp + '" class="collapse" aria-labelledby="headingPED" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-ped_' + etp + '" class="card-body">' +
        //<!-- DETALHES PED -->
        html_modal_ped +
        '</div>' +
        '</div>'
    }

    if(details['T2S'].length>0){
         modalEtp = modalEtp +
        '<div class="card-header" id="headingPC_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm collapsed" type="button" data-toggle="collapse" data-target="#collapsePC_' + etp + '" aria-expanded="false" aria-controls="collapsePC_' + etp + '">' +
        'Pedido(s)' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapsePC_' + etp + '" class="collapse" aria-labelledby="headingPC_' + etp + '" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-t2_' + etp + '" class="card-body">' +
        //<!-- DETALHES T2 -->
        html_modal_t2 +
        '</div>' +
        '</div>'
    }

    if(details['COTACAO'].length>0){
         modalEtp = modalEtp +
        '<div class="card-header" id="headingCotacao_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm collapsed" type="button" data-toggle="collapse" data-target="#collapseCotacao_' + etp + '" aria-expanded="false" aria-controls="collapseCotacao_' + etp + '">' +
        'Cotação' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseCotacao_' + etp + '" class="collapse" aria-labelledby="headingCotacao_' + etp + '" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-cotacao_' + etp + '" class="card-body">' +
        //<!-- DETALHES COTAÇÃO -->
        html_modal_cotacao +
        '</div>' +
        '</div>'
    }

    if(details['SITES'].length>0){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingSITESENVOLVIDOS_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseSITESENVOLVIDOS_' + etp + '" aria-expanded="true" aria-controls="collapseSITESENVOLVIDOS_' + etp + '">' +
        'Sites Envolvidos' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseSITESENVOLVIDOS_' + etp + '" class="collapse" aria-labelledby="headingSITESENVOLVIDOS" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-detalhes-sites_envolvidos' + etp + '" class="card-body">' +
        //<!-- DETALHES SITES ENVOLVIDOS -->
        html_modal_sites +
        '</div>' +
        '</div>'
    }

    if(details.hasOwnProperty('data_etps_infos')){
        modalEtp = modalEtp +
        '<div class="card-header" id="headingDATAETPINFOS_' + etp + '">' +
        '<h5 class="mb-0">' +
        '<button class="btn btn-link btn-sm" type="button" data-toggle="collapse" data-target="#collapseDATAETPINFOS_' + etp + '" aria-expanded="true" aria-controls="collapseDATAETPINFOS_' + etp + '">' +
        'ETP(s) do Projeto' +
        '</button>' +
        '</h5>' +
        '</div>' +
        '<div id="collapseDATAETPINFOS_' + etp + '" class="collapse" aria-labelledby="headingDATAETPINFOS" data-parent="#accordionExample_' + etp + '">' +
        '<div id="modal-data-etps-infos' + etp + '" class="card-body">' +
        //<!-- DETALHES ETPS INFO -->
        html_modal_data_etps_infos +
        '</div>' +
        '</div>'
    }

    modalEtp = modalEtp +
    '</div>' +
    '</div>' +
    '</div>' +
    '<div class="modal-footer">' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'

    return modalEtp;
}

function checkPlot(cb, map, type, id){
    var visible = (cb.checked) ? map : null;
    var elements = etpLines.filter(function(obj){return obj.id == id && obj.type == type})
    .concat(etpMarkers.filter(function(obj){return obj.id == id && obj.type == type}))
    .concat(etpMarkers.filter(function(obj){return obj.id == id && obj.type == 'ROUTER'}));
    elements.forEach(function(item){
        item.setMap(visible);
    });
}

function checkPlotElements(cb, map, etp, type, rota='N'){
    var visible = (cb.checked) ? map : null;

    if(type == 'ETP'){
        if(document.getElementById('checkElements_' + etp + '_SITES') !== null){
            document.getElementById('checkElements_' + etp + '_SITES').checked = cb.checked;
            checkPlotElements(cb, map, etp, 'SITE');
        }
        if(document.getElementById('checkElements_' + etp + '_OMS') !== null){
            document.getElementById('checkElements_' + etp + '_OMS').checked = cb.checked;
            checkPlotElements(cb, map, etp, 'OMS');
        }
        if(document.getElementById('checkElements_' + etp + '_OCH') !== null){
            if(!cb.checked){
                document.getElementById('checkElements_' + etp + '_OCH').checked = cb.checked;
                checkPlotElements(cb, map, etp, 'OCH');
            }
        }
        if(document.getElementById('checkElements_' + etp + '_ODU') !== null){
            if(!cb.checked){
                document.getElementById('checkElements_' + etp + '_ODU').checked = cb.checked;
                checkPlotElements(cb, map, etp, 'ODU');
            }
        }
        Object.keys(etps_result[etp]['resumes']['CIRCUITOS']).forEach(function(r){
            if(document.getElementById('checkElements_' + etp + '_CIRCUITO_'+ r.replace(/\s+/g, '')) !== null){
                document.getElementById('checkElements_' + etp + '_CIRCUITO_'+ r.replace(/\s+/g, '')).checked = cb.checked;
                checkPlotElements(cb, map, etp, 'EILD-LEGADO', r);
            }
        })
    } else if(type == 'EILD-LEGADO'){
        etpLines.filter(function(obj){return obj.etp == etp && obj.type == 'EILD' && obj.Rota == rota}).forEach(function(item){
            if(document.getElementById('check_' + etp + '_' + item.id) !== null){
                document.getElementById('check_' + etp + '_' + item.id).checked = cb.checked;
            }
            item.setMap(visible);
        });
        etpLines.filter(function(obj){return obj.etp == etp && obj.type == 'LEGADO' && obj.Rota == rota}).forEach(function(item){
            if(document.getElementById('check_' + etp + '_' + item.id) !== null){
                document.getElementById('check_' + etp + '_' + item.id).checked = cb.checked;
            }
            item.setMap(visible);
        });
        etpMarkers.filter(function(obj){return obj.etp == etp && obj.type == 'ROUTER' && obj.Rota == rota}).forEach(function(item){
            item.setMap(visible);
        });
    } else if(type == 'SITE'){
        etpMarkers.filter(function(obj){return obj.etp == etp}).forEach(function(item){
            if(document.getElementById('check_' + etp + '_' + item.id) !== null){
                document.getElementById('check_' + etp + '_' + item.id).checked = cb.checked;
            }
            item.setMap(visible);
        });
    } else {
        etpLines.filter(function(obj){return obj.etp == etp && obj.type == type}).forEach(function(item){
            if(document.getElementById('check_' + etp + '_' + item.id) !== null){
                document.getElementById('check_' + etp + '_' + item.id).checked = cb.checked;
            }
            item.setMap(visible);
        });
    }

}

function showModalDetails(status, etp){
    document.getElementById('ModalDetails_' + etp).style.display = status;
}

function initMap() {

    $.ajax({
        url: '/ajax-topology',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            topologyBase = defineNetworkCoordinates(response['networkTopologyCoordinates'], 'base', 1, 0.5);
            sitesBase = defineMarkers(response['locations'], 6, 'base', true);
            planBase = defineNetworkCoordinates(response['networkTopologyCoordinates'].filter(function(obj){return obj.Status != 'Ativado'}), 'plan', 2, 1);
        },
        error: function(error){
            console.log(error);
        }
    });

    var styledMapType = new google.maps.StyledMapType(
            [{ "elementType": "geometry", "stylers": [ { "color": "#f5f5f5" } ] },
            { "elementType": "geometry.fill", "stylers": [ { "visibility": "simplified" } ] },
            //{ "elementType": "geometry.fill", "stylers": [ { "color": "#FFFAFA" } ] },
            { "elementType": "geometry.stroke", "stylers": [ { "visibility": "on" }, { "weight": 1 } ] },
            { "elementType": "labels.icon", "stylers": [ { "visibility": "off" } ] },
            { "elementType": "labels.text.fill", "stylers": [ { "color": "#9a9a9a" } ] },
            { "elementType": "labels.text.stroke", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [ { "color": "#bdbdbd" } ] },
            { "featureType": "poi", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "poi.park", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "road", "elementType": "geometry", "stylers": [ { "color": "#ffffff" } ] },
            { "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "road.highway", "elementType": "geometry", "stylers": [ { "color": "#dadada" } ] },
            { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [ { "color": "#616161" } ] },
            { "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "transit.line", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "transit.station", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "water", "elementType": "geometry", "stylers": [ { "color": "#c9c9c9" } ] },
            //{ "featureType": "water", "elementType": "geometry.fill", "stylers": [ {"color": "#F0FFFF"} ] },
            { "featureType": "water", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] } ],
            {name: 'Simples'});

    map = new google.maps.Map(document.getElementById('map'), {
      zoom: 5,
      center: new google.maps.LatLng(-15.7797203, -47.9297218), //Brasília
      //mapTypeId: 'roadmap',
      //gestureHandling: 'cooperative',
      streetViewControl: false,
      zoomControl: false,
      fullscreenControl: false,
      //mapTypeControl: true,
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain',
                'styled_map']
      }
    });

    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');

    map.controls[google.maps.ControlPosition.LEFT_TOP].push(resumeEtp);
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(searchEtp);
    map.controls[google.maps.ControlPosition.BOTTOM_LEFT].push(topology);
    map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(statusEtp);
    map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(cpomEtp);

    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(btNewEtp);
    map.controls[google.maps.ControlPosition.RIGHT_TOP].push(listEtps);

    if(authedit){
        btNewEtp.innerHTML = '<button type="button" class="btn btn-danger btn-circle" title="Novo ETP" onclick="newEtpStart()">+</button>';
    }

    visibleElements('none');
    createInfoTables('block');
}

function createModalAtributes(atributes, etp, validation){
    var atrTipoEtp = atributes['tipoEtp'];
    var atrVersao = atributes['emissao'];
    var atrAno = atributes['ano'];
    var atrDataEmissao = new Date(Date.parse(atributes['data_emissao']));
    atrDataEmissao = String(atrDataEmissao.getDate()).padStart(2, "0")+'/'+String(atrDataEmissao.getMonth()+1).padStart(2, "0")+'/'+String(atrDataEmissao.getFullYear());
    var atrElaborador = atributes['elaborador'][0];
    var atrDemanda = atributes['demanda'][0];
    var atrMotivador = atributes['motivador'][0];
    var atrTitulo = atributes['titulo'];

    var atrHierarquia = atributes['hierarquia'];
    var atrHierarquiaTxt = '';
    atrHierarquia.forEach((data) => atrHierarquiaTxt = atrHierarquiaTxt+data[1]+' | ');
    atrHierarquiaTxt = atrHierarquiaTxt.substring(0, atrHierarquiaTxt.length-3);
    var atrHierarquiaList = []
    atrHierarquia.forEach((data) => atrHierarquiaList.push(data[0]));
    var atrPropFibra = atributes['prop_fibra'];
    var atrPropFibraTxt = '';
    atrPropFibra.forEach((data) => atrPropFibraTxt = atrPropFibraTxt+data[1]+' | ');
    atrPropFibraTxt = atrPropFibraTxt.substring(0, atrPropFibraTxt.length-3);
    var atrPropFibraList = []
    atrPropFibra.forEach((data) => atrPropFibraList.push(data[0]));
    var atrVendor = atributes['vendor'];
    var atrVendorTxt = '';
    atrVendor.forEach((data) => atrVendorTxt = atrVendorTxt+data[0]+' | ');
    atrVendorTxt = atrVendorTxt.substring(0, atrVendorTxt.length-3);
    var atrVendorList = []
    atrVendor.forEach((data) => atrVendorList.push(data[0]));

    var atrMunA = atributes['municipio_a'];
    var atrMunATxt = atrMunA[0]+' ('+atrMunA[1]+')';
    var atrMunB = atributes['municipio_b'];
    var atrMunBTxt = (atrMunB.length>0) ? atrMunB[0]+' ('+atrMunB[1]+')' : '';

    var atrComplemento = atributes['complemento'];
    var atrComplementoTipo = (atrComplemento.length>0) ? atrComplemento[0] : '';
    var atrComplementoTxt = (atrComplemento.length>0) ? atrComplemento[1] : '';

    var atrCancelamento = atributes['cancelamento'];
    var atrCancelamentoChecked = (atrCancelamento) ? 'checked' : '';

    var atrDescricaoMacro = (atributes['descricao_macro']) ? atributes['descricao_macro'] : '';
    var atrObjetivo = (atributes['objetivo']) ? atributes['objetivo'] : '';
    var atrJustificativa  = (atributes['justificativa']) ? atributes['justificativa'] : '';
    var atrPredecessoras  = (atributes['predecessoras']) ? String(atributes['predecessoras']).replace(',', ', ') : '';
    var atrEscopo = (atributes['escopo']) ? atributes['escopo'] : '';
    var atrPremissas = (atributes['premissas']) ? atributes['premissas'] : '';
    var atrRestricoes = (atributes['restricoes']) ? atributes['restricoes'] : '';
    var atrFatoresCriticos = (atributes['fatores_criticos']) ? atributes['fatores_criticos'] : '';
    var atrTopologiaType = (atributes['topologia_type'] && atributes['topologia_type'] !== 'null') ? atributes['topologia_type'] : 'null';
    var atrTopologiaFile = (atributes['topologia_file'] && atributes['topologia_file'] !== 'null') ? atributes['topologia_file'] : 'null';
    var atrTopologiaFileVisibility = (atributes['topologia_type'] && atributes['topologia_type'] !== 'null') ? 'visible' : 'hidden';

    var atrDescricaoMacroTxt = (atributes['descricao_macro']) ? atributes['descricao_macro'] : 'Não Informado';
    var atrObjetivoTxt = (atributes['objetivo']) ? atributes['objetivo'] : 'Não Informado';
    var atrJustificativaTxt  = (atributes['justificativa']) ? atributes['justificativa'] : 'Não Informado';
    var atrEscopoTxt = (atributes['escopo']) ? atributes['escopo'].replace(/\n/g, "<br>") : 'Não Informado';
    var atrPremissasTxt = (atributes['premissas']) ? atributes['premissas'].replace(/\n/g, "<br>") : 'Não Informado';
    var atrRestricoesTxt = (atributes['restricoes']) ? atributes['restricoes'].replace(/\n/g, "<br>") : 'Não Informado';
    var atrFatoresCriticosTxt = (atributes['fatores_criticos']) ? atributes['fatores_criticos'].replace(/\n/g, "<br>") : 'Não Informado';

    html = '' +
    '<form id="formGravaEtp-' + etp +'">' +
    '<div class="form-row">' +
    '<div class="form-group col-md-2">' +
    '<label for="inputEtp-' + etp +'"><b>ETP Nº</b></label>' +
    '<big id="inputEtp-' + etp +'" class="form-text text-muted">' + etp +'</big>' +
    '<input type="hidden" name="inputEtpHidden-' + etp +'" id="inputEtpHidden-' + etp +'" value="' + etp +'" />' +
    //'<input type="hidden" name="csrf_token" id="inputToken-' + etp +'" value="' + token + '" />' +
    '</div>' +
    '<div class="form-group col-md-3">' +
    '<label for="inputTipoEtp-' + etp +'"><b>Tipo ETP</b></label>' +
    '<big id="inputTipoEtp-' + etp +'" class="form-text text-muted">' + atrTipoEtp + '</big>' +
    '</div>' +
    '<div class="form-group col-md-2">' +
    '<label for="inputVersao-' + etp +'"><b>Versao</b></label>' +
    '<big id="inputVersao-' + etp +'" class="form-text text-muted">' + atrVersao + '</big>' +
    '</div>' +
    '<div class="form-group col-md-2">' +
    '<label for="inputAno-0040-0490"><b>Ano</b></label>' +
    '<big id="inputAno-' + etp +'" class="form-text text-muted">' + atrAno + '</big>' +
    '</div>' +
    '<div class="form-group col-md-3">' +
    '<label for="inputDataEmissao-' + etp +'"><b>Data da Emissão</b></label>' +
    '<big id="inputDataEmissao-' + etp +'" class="form-text text-muted">' + atrDataEmissao + '</big>' +
    '</div>' +
    '</div>' +

    '<div class="form-row">' +
    '<div class="form-group col-md-4">' +
    '<label for="inputElaborador-' + etp +'"><b>Elaborador</b></label>' +
    '<big id="inputElaborador-' + etp +'" class="form-text text-muted">' + atrElaborador + '</big>' +
    '</div>' +
    '<div class="form-group col-md-4">' +
    '<label for="inputDemanda-' + etp +'"><b>Demanda</b></label>' +
    '<big id="inputDemanda-' + etp +'" class="form-text text-muted">' + atrDemanda + '</big>' +
    '</div>' +
    '<div class="form-group col-md-4">' +
    '<label for="inputMotivador-' + etp +'"><b>Motivador</b></label>' +
    '<big id="inputMotivador-' + etp +'" class="form-text text-muted">' + atrMotivador + '</big>' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputTitulo-' + etp +'"><b>Título</b></label>' +
    '<big id="inputTitulo-' + etp +'" class="form-text text-muted">' + atrTitulo + '</big>' +
    '</div>' +
    '</div>' +
    '<hr>'
    if(validation && atrCancelamento == false){
        html = html + '<i id="inputEtpEdit-' + etp +'" class="material-icons" style="cursor:pointer" onclick="disableEtpAtributes(\'' + etp +  '\', false, \'block\', \'none\')">edit_note</i>'
    }
    html = html +
    '<div class="form-row">' +
    '<div class="form-group col-md-4">' +
    '<label for="inputHierarquia-' + etp +'"><b>Hierarquia</b></label>' +
    '<big id="inputHierarquiaTxt-' + etp +'" class="form-text text-muted">' + atrHierarquiaTxt + '</big>' +
    '<select style="display: none" class="form-control" disabled id="inputHierarquia-' + etp +'" multiple>' +
    '<option></option>'
    supportsedit['hierarchy'].forEach(function(item){
        var slctd = (atrHierarquiaList.includes(item)) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '<div class="form-group col-md-4">' +
    '<label for="inputPropFibra-' + etp +'"><b>Prop. da Fibra</b></label>' +
    '<big id="inputPropFibraTxt-' + etp +'" class="form-text text-muted">' + atrPropFibraTxt + '</big>' +
    '<select style="display: none" class="form-control" disabled id="inputPropFibra-' + etp +'" multiple>' +
    '<option></option>'
    supportsedit['fiber_owner'].forEach(function(item){
        var slctd = (atrPropFibraList.includes(item)) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '<div class="form-group col-md-4">' +
    '<label for="inputVendor-' + etp +'"><b>Vendor</b></label>' +
    '<big id="inputVendorTxt-' + etp +'" class="form-text text-muted">' + atrVendorTxt + '</big>' +
    '<select style="display: none" class="form-control" disabled id="inputVendor-' + etp +'" multiple>' +
    '<option></option>'
    supportsedit['vendor'].forEach(function(item){
        var slctd = (atrVendorList.includes(item)) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '</div>' +

    '<div class="form-row">' +
    '<div class="form-group col-md-4">' +
    '<label for="inputComplementoTipo-' + etp +'"><b>Tipo do Complemento</b></label>' +
    '<big id="inputComplementoTipoTxt-' + etp +'" class="form-text text-muted">' + atrComplementoTipo + '</big>' +
    '<select onchange="complementoModelo(\'inputComplementoTipo-' + etp +'\', \'inputComplemento-' + etp +'\')" style="display: none" class="form-control" disabled id="inputComplementoTipo-' + etp +'">' +
    '<option></option>'
    supportsedit['complemento'].forEach(function(item){
        var slctd = (atrComplementoTipo.includes(item)) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '<div class="form-group col-md-8">' +
    '<label for="inputComplemento-' + etp +'"><b>Complemento</b></label>' +
    '<big id="inputComplementoTxt-' + etp +'" class="form-text text-muted">' + atrComplementoTxt + '</big>' +
    '<input style="display: none" type="text" maxlength="25" class="form-control" id="inputComplemento-' + etp +'" disabled value="' + atrComplementoTxt + '">' +
    '</div>' +
    '</div>' +

    '<div class="form-row">' +
    '<div class="form-group col-md-4">' +
    '<label for="inputMunA-' + etp +'"><b>Mun. A</b></label>' +
    '<big id="inputMunATxt-' + etp +'" class="form-text text-muted">' + atrMunATxt + '</big>' +
    '<select style="display: none" class="form-control" disabled id="inputMunA-' + etp +'">' +
    '<option></option>'
    supportsedit['cnl'].forEach(function(item){
        var slctd = (atrMunA[0] === item) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '<div class="form-group col-md-4">' +
    '<label for="inputMunB-' + etp +'"><b>Mun. B</b></label>' +
    '<big id="inputMunBTxt-' + etp +'" class="form-text text-muted">' + atrMunBTxt + '</big>' +
    '<select style="display: none" class="form-control" disabled id="inputMunB-' + etp +'">' +
    '<option></option>'
    supportsedit['cnl'].forEach(function(item){
        var slctd = (atrMunB[0] === item) ? 'selected' : '';
        html = html + '<option '+slctd+'>' + item + '</option>';
    })
    html = html +
    '</select>' +
    '</div>' +
    '</div>' +

    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputDescricaoMacro-' + etp +'"><b>Descrição Macro do Projeto</b></label>' +
    '<big id="inputDescricaoMacroTxt-' + etp +'" class="form-text text-muted">' + atrDescricaoMacroTxt + '</big>' +
    '<input style="display: none" type="text" class="form-control" id="inputDescricaoMacro-' + etp +'" disabled value="' + atrDescricaoMacro + '">' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputObjetivo-' + etp +'"><b>Objetivo do Projeto</b></label>' +
    '<big id="inputObjetivoTxt-' + etp +'" class="form-text text-muted">' + atrObjetivoTxt + '</big>' +
    '<input style="display: none" type="text" class="form-control" id="inputObjetivo-' + etp +'" disabled value="' + atrObjetivo + '">' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputJustificativa-' + etp +'"><b>Justificativa</b></label>' +
    '<big id="inputJustificativaTxt-' + etp +'" class="form-text text-muted">' + atrJustificativaTxt + '</big>' +
    '<input style="display: none" type="text" class="form-control" id="inputJustificativa-' + etp +'" disabled value="' + atrJustificativa + '">' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputPredecessoras-' + etp +'"><b>Predecessoras (separadas por vírgula)</b></label>' +
    '<input style="display: none" type="text" class="form-control" id="inputPredecessoras-' + etp +'" disabled value="' + atrPredecessoras + '">' +
    '<span id="inputPredecessorasTxt-' + etp +'" class="form-text text-info">'
    if(atrPredecessoras !== ''){
        html = html +
        '<a style="cursor: pointer" onclick="plotPredecessoras(\'' + etp + ' ' + atrPredecessoras.replaceAll(',', ' ') +  '\')"><i class="material-icons">visibility</i> Plotar ' + etp +' com as predecessoras..</a>'
    } else {
        html = html +
        'Não Informado'
    }
    html = html +
    '</span>' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputEscopo-' + etp +'"><b>Escopo</b></label>' +
    '<big id="inputEscopoTxt-' + etp +'" class="form-text text-muted">' + atrEscopoTxt + '</big>' +
    '<textarea style="display: none" class="form-control" id="inputEscopo-' + etp +'" rows="10" disabled>' + atrEscopo + '</textarea>' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputPremissas-' + etp +'"><b>Premissas<br>(Novas Rotas destacar premissas do projeto)</b></label>' +
    '<big id="inputPremissasTxt-' + etp +'" class="form-text text-muted">' + atrPremissasTxt + '</big>' +
    '<textarea rows="3" style="display: none" type="text" class="form-control" id="inputPremissas-' + etp +'" disabled>' + atrPremissas + '</textarea>' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputRestricoes-' + etp +'"><b>Restrições</b></label>' +
    '<big id="inputRestricoesTxt-' + etp +'" class="form-text text-muted">' + atrRestricoesTxt + '</big>' +
    '<textarea rows="1" style="display: none" type="text" class="form-control" id="inputRestricoes-' + etp +'" disabled>' + atrRestricoes + '</textarea>' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputFatoresCriticos-' + etp +'"><b>Fatores Criticos</b></label>' +
    '<big id="inputFatoresCriticosTxt-' + etp +'" class="form-text text-muted">' + atrFatoresCriticosTxt + '</big>' +
    '<textarea rows="1" style="display: none" type="text" class="form-control" id="inputFatoresCriticos-' + etp +'" disabled>' + atrFatoresCriticos + '</textarea>' +
    '</div>' +
    '</div>' +
    '<div style="display: none" id="inputMudaVersaoDiv-' + etp +'" class="form-row">' +
    '<div class="form-group form-check">' +
    '<input disabled type="checkbox" class="form-check-input" id="inputMudaVersao-' + etp +'">' +
    '<label id="labelMudaVersao-' + etp +'" class="form-check-label" for="inputMudaVersao-' + etp +'">Alterar ETP para Versão ' + String(parseInt(atrVersao)+1) + '</label>' +
    '</div>' +
    '</div>' +
    '<div style="display: none" id="inputCancelamentoDiv-' + etp +'" class="form-row">' +
    '<div class="form-group form-check">' +
    '<input ' + atrCancelamentoChecked + ' disabled type="checkbox" class="form-check-input" id="inputCancelamento-' + etp +'" onclick="checkCancelamento(\'' + etp +  '\')">' +
    '<label class="form-check-label" for="inputCancelamento-' + etp +'">Cancelar a ETP ' + etp +'</label>' +
    '</div>' +
    '</div>' +
    '<div class="form-group">' +
    '<input type="hidden" name="inputTopologiaHidden-' + etp +'" id="inputTopologiaHidden-' + etp +'" value="' + atrTopologiaFile + '" />' +
    '<input type="hidden" name="inputTopologiaTypeHidden-' + etp +'" id="inputTopologiaTypeHidden-' + etp +'" value="' + atrTopologiaType + '" />' +
    '<label for="inputTopologia-' + etp +'" aria-describedby="inputTopologiaHelp-' + etp +'">Topologia (pdf)...</label>' +
    '<span id="textDownloadTopologia-' + etp +'" class="form-text text-info" style="visibility: ' + atrTopologiaFileVisibility + '">' +
    '<a style="cursor: pointer" onclick="downloadEtpTopology(\'' + etp +  '\')">Baixar topologia-' + etp +'.pdf</a>' +
    '</span>' +
    //'<br>' +
    '<input style="display: none" type="file" class="form-control-file" id="inputTopologia-' + etp +'" disabled>' +
    '<small style="display: none" id="inputTopologiaHelp-' + etp +'" class="form-text text-muted">' +
    'Arquivos devem estar obrigatoriamente na extensão .pdf' +
    '</small>' +
    '</div>' +
    '<button style="display: none" class="btn btn-outline-secondary" type="button" id="bt-grava-etp-' + etp +'" onclick="saveEtpAtributes(\'' + etp +  '\')">Gravar</button>' +
    '</form>' +

    '<hr>' +
    '<h5 class="mb-0">Histórico de Atualizações</h5>' +
    '<table class="table">' +
    '<thead>' +
    '<tr>' +
    '<th scope="col"></th>' +
    '<th scope="col">Data</th>' +
    '<th scope="col">Usuário</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>'
    atributes['changes_control'].reverse();
    atributes['changes_control'].forEach(function(item, key){
        var dataMudanca = new Date(Date.parse(item['date']));
        html = html +
        '<tr>' +
        '<td scope="row">' +
        '<a data-toggle="collapse" href="#collapseChange-' + etp + '-' + key + '" aria-expanded="false" aria-controls="collapseChange0">+</a>' +
        '</td>' +
        '<td scope="row">' + String(dataMudanca.getDate()).padStart(2, "0")+'/'+String(dataMudanca.getMonth()+1).padStart(2, "0")+'/'+String(dataMudanca.getFullYear())+' '+String(dataMudanca.getHours()).padStart(2, "0")+':'+String(dataMudanca.getMinutes()).padStart(2, "0")+':'+String(dataMudanca.getSeconds()).padStart(2, "0") +'</td>' +
        '<td scope="row">' + item['name'] + '</td>' +
        '</tr>' +
        '<tr class="collapse multi-collapse" id="collapseChange-' + etp + '-' + key + '">' +
        '<td colspan="6">' +
        '<table class="table table-sm thead-dark">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Atributo</th>' +
        '<th scope="col">De</th>' +
        '<th scope="col">Para</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        item['changes'].forEach(function(itemC, keyC){
            if(itemC['field'] != 'topologia_type'){
                var fromChange = (itemC['field'] == 'topologia_file') ? '' : itemC['from'];
                var toChange = (itemC['field'] == 'topologia_file') ? 'Alteração de arquivo' : itemC['to'];
                html = html +
                '<tr>' +
                '<td scope="row">' + itemC['field'] + '</td>' +
                '<td scope="row">' + fromChange + '</td>' +
                '<td scope="row">' + toChange + '</td>' +
                '</tr>'
            }
        })
        html = html +
        '</tbody>' +
        '</table>' +
        '</td>' +
        '</tr>'

    })
    html = html +
    '</tbody>' +
    '</table>'

    return html;
}

function filterCotacaoTipo(etp){
    var tipo = document.getElementById('changeCotacaoTipo-'+etp).value;
    var html = bodyCotacao(etp, tipo);
    document.getElementById('bodyCotacaoTipo-'+etp).innerHTML = html;
}

function bodyCotacao(etp, tipo){
    html = '';
    if(tipo == 'Todos'){
        var detailsCotacao = etps_result[etp]["details"]["COTACAO"];
    } else {
        var detailsCotacao = etps_result[etp]["details"]["COTACAO"].filter(function(obj){return obj.TipoLabel == tipo});
    }

    detailsCotacao.forEach(function(item){
        var categoria = (item.Categoria) ? item.Categoria : '';
        html = html +
        '<tr>' +
        '<td scope="row">' + item.Site + '</td>' +
        '<td scope="row">' + item.IdT2 + '</td>' +
        '<td scope="row">' + item.T2Codigo + '</td>' +
        '<td scope="row">' + item.T2DescricaoCodigo + '</td>' +
        '<td scope="row">' + item.Fabricante + '</td>' +
        '<td scope="row">' + item.Quantidade + '</td>' +
        '<td scope="row">' + item.Unidade + '</td>' +
        '<td scope="row">' + 'R$ ' + parseFloat(Math.round(item.ValorTotalLiqLiq * 100) / 100).toLocaleString('pt-BR') + '</td>' +
        //'<td scope="row">' + item.Tipo + '</td>' +
        //'<td scope="row">' + categoria + '</td>' +
        '</tr>'
    });

    return html;
}

function checkCancelamento(etp){
    if(document.getElementById('inputCancelamento-'+etp).checked){
        var txt = 'Se as alterações forem gravadas, a etp '+etp+' será cancelada. \n Essa operação não poderá ser revertida.'
        swal("Atenção!", txt, "warning");
    }
}

async function saveEtpAtributes(etp){
    var saveEtp = true;
    var  fieldsCheck = {
        inputHierarquia: Array.prototype.map.call(document.getElementById('inputHierarquia-'+etp).selectedOptions, function(x){ return x.value }),
        inputPropFibra: Array.prototype.map.call(document.getElementById('inputPropFibra-'+etp).selectedOptions, function(x){ return x.value }),
        inputVendor: Array.prototype.map.call(document.getElementById('inputVendor-'+etp).selectedOptions, function(x){ return x.value }),
        inputMunA: String(document.getElementById('inputMunA-'+etp).value)
    };

    Object.keys(fieldsCheck).forEach(function(item){
        e = ['inputHierarquia', 'inputPropFibra']
        if((document.getElementById('inputEtpHidden-'+etp).value).substring(0, 4) === '0050' && Boolean(e.find( i => i === item))){

        } else {
            if(fieldsCheck[item] == '' || fieldsCheck[item].length == 0){
                saveEtp = false;
                document.getElementById(item+'-'+etp).classList.remove('is-valid');
                document.getElementById(item+'-'+etp).classList.add('is-invalid');
            } else {
                document.getElementById(item+'-'+etp).classList.remove('is-invalid');
                document.getElementById(item+'-'+etp).classList.add('is-valid');
            }
        }
    })
    fieldsCheck['inputMunB'] = String(document.getElementById('inputMunB-'+etp).value);
    fieldsCheck['inputComplementoTipo'] = String(document.getElementById('inputComplementoTipo-'+etp).value);
    fieldsCheck['inputComplemento'] = String(document.getElementById('inputComplemento-'+etp).value);

    if(saveEtp){
        var inputFileTopologia = document.getElementById('inputTopologia-'+etp).files[0];
        var topologiaFile = [];

        if(inputFileTopologia && inputFileTopologia.type.substring(inputFileTopologia.type.length, inputFileTopologia.type.length-3) !== 'pdf'){
            swal("Erro!", "Um erro ocorreu. O anexo da topologia deve ser no formato pdf!", "error");
        } else {
            if(inputFileTopologia){
                topologiaFile.push(inputFileTopologia.type);
                await getBase64(inputFileTopologia).then(function(result) {
                    topologiaFile.push(result.toString().replace(/^data:(.*,)?/, ''));
                }).catch(err =>{
                    console.log("ERRO: ",err);
                });
            } else {
                topologiaFile = [document.getElementById('inputTopologiaTypeHidden-'+etp).value, document.getElementById('inputTopologiaHidden-'+etp).value];
            }

            $.ajax({
                url: '/ajax-etp-atributos',
                type: 'POST',
                data: {
                    etp: String(document.getElementById('inputEtpHidden-'+etp).value),

                    hierarquia: fieldsCheck['inputHierarquia'].join('_'),
                    prop_fibra: fieldsCheck['inputPropFibra'].join('_'),
                    vendor: fieldsCheck['inputVendor'].join('_'),
                    municipio_a: fieldsCheck['inputMunA'],
                    municipio_b: fieldsCheck['inputMunB'],
                    complemento_tipo: fieldsCheck['inputComplementoTipo'],
                    complemento_texto: fieldsCheck['inputComplemento'],

                    descricao_macro: String(document.getElementById('inputDescricaoMacro-'+etp).value),
                    objetivo: String(document.getElementById('inputObjetivo-'+etp).value),
                    justificativa: String(document.getElementById('inputJustificativa-'+etp).value),
                    predecessoras: String(document.getElementById('inputPredecessoras-'+etp).value),
                    escopo: String(document.getElementById('inputEscopo-'+etp).value),
                    premissas: String(document.getElementById('inputPremissas-'+etp).value),
                    restricoes: String(document.getElementById('inputRestricoes-'+etp).value),
                    fatores_criticos: String(document.getElementById('inputFatoresCriticos-'+etp).value),
                    topologia_type: String(topologiaFile[0]),
                    topologia_file: String(topologiaFile[1]),
                    muda_emissao: document.getElementById('inputMudaVersao-'+etp).checked,
                    cancelamento: document.getElementById('inputCancelamento-'+etp).checked
                },
                //contentType: 'application/json',
                success: function(response){
                    html_modal_atributes = createModalAtributes(response['atributes'], etp, true);
                    document.getElementById('modal-detalhes-atributos_' + etp).innerHTML = html_modal_atributes;

                    html_modal_checklist = createModalChecklist(response['atributes']['checklist'], etp, newValidation);
                    document.getElementById('modal-detalhes-checklist_' + etp).innerHTML = html_modal_checklist;

                    swal("Sucesso!", "Os atributos da ETP foram atualizados!", "success");
                },
                error: function(error){
                    console.log(error);
                    swal("Erro!", "Um erro ocorreu. Os atributos da ETP não foram atualizados!", "error");
                }
            });
        }
    } else {
        swal("Erro!", "Campo(s) obrigatório(s) não foram preenchidos!", "error");
    }
}

function disableEtpAtributes(etp, boolDisabled, displayInput, displayTxt){
    var fields = ['inputDescricaoMacro', 'inputObjetivo', 'inputJustificativa', 'inputPredecessoras',
                    'inputEscopo', 'inputPremissas', 'inputRestricoes', 'inputFatoresCriticos',
                    'inputHierarquia', 'inputPropFibra', 'inputVendor', 'inputComplementoTipo',
                    'inputComplemento', 'inputMunA', 'inputMunB']
    var forDeletion = ['inputHierarquia', 'inputPropFibra']

    if((document.getElementById('inputEtpHidden-'+etp).value).substring(0, 4) === '0050'){
        fields = fields.filter(item => !forDeletion.includes(item));
    }

    fields.forEach(function(item){
        document.getElementById(item+'-'+etp).disabled = boolDisabled;
        document.getElementById(item+'-'+etp).style.display = displayInput;
        document.getElementById(item+'Txt-'+etp).style.display = displayTxt;
    })

    document.getElementById('inputMudaVersao-'+etp).disabled = boolDisabled;
    document.getElementById('inputMudaVersaoDiv-'+etp).style.display = displayInput;
    document.getElementById('inputCancelamento-'+etp).disabled = boolDisabled;
    document.getElementById('inputCancelamentoDiv-'+etp).style.display = displayInput;

    document.getElementById('inputTopologia-'+etp).disabled = boolDisabled;
    document.getElementById('inputTopologia-'+etp).style.display = displayInput;
    document.getElementById('inputTopologiaHelp-'+etp).style.display = displayInput;

    document.getElementById('bt-grava-etp-'+etp).style.display = displayInput;
}

function plotPredecessoras(txt){
    document.getElementById('etp-text').value = txt;
    document.getElementById('bt-busca-etp').click();
}

function downloadEtpTopology(etp){
    checkForMIMEType(document.getElementById('inputTopologiaHidden-'+etp).value, 'topologia-'+etp+'.pdf');
}

function getBase64(file) {
    return new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.onload = function() { return resolve(reader.result); };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function checkForMIMEType(response, filename) {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";

    var blob;
    blob = converBase64toBlob(response, 'application/pdf');
    var blobURL = URL.createObjectURL(blob);
    //window.open(blobURL);

    a.href = blobURL;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(blobURL);

}

function converBase64toBlob(content, contentType) {
  contentType = contentType || '';
  var sliceSize = 512;
  var byteCharacters = window.atob(content); //method which converts base64 to binary
  var byteArrays = [
  ];

  for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    var slice = byteCharacters.slice(offset, offset + sliceSize);
    var byteNumbers = new Array(slice.length);
    for (var i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
  var blob = new Blob(byteArrays, {
    type: contentType
  }); //statement which creates the blob
  return blob;
}

function refreshEtp(etp){
    swal("", "Será realizado uma tentativa de atualização da ETP!!! \n\n Esse processo levará um pouco mais de tempo. Deseja continuar?", "warning",
    {buttons: {
        cancel: "Cancelar",
        roll: {
            text: 'Continuar',
            type: 'success'
            }
        }
    }
    ).then(function(e) {
        if(e){ refresh(etp); }
    });

    function refresh(etp){
        $.ajax({
            url: '/ajax-refresh-etp',
            type: 'GET',
            data: {
                etp: String(etp)
            },
            //contentType: 'application/json',
            success: function(response){
                etp = response['etp']

                //modalDetailsEtps.innerHTML = '';
                showModalDetails('none', etp);
                modalDetailsEtps.innerHTML = '';

                document.getElementById('etp-text').value = ""
                document.getElementById('etp-text').value = etp;
                document.getElementById('bt-busca-etp').click();
            },
            error: function(error){
                swal("Erro!", "Ocorreu um erro ao atualizar a ETP!", "error");
            }
        });
    }
}

function changeFilterGroup(){
    var tipo = document.getElementById('filter-group').options[document.getElementById('filter-group').selectedIndex].text;
    var txt_etp = document.getElementById('etp-text');
    if(document.getElementById('filter-group').value == 'etp'){
        txt_etp.disabled = false;
        txt_etp.value = '';
    } else {
        txt_etp.value = tipo;
        txt_etp.disabled = true;
    }
}