// Filtros por Status
function createFilterStatus(statusFilter){
    document.getElementById("progress").innerHTML = html_spinner;

    $.ajax({
        url: '/ajax-etp-status',
        type: 'GET',
        contentType: 'application/json',
        data: {
              status: String(statusFilter)
            },
        success: function(response){
            filterStatusResponseTable = response['result'];
            filterStatusResponseTitle = response['title'];
            document.getElementById('status-filter').style.display = 'none';

            var filterStatusDiv = document.createElement('div');
            filterStatusDiv.id = 'filterStatusDivId';
            createFilterStatusDiv(filterStatusDiv, filterStatusResponseTitle);
            filterStatusDiv.setAttribute('class', 'w-25');
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(filterStatusDiv);

            var filterStatusSelected;

            $.extend( true, $.fn.dataTable.defaults, {
                retrieve: true,
                lengthChange: false,
                paging: false,
                info: false
            } );

            $( "#accordionFilterStatus" ).on("shown.bs.collapse", function() {
                $.each($.fn.dataTable.tables(true), function(){
                $(this).DataTable().columns.adjust().draw();
                });
            });

            var table = $('#tableFilterStatus').DataTable({
                data: filterStatusResponseTable,
                columns: [
                    { title: '', defaultContent: '' },
                    { title: 'ETP', data: 'ETP' },
                    { title: 'SP FSP', data: 'SP_FSP' },
                    { title: 'UFS', data: 'UFS' },
                    { title: 'Resp. Tecn.', data: 'RESPONSAVEL_TECNICO'}
                ],
                columnDefs: [{
                    orderable: false,
                    targets: [0, 2, 3]
                }, {
                    targets: [1],
                    orderData: [1, 2]
                }, {
                    targets: 0,
                    checkboxes: {
                        selectRow: true
                    }
                }],
                select: {
                    style: 'multi'
                },
                scrollY: '400px',
                scrollCollapse: true,
                language: {
                    //url: "http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
                    search: 'Pesquisar:',
                    zeroRecords: 'Nenhum registro encontrado...'
                },
                dom: 'Bfrtip',
                select: true,
                buttons: [
                    {
                        text: 'Plotar',
                        action: function () {
                            filterStatusSelected = table.rows( { selected: true } );

                            if(filterStatusSelected.count() == 0){
                                alert("Nenhuma ETP selecionada...")
                            } else {
                                document.getElementById('etp-text').value = ""

                                for(i=0; i<filterStatusSelected.count(); i++){
                                    document.getElementById('etp-text').value = document.getElementById('etp-text').value + filterStatusSelected.data()[i]['ETP'] + ' ';
                                }
                                document.getElementById('bt-busca-etp').click();

                                //fecha accordion
                                document.getElementById("btnSelectFilterStatus").click();
                            }
                        }
                    }
                ]
            });
            filterStatusDiv.setAttribute('class', 'w-100');
            filterStatusDiv.setAttribute('class', 'w-25');
            document.getElementById("progress").innerHTML = '';
        },
        error: function(error){
            console.log(error);
            document.getElementById("progress").innerHTML = '';
        }
    });
}

function createFilterStatusDiv(filterStatusDiv, title){
    var html = '' +
    '<div class="accordion" id="accordionFilterStatus">' +
    '<div class="card">' +
    '<div class="card-header" id="headingFilterStatus">' +
    '<h2 class="mb-0">' +
    '<button id="btnSelectFilterStatus" class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFilterStatus" aria-expanded="true" aria-controls="collapseFilterStatus">' +
    'ETPs ' + title + '' +
    '</button>' +
    '<a class="close" href="#!">' +
    '<i class="material-icons" onclick="hideFilterStatus()">close</i>' +
    '</a>' +
    '</h2>' +
    '</div>' +
    '<div id="collapseFilterStatus" class="collapse show" aria-labelledby="headingFilterStatus" data-parent="#accordionFilterStatus">' +
    '<div class="card-body">' +
    '<table id="tableFilterStatus" class="display compact card-table table"></table>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'
    filterStatusDiv.innerHTML = html;
}

function hideFilterStatus(){
    document.getElementById('filterStatusDivId').innerHTML = "";
    map.controls[google.maps.ControlPosition.TOP_CENTER].pop(document.getElementById('filterStatusDivId'));
    document.getElementById('status-filter').style.display = 'block';
    filterStatusResponse = [];
}
