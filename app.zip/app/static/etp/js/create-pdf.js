//function createEtpPDF(details, etp, resumes) {
function createEtpPDF(etp) {
    //var sTable = document.getElementById('tab').innerHTML;
    var details = etps_result[etp]['details'];
    var resumes = etps_result[etp]['resumes'];
    var lineTag = '<div class="border-top my-3"></div>';
    var PedidosEtp = new Array(0);

    //###########################################################################################
    // CRIA HTML'S E ADICIONA AO PRINT
    html = ''

    if(details['ATRIBUTOS']){
        var atrTipoEtp = details['ATRIBUTOS']['tipoEtp'];
        var atrVersao = details['ATRIBUTOS']['emissao'];
        var atrAno = details['ATRIBUTOS']['ano'];
        var atrDataEmissao = new Date(Date.parse(details['ATRIBUTOS']['data_emissao']));
        atrDataEmissao = String(atrDataEmissao.getDate()).padStart(2, "0")+'/'+String(atrDataEmissao.getMonth()+1).padStart(2, "0")+'/'+String(atrDataEmissao.getFullYear());
        var atrElaborador = details['ATRIBUTOS']['elaborador'][0];
        var atrDemanda = details['ATRIBUTOS']['demanda'][0];
        var atrMotivador = details['ATRIBUTOS']['motivador'][0];
        var atrTitulo = details['ATRIBUTOS']['titulo'];

        var atrHierarquia = details['ATRIBUTOS']['hierarquia'];
        var atrHierarquiaTxt = '';
        atrHierarquia.forEach((data) => atrHierarquiaTxt = atrHierarquiaTxt+data[1]+' | ');
        atrHierarquiaTxt = atrHierarquiaTxt.substring(0, atrHierarquiaTxt.length-3);

        var atrPropFibra = details['ATRIBUTOS']['prop_fibra'];
        var atrPropFibraTxt = '';
        atrPropFibra.forEach((data) => atrPropFibraTxt = atrPropFibraTxt+data[1]+' | ');
        atrPropFibraTxt = atrPropFibraTxt.substring(0, atrPropFibraTxt.length-3);

        var atrVendor = details['ATRIBUTOS']['vendor'];
        var atrVendorTxt = '';
        atrVendor.forEach((data) => atrVendorTxt = atrVendorTxt+data[0]+' | ');
        atrVendorTxt = atrVendorTxt.substring(0, atrVendorTxt.length-3);

        var atrMunA = details['ATRIBUTOS']['municipio_a'];
        var atrMunATxt = atrMunA[0]+' ('+atrMunA[1]+')';
        var atrMunB = details['ATRIBUTOS']['municipio_b'];
        var atrMunBTxt = (atrMunB.length>0) ? atrMunB[0]+' ('+atrMunB[1]+')' : '';

        var atrComplemento = details['ATRIBUTOS']['complemento'];
        var atrComplementoTipo = (atrComplemento.length>0) ? atrComplemento[0] : '';
        var atrComplementoTxt = (atrComplemento.length>0) ? atrComplemento[1] : '';

        var atrDescricaoMacroTxt = (details['ATRIBUTOS']['descricao_macro']) ? details['ATRIBUTOS']['descricao_macro'] : 'Não Informado';
        var atrObjetivoTxt = (details['ATRIBUTOS']['objetivo']) ? details['ATRIBUTOS']['objetivo'] : 'Não Informado';
        var atrJustificativaTxt  = (details['ATRIBUTOS']['justificativa']) ? details['ATRIBUTOS']['justificativa'] : 'Não Informado';
        var atrPredecessoras  = (details['ATRIBUTOS']['predecessoras']) ? String(details['ATRIBUTOS']['predecessoras']).replace(',', ', ') : '';
        var atrEscopoTxt = (details['ATRIBUTOS']['escopo']) ? details['ATRIBUTOS']['escopo'].replace(/\n/g, "<br>") : 'Não Informado';
        var atrPremissasTxt = (details['ATRIBUTOS']['premissas']) ? details['ATRIBUTOS']['premissas'].replace(/\n/g, "<br>") : 'Não Informado';
        var atrRestricoesTxt = (details['ATRIBUTOS']['restricoes']) ? details['ATRIBUTOS']['restricoes'].replace(/\n/g, "<br>") : 'Não Informado';
        var atrFatoresCriticosTxt = (details['ATRIBUTOS']['fatores_criticos']) ? details['ATRIBUTOS']['fatores_criticos'].replace(/\n/g, "<br>") : 'Não Informado';

        html = html + '<h3>Atributos da ETP</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">ETP Nº</th>' +
        '<th scope="col">Tipo ETP</th>' +
        '<th scope="col">Versao</th>' +
        '<th scope="col">Ano</th>' +
        '<th scope="col">Data da Emissão</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + etp + '</td>' +
        '<td scope="row">' + atrTipoEtp + '</td>' +
        '<td scope="row">' + atrVersao + '</td>' +
        '<td scope="row">' + atrAno + '</td>' +
        '<td scope="row">' + atrDataEmissao + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Elaborador</th>' +
        '<th scope="col">Demanda</th>' +
        '<th scope="col">Motivador</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrElaborador + '</td>' +
        '<td scope="row">' + atrDemanda + '</td>' +
        '<td scope="row">' + atrMotivador + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Título</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrTitulo + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Hierarquia</th>' +
        '<th scope="col">Prop. da Fibra</th>' +
        '<th scope="col">Vendor</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrHierarquiaTxt + '</td>' +
        '<td scope="row">' + atrPropFibraTxt + '</td>' +
        '<td scope="row">' + atrVendorTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Tipo do Complemento</th>' +
        '<th scope="col">Complemento</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrComplementoTipo + '</td>' +
        '<td scope="row">' + atrComplementoTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Mun. A</th>' +
        '<th scope="col">Mun. B</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrMunATxt + '</td>' +
        '<td scope="row">' + atrMunBTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Descrição Macro do Projeto</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrDescricaoMacroTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Objetivo do Projeto</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrObjetivoTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Justificativa</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrJustificativaTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Predecessoras</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrPredecessoras + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Escopo</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrEscopoTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Premissas<br>(Novas Rotas destacar premissas do projeto)</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrPremissasTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Restrições</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrRestricoesTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +

        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Fatores Criticos</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + atrFatoresCriticosTxt + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +
        lineTag
    } else {
        html = html + '<h5>*** ETP Off-Line ***</h5>' + lineTag
    }

    if(details['SITES'].length>0){
        html = html + '<h3>Sites Envolvidos no Projeto</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">UF</th>' +
        '<th scope="col">Sigla Fixa</th>' +
        '<th scope="col">Nome</th>' +
        '<th scope="col">Endereço</th>' +
        '<th scope="col">Bairro</th>' +
        '<th scope="col">Município</th>' +
        '<th scope="col">CEP</th>' +
        '<th scope="col">Latitude</th>' +
        '<th scope="col">Longitude</th>' +
        '<th scope="col">Id Financeiro</th>' +
        '<th scope="col">Utilização</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        details['SITES'].forEach(function(item){
            html = html +
            '<tr>' +
            '<td scope="row">' + item.sigla + '</td>' +
            '<td scope="row">' + item.uf + '</td>'
            if(item.latitude !== undefined){
            html = html +
                '<td scope="row">' + item.sigla_fixa + '</td>' +
                '<td scope="row">' + item.nome + '</td>' +
                '<td scope="row">' + item.endereco + '</td>' +
                '<td scope="row">' + item.bairro + '</td>' +
                '<td scope="row">' + item.municipio + '</td>' +
                '<td scope="row">' + item.cep + '</td>' +
                '<td scope="row">' + item.latitude + '</td>' +
                '<td scope="row">' + item.longitude + '</td>' +
                '<td scope="row">' + item.id_financeiro + '</td>' +
                '<td scope="row">' + item.utilizacao + '</td>' +
                '</tr>'
            } else {
                '<td scope="row" colspan="9">&nbsp;</td>' +
                '</tr>'
            }

        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(details['OES'].length>0){
        html = html +'<h3>OEs Emitidas</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Num OE</th>' +
        '<th scope="col">Tipo OE</th>' +
        '<th scope="col">Elemento</th>' +
        '<th scope="col">Status OE</th>' +
        '<th scope="col">Descrição</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'

        idOEs = [];
        details['OES'].forEach(function(item){
            if(item.numOE>0 && !idOEs.includes(item.numOE)){
                html = html +
                '<tr>' +
                '<td scope="row">' + item.numOE + '</td>' +
                '<td scope="row">' + item.TipoOE + '</td>' +
                '<td scope="row">' + item.id + '</td>' +
                '<td scope="row">' + item.Status + '</td>' +
                '<td scope="row">' + item.Descricao + '</td>' +
                '</tr>'
            }
            idOEs.push(item.numOE);
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(Object.keys(resumes['CIRCUITOS']).length>0){
        html = html + '<h3>Equipamentos</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Rota</th>' +
        '<th scope="col">Site A</th>' +
        '<th scope="col">Roteador A</th>' +
        '<th scope="col">Interface A</th>' +
        '<th scope="col">Camada A</th>' +
        '<th scope="col">Sigla A</th>' +
        '<th scope="col">She/Slo/Por A</th>' +
        '<th scope="col">Site B</th>' +
        '<th scope="col">Roteador B</th>' +
        '<th scope="col">Interface B</th>' +
        '<th scope="col">Camada B</th>' +
        '<th scope="col">Sigla B</th>' +
        '<th scope="col">She/Slo/Por B</th>' +
        '<th scope="col">OE</th>' +
        '<th scope="col">EILD</th>' +
        '<th scope="col">Velocidade</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        Object.keys(resumes['CIRCUITOS']).forEach(function(r){
            resumes['CIRCUITOS'][r].forEach(function(item){
                var num_oe = (item.numOE>0) ? item.numOE : 'Legado';
                var siglaA = (item.siglaA=='') ? '-' : item.siglaA;
                var shelfA = (item.shelfA=='') ? '-' : item.shelfA;
                var slotA = (item.slotA=='') ? '-' : item.slotA;
                var siglaB = (item.siglaB=='') ? '-' : item.siglaB;
                var portaA = (item.portaA=='') ? '-' : item.portaA;
                var shelfB = (item.shelfB=='') ? '-' : item.shelfB;
                var slotB = (item.slotB=='') ? '-' : item.slotB;
                var portaB = (item.portaB=='') ? '-' : item.portaB;
                html = html +
                '<tr>' +
                '<td scope="row">' + item.Rota + '</td>' +
                '<td scope="row">' + item.SiteI + '</td>' +
                '<td scope="row">' + item.EquipamentoI + '</td>' +
                '<td scope="row">' + item.InterfaceI + '</td>' +
                '<td scope="row">' + item.CamadaI + '</td>' +
                '<td scope="row">' + siglaA + '</td>' +
                '<td scope="row">' + shelfA + '/' + slotA + '/' + portaA + '</td>' +
                '<td scope="row">' + item.SiteF + '</td>' +
                '<td scope="row">' + item.EquipamentoF + '</td>' +
                '<td scope="row">' + item.InterfaceF + '</td>' +
                '<td scope="row">' + item.CamadaF + '</td>' +
                '<td scope="row">' + siglaB + '</td>' +
                '<td scope="row">' + shelfB + '/' + slotB + '/' + portaB + '</td>' +
                '<td scope="row">' + num_oe + '</td>' +
                '<td scope="row">' + item.id + '</td>' +
                '<td scope="row">' + item.Velocidade + '</td>'
            })
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(details['PEDS'].length>0){
        html = html + '<h3>PEDs Emitidas</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Num PED</th>' +
        '<th scope="col">Tipo PED</th>' +
        '<th scope="col">Status PED</th>' +
        '<th scope="col">Resp. Técnico</th>' +
        '<th scope="col">Aplicação</th>' +
        '<th scope="col">Referencia</th>' +
        '<th scope="col">Objetivo</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        details['PEDS'].forEach(function(item){
            var aplicacao = (item.APLICACAO) ? item.APLICACAO : '';
            var referencia = (item.REFERENCIA) ? item.REFERENCIA : '';
            var objetivoped = (item.OBJETIVO) ? item.OBJETIVO : '';
            html = html +
            '<tr>' +
            '<td scope="row">' + item.PED + '</td>' +
            '<td scope="row">' + item.LabelRequisitada + '</td>' +
            '<td scope="row">' + item.STATUS_SSI + '</td>' +
            '<td scope="row">' + item.RESPONSAVEL_TECNICO + '</td>' +
            '<td scope="row">' + aplicacao + '</td>' +
            '<td scope="row">' + referencia + '</td>' +
            '<td scope="row">' + objetivoped + '</td>' +
            '</tr>'
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(details['T2S'].length>0){
        html = html + '<h3>T2s Emitidas</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">T2</th>' +
        '<th scope="col">Status T2</th>' +
        '<th scope="col">Contrato</th>' +
        '<th scope="col">Fornecedor</th>' +
        '<th scope="col">Escopo</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        details['T2S'].forEach(function(item){
            html = html +
            '<tr>' +
            '<td scope="row">' + item.T2 + '</td>' +
            '<td scope="row">' + item.Status + '</td>' +
            '<td scope="row">' + item.Contrato + '</td>' +
            '<td scope="row">' + item.FornecedorLabel + '</td>' +
            '<td scope="row">' + item.Escopo + '</td>'
            if(item.Pedidos.length>0){
                PedidosEtp = PedidosEtp.concat(item.Pedidos);
            }
            html = html +
            '</tr>'
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(PedidosEtp.length>0){
        html = html + '<h3>Pedidos Emitidos</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">T2</th>' +
        '<th scope="col">Pedido</th>' +
        '<th scope="col">Data PC</th>' +
        '<th scope="col">Pep</th>' +
        '<th scope="col">Valor Bruto</th>' +
        '<th scope="col">Valor Faturado</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        PedidosEtp.forEach(function(pc){
            html = html +
            '<tr>' +
            '<td scope="row">' + pc.IdT2 + '</td>' +
            '<td scope="row">' + pc.Pedido + '</td>' +
            '<td scope="row">' + pc.DataPc + '</td>' +
            '<td scope="row">' + pc.Pep_Id + '</td>' +
            '<td scope="row">' + 'R$ ' + parseFloat(Math.round(pc.VlrBrutoPedido * 100) / 100).toLocaleString('pt-BR') + '</td>' +
            '<td scope="row">' + 'R$ ' + parseFloat(Math.round(pc.VlrFaturado * 100) / 100).toLocaleString('pt-BR') + '</td>' +
            '</tr>'
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

    if(details['COTACAO'].length>0){
        html = html + '<h3>Cotação</h3>'
        html = html +
        '<table class="table table-sm">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Site</th>' +
        '<th scope="col">T2</th>' +
        '<th scope="col">T2 - Código</th>' +
        '<th scope="col">T2 - Descr. Código</th>' +
        '<th scope="col">Fabricante</th>' +
        '<th scope="col">Qtde</th>' +
        '<th scope="col">Unid</th>' +
        '<th scope="col">Vlr Total</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>'
        details['COTACAO'].forEach(function(item){
            html = html +
            '<tr>' +
            '<td scope="row">' + item.Site + '</td>' +
            '<td scope="row">' + item.IdT2 + '</td>' +
            '<td scope="row">' + item.T2Codigo + '</td>' +
            '<td scope="row">' + item.T2DescricaoCodigo + '</td>' +
            '<td scope="row">' + item.Fabricante + '</td>' +
            '<td scope="row">' + item.Quantidade + '</td>' +
            '<td scope="row">' + item.Unidade + '</td>' +
            '<td scope="row">' + 'R$ ' + parseFloat(Math.round(item.ValorTotalLiqLiq * 100) / 100).toLocaleString('pt-BR') + '</td>' +
            '</tr>'
        });
        html = html +
        '</tbody>' +
        '</table>' +
        lineTag
    }

     //###########################################################################################

    // CREATE A WINDOW OBJECT.
    var win = window.open(etp, etp, 'height=700,width=700');

    win.document.write('<html><head>');
    win.document.write('<title>ETP '+etp+'</title>');   // <title> FOR PDF HEADER.
    win.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">')
    win.document.write('</head>');
    win.document.write('<body>');

    win.document.write('<h1>ETP ' + etp + '</h1>');
    win.document.write(lineTag);

    win.document.write(html);         // THE TABLE CONTENTS INSIDE THE BODY TAG.

    win.document.write('</body></html>');
    win.document.close(); 	// CLOSE THE CURRENT WINDOW.
    win.print();    // PRINT THE CONTENTS.
}