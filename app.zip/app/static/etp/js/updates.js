function OtsUpdateCreate(etp){
    var table = document.getElementById('table-detalhes-ots-'+etp);
    var rows = table.rows.length;

    for (let i=2; i<rows; i++){
        var ots = table.rows[i].cells[0].textContent;
        document.getElementById('slcOts-' + ots + '-' + etp).style.display = 'block';
        if(i==2){
            document.getElementById('checkOts-' + ots + '-' + etp).style.display = 'block';
        }
        document.getElementById('spanOts-' + ots + '-' + etp).style.display = 'none';
        //table.rows[i].cells[3].textContent = '';
     }

    document.getElementById('btGravaOts-' + etp).style.display = 'block';
    document.getElementById('inputOtsEdit-' + etp).style.display = 'none';
}

function saveOtsUpdate(etp){
    var table = document.getElementById('table-detalhes-ots-'+etp);
    var rows = table.rows.length;
    var otssList = '';
    for (let i=2; i<rows; i++){
        var ots = table.rows[i].cells[0].textContent;
        otssList = otssList + document.getElementById('hidOts-' + ots + '-' + etp).value + '|' + document.getElementById('slcOts-' + ots + '-' + etp).value + '#';
    }
    otssList = otssList.slice(0, -1);

    $.ajax({
        url: '/ajax-etp-update-ots',
        type: 'GET',
        data: {
            otss: otssList,
            etp: etp
        },
        //contentType: 'application/json',
        success: function(response){
            for (let i=2; i<rows; i++){
                var ots = table.rows[i].cells[0].textContent;
                document.getElementById('slcOts-' + ots + '-' + etp).style.display = 'none';
                if(i==2){
                    document.getElementById('checkOts-' + ots + '-' + etp).style.display = 'none';
                }
                document.getElementById('spanOts-' + ots + '-' + etp).style.display = 'block';
                document.getElementById('spanOts-' + ots + '-' + etp).textContent = document.getElementById('slcOts-' + ots + '-' + etp).value;
            }
            document.getElementById('btGravaOts-' + etp).style.display = 'none';
            document.getElementById('inputOtsEdit-' + etp).style.display = 'block';
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao atualizar as OTSs!", "error");
        }
    });
}

function replication(etp, cb){
console.log('entrou');
console.log(cb.checked);
    var table = document.getElementById('table-detalhes-ots-'+etp);
    var rows = table.rows.length;

    var proprietario = document.getElementById('slcOts-' + table.rows[2].cells[0].textContent + '-' + etp).value;

    if(cb.checked){
        for (let i=3; i<rows; i++){
            var ots = table.rows[i].cells[0].textContent;
            document.getElementById('slcOts-' + ots + '-' + etp).value = proprietario;
            //table.rows[i].cells[3].textContent = '';
         }
     }
}

