function showInfoTable(display='block'){
    if(display == 'block'){
        document.getElementById('etp-list').style.width = '';
        document.getElementById('tableInfos').style.display = 'none';
        document.getElementById('aTableInfos').text = 'Ver Lista de Etps...';
        document.getElementById('aTableInfos').setAttribute('onclick','showInfoTable(\'none\')');

        document.getElementById('spanTableEtpOnLineExcel').removeChild(document.getElementById('spanTableEtpOnLineExcel').firstElementChild);
    } else {
        document.getElementById('etp-list').style.width = '98%';
        document.getElementById('tableInfos').style.display = 'block';
        document.getElementById('aTableInfos').text = 'Ocultar Lista de Etps...';
        document.getElementById('aTableInfos').setAttribute('onclick','showInfoTable(\'block\')');

        var aTable = document.createElement('a');
        aTable.setAttribute('onclick','createXlsxListEtps()');
        aTable.classList.add('text-success');
        aTable.style = ('cursor:pointer');
        aTable.text = 'Baixar em xlsx...';
        var iTable = document.createElement('i');
        iTable.classList.add('material-icons');
        iTable.append('file_download');
        aTable.appendChild(iTable);
        document.getElementById('spanTableEtpOnLineExcel').appendChild(aTable);
    }
}


function createInfoTables(){
    $.ajax({
        url: '/ajax-list-etps',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            etpsOnLine = response['etpsOnLine'];

            if($.fn.DataTable.isDataTable('#tableListEtps')){
                $('#tableListEtps').dataTable().fnClearTable();
                $('#tableListEtps').dataTable().fnDestroy();
            }

            $.extend( true, $.fn.dataTable.defaults, {
                retrieve: true,
                paging: true,
                info: true
            } );

            $('#tableListEtps').DataTable({
                data: etpsOnLine,
                pagingType: "full_numbers",
                columns: [
                    { title: 'Etp', data: 'etp' },
                    { title: 'Elaborador', data: 'gestor' },
                    { title: 'Status', data: 'status' },
                    { title: 'Título', data: 'titulo' },
                    { title: 'Resp. Técnico', data: 'responsavel' },
                    { title: 'Predecessoras', data: 'predecessoras' },
                    { title: 'Predec. OK?', data: 'predecessoras_ok' },
                    { title: 'Cadastro', data: 'cadastro' },
                    { title: 'Infra', data: 'infra' },
                    { title: 'DCN', data: 'dcn' },
                    { title: 'Rede Externa', data: 'redeexterna' },
                    { title: 'Ped RE', data: 'redeexterna_ped' },
                    { title: 'ETP RE', data: 'redeexterna_etp' },
                    { title: 'Implantação', data: 'implantacao' },
                ],
                scrollY: '350px',
                scrollCollapse: true,
                //scrollX: true,
                language: {
                    //url: "http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
                    search: 'Pesquisar:',
                    zeroRecords: 'Nenhum ETP encontrado...',
                    info: '_TOTAL_ ETPs encontrados (_PAGES_ página(s))',
                    infoFiltered: " (do total de  _MAX_ ETPs)",
                    lengthMenu: 'Mostrar _MENU_',
                    paginate: {
                      first: '',
                      last: '',
                      next: 'Próxima',
                      previous:'Anterior'
                    }
                }
            });
            showInfoTable('block');
        },
        error: function(error){
            console.log(error);
        }
    });

}

