var map_dicts_xlsx = {
    'oes': { 'k': 'details', 'v': 'OES',
     'o': ['numOE', 'id', 'Status', 'Descricao', 'SiteA', 'SiteB', 'TipoElemento', 'TipoOE', 'idsWDMOMS']},

     'oes_predecessoras': { 'k': 'details', 'v': 'adicionais',
     'o': ['numOE', 'id', 'Status', 'Descricao', 'SiteA', 'SiteB', 'TipoElemento', 'TipoOE', 'idsWDMOMS']},

     'ots': { 'k': 'resumes', 'v': 'OTS',
     'o': ['ChaveOTS', 'Sigla', 'PropriedadeFibra', 'NomeRotaNovo']},

    'cotacao': { 'k': 'details', 'v': 'COTACAO',
     'o': ['Site', 'IdT2', 'Fabricante', 'Escopo', 'Quantidade', 'T2DescricaoCodigo',
     'Tipo', 'TipoLabel', 'T2Codigo', 'Unidade', 'ValorTotalLiqLiq', 'Categoria']},

    'peds': { 'k': 'details', 'v': 'PEDS',
     'o': ['ANO', 'PED', 'PED_ASSOCIADA', 'REQUISITANTE', 'SOLICITANTE', 'LabelRequisitada',
     'REQUISITADO', 'RESPONSAVEL_TECNICO', 'LabelStatus', 'PRIORIDADE', 'REFERENCIA', 'OBJETIVO',
     'APLICACAO', 'MOTIVACAO', 'CONCLUSAO', 'DATA_CRIACAO', 'SP_FSP', 'STATUS', 'STATUS_SSI', 'UFS', 'ID_PED']},

    'pedidos': { 'k': 'details', 'v': 'T2S',
     'ot': ['Contrato', 'Fornecedor', 'T2', 'Valor', 'Escopo', 'FornecedorLabel', 'Responsavel', 'Agrupamento',
     'AnoOrcamentario', 'DataCriacao', 'Status'],
     'op': ['Pedido', 'Pep_Id', 'SitePC', 'DataPc', 'VlrBrutoPedido', 'VlrFaturado', 'VlrLiqPedido', 'Bloqueado',
     'DataCriacao', 'Escopo']},

    'sites': { 'k': 'details', 'v': 'SITES',
     'o': ['uf', 'sigla', 'nome', 'endereco', 'bairro', 'municipio', 'cep', 'latitude', 'longitude',
     'id_financeiro', 'origem', 'utilizacao', 'situacao']},

    'equipamentos': { 'k': 'resumes', 'v': 'CIRCUITOS',
     'o': ['numOE', 'id', 'Status', 'Descricao', 'TipoElemento', 'TipoOE', 'Velocidade', 'SiteA', 'SiteB',
     'SiteF', 'SiteI', 'idsWDMOMS', 'portaA', 'portaB', 'shelfA', 'shelfB', 'siglaA', 'siglaB', 'slotA', 'slotB',
     'dgoTxA', 'dgoTxB', 'dgoRxA', 'dgoRxB',
     'CamadaF', 'CamadaI', 'EquipamentoF', 'EquipamentoI', 'InterfaceF', 'InterfaceI', 'L0', 'Rota']},

     'lista-etps': ['etp', 'gestor', 'status', 'titulo', 'responsavel', 'predecessoras', 'predecessoras_ok', 'cadastro',
     'infra', 'dcn', 'redeexterna', 'redeexterna_ped', 'redeexterna_etp', 'implantacao'],

     'infos_etp': { 'k': 'details', 'v': 'data_etps_infos',
     'o': ['etp', 'gestor', 'status', 'titulo']},

     'fibras_info': { 'k': 'resumes', 'v': 'FIBRAS_INFO',
     'o': ['Sigla Fibra', 'Numero da Fibra', 'Sigla do cabo', 'Ponta A (Site+UF)', 'Ponta B (Site+UF)',
     'Proprietário', 'Acordo Swap', 'DGO A', 'DGO B', 'Distancia KM']},
}

function s2ab(s) {
    var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
    var view = new Uint8Array(buf);  //create uint8array as viewer
    for (var i=0; i<s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
    return buf;
}

function createXlsx(etp, tipo){
    var wb = XLSX.utils.book_new();

    var CreatedDateFull = new Date(Date.now());
    var FileName = 'ETP_'+etp+'_'+tipo+'_'+String(CreatedDateFull.getFullYear())+
                                    String(CreatedDateFull.getMonth()).padStart(2, "0")+
                                    String(CreatedDateFull.getDay()).padStart(2, "0")+'.xlsx'
    wb.Props = {
        Title: "Etp-"+etp,
        Subject: "Etp-"+etp+"("+tipo+")",
        Author: "Portal BackboneTX",
        CreatedDate: CreatedDateFull
    };

    wb.SheetNames.push(etp+"("+tipo+")");
    var ws_data = createObjectTable(etp, tipo);
    var ws = XLSX.utils.json_to_sheet(ws_data);
    wb.Sheets[etp+"("+tipo+")"] = ws;

    var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), FileName);
}

function createXlsxListEtps(){
    var wb = XLSX.utils.book_new();

    var CreatedDateFull = new Date(Date.now());
    var FileName = 'EtpsOnLine_'+String(CreatedDateFull.getFullYear())+
                                    String(CreatedDateFull.getMonth()).padStart(2, "0")+
                                    String(CreatedDateFull.getDay()).padStart(2, "0")+'.xlsx'
    wb.Props = {
        Title: "EtpsOnLine",
        Subject: "EtpsOnLine",
        Author: "Portal BackboneTX",
        CreatedDate: CreatedDateFull
    };

    wb.SheetNames.push("EtpsOnLine");
    var ws_data = createObjectTable('lista-etps', 'lista-etps');
    var ws = XLSX.utils.json_to_sheet(ws_data);
    wb.Sheets["EtpsOnLine"] = ws;

    var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), FileName);
}

function createObjectTable(etp, tipo){
    var data;
    var dataTemp = [];
    var dataTipo = (tipo==='lista-etps') ? etpsOnLine : etps_result[etp][map_dicts_xlsx[tipo]['k']][map_dicts_xlsx[tipo]['v']];

    if(tipo === 'oes'){
        dataTipo.forEach(function(item){
            var itemTemp = Object.assign({}, item);
            var itemColumns = {};

            ['EquipamentoF', 'EquipamentoI', 'InterfaceF', 'InterfaceI',
            'L0', 'Rota', 'portaA', 'portaB', 'shelfA', 'shelfB',
            'siglaA', 'siglaB', 'slotA', 'slotB'].forEach(function(field){
                if(itemTemp[field]){
                    delete itemTemp[field];
                }
            });

            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = itemTemp[col];
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo === 'oes_predecessoras'){
        dataTipo = etps_result[etp]['details']['adicionais']['oes_predecessoras'];
        dataTipo.forEach(function(item){
            var itemTemp = Object.assign({}, item);
            var itemColumns = {};

            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = itemTemp[col];
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo === 'ots'){
        dataTipo.forEach(function(item){
            var itemTemp = Object.assign({}, item);
            var itemColumns = {};

            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = itemTemp[col];
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo === 'cotacao'){
        dataTipo.forEach(function(item){
            var itemTemp = Object.assign({}, item);
            var itemColumns = {};

            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = itemTemp[col];
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo === 'peds'){
        dataTipo.forEach(function(item){
            var itemTemp = Object.assign({}, item);
            delete itemTemp['PED_ASSOCIADA_DETALHES'];
            var itemColumns = {};

            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = itemTemp[col];
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo === 'pedidos'){
        dataTipo.forEach(function(item){
            var itemColumns = {};

            map_dicts_xlsx[tipo]['ot'].forEach(function(colt2){
                itemColumns[colt2] = item[colt2];
            })

            if(item['Pedidos'].length>0){
                item['Pedidos'].forEach(function(pc){
                    var itemPedidos = Object.assign({}, itemColumns);

                    map_dicts_xlsx[tipo]['op'].forEach(function(colpc){
                        itemPedidos['PC_'+colpc] = pc[colpc];
                    })

                    dataTemp.push(itemPedidos);
                })
            } else {
                var itemPedidos = Object.assign({}, itemColumns);
                map_dicts_xlsx[tipo]['op'].forEach(function(colpc){
                    itemPedidos['PC_'+colpc] = '';
                })
                dataTemp.push(itemPedidos);
            }
        });
        data = dataTemp;

    } else if(tipo == 'sites'){
        dataTipo.forEach(function(item){
            var itemColumns = {};
            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = (item[col]) ? item[col] : '';
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo == 'infos_etp'){
        dataTipo.forEach(function(item){
            var itemColumns = {};
            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = (item[col]) ? item[col] : '';
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    } else if(tipo == 'equipamentos'){
        Object.keys(dataTipo).forEach(function(k){
            dataTipo[k].forEach(function(item){
                var itemTemp = Object.assign({}, item);
                delete itemTemp['Details'];
                var itemColumns = {};

                map_dicts_xlsx[tipo]['o'].forEach(function(col){
                    itemColumns[col] = itemTemp[col];
                })
                dataTemp.push(itemColumns);
            });
        });
        data = dataTemp;
    } else if(tipo === 'lista-etps'){
        dataTipo.forEach(function(item){
            var itemColumns = {};
            map_dicts_xlsx['lista-etps'].forEach(function(col){
                itemColumns[col] = (item[col]) ? item[col] : '';
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;
    } else if(tipo == 'fibras_info'){
        dataTipo.forEach(function(item){
            var itemColumns = {};
            map_dicts_xlsx[tipo]['o'].forEach(function(col){
                itemColumns[col] = (item[col]) ? item[col] : '';
            })
            dataTemp.push(itemColumns);
        });
        data = dataTemp;

    }

    return data;
}


// TODO: CRIAR TODO O ETP EM XLSX
function createEtpXlsx(etp){
    var wb = XLSX.utils.book_new();

    var CreatedDateFull = new Date(Date.now());
    var FileName = 'ETP_'+etp+'_'+String(CreatedDateFull.getFullYear())+
                                    String(CreatedDateFull.getMonth()).padStart(2, "0")+
                                    String(CreatedDateFull.getDay()).padStart(2, "0")+'.xlsx'
    var ListItemsPadrao = ['OES', 'PEDS', 'COTACAO']

    wb.Props = {
        Title: "Etp-"+etp,
        Subject: "Etp-"+etp,
        Author: "Portal BackboneTX",
        CreatedDate: CreatedDateFull
    };

    ListItemsPadrao.forEach(function(item){
        if(etps_result[etp]["details"][item].length>0){
            wb.SheetNames.push(item);
            var ws_data = etps_result[etp]["details"][item]
            var ws = XLSX.utils.json_to_sheet(ws_data);
            wb.Sheets[item] = ws;
        }
    })

    var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});

    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), FileName);
}

function createXlsxFibra(etp){
    var wb = XLSX.utils.book_new();

    var CreatedDateFull = new Date(Date.now());
    var FileName = 'ETP_'+etp+'_TPL_CM_FIBRA_OPTICA_'+String(CreatedDateFull.getFullYear())+
                                    String(CreatedDateFull.getMonth()).padStart(2, "0")+
                                    String(CreatedDateFull.getDay()).padStart(2, "0")+'.xlsx'
    wb.Props = {
        Title: "Etp-"+etp,
        Subject: "Etp-"+etp+"(TPL_CM_FIBRA_OPTICA)",
        Author: "Portal BackboneTX",
        CreatedDate: CreatedDateFull
    };

    wb.SheetNames.push("TPL_CM_FIBRA_OPTICA_01_OTS");
    var ws_data_ots = createObjectTable(etp, 'fibras_info');
    var ws_ots = XLSX.utils.json_to_sheet(ws_data_ots);
    wb.Sheets["TPL_CM_FIBRA_OPTICA_01_OTS"] = ws_ots;

    /*
    wb.SheetNames.push("TPL_CM_FIBRA_OPTICA_01_EILD");
    var ws_data_eild = [['Sigla Fibra', 'Numero da Fibra', 'Sigla do cabo', 'Ponta A (Site+UF)', 'Ponta B (Site+UF)',
                        'Proprietário', 'Acordo Swap', 'DGO A', 'DGO B', 'Distancia KM']];
    var ws_eild = XLSX.utils.json_to_sheet(ws_data_eild);
    wb.Sheets["TPL_CM_FIBRA_OPTICA_01_EILD"] = ws_eild;
    */

    var wbout = XLSX.write(wb, {bookType:'xlsx',  type: 'binary'});
    saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), FileName);
}