
function newEtpStart(etp='newEtp'){
    $.ajax({
        url: '/ajax-etp-new-start',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            supports = response['supports'];

            var html_modal_new_etp = '' +
            '<form id="form">' +
            '<div class="form-row">' +
            '<div class="form-group col-md-4">' +
            '<label for="TipoNewEtp"><b>Tipo da ETP</b></label>' +
            '<select onchange="verificaTipo(\'TipoNewEtp\')" class="form-control" id="TipoNewEtp">' +
            '<option></option>'
            supports['types'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-6">' +
            '<label for="ElaboradorNewEtp"><b>Elaborador</b></label>'
            if(supports['nameOK']){
                html_modal_new_etp = html_modal_new_etp + '<select class="form-control" id="ElaboradorNewEtp" disabled>';
            } else {
                html_modal_new_etp = html_modal_new_etp + '<select class="form-control" id="ElaboradorNewEtp">';
            }
            html_modal_new_etp = html_modal_new_etp +
            '<option></option>'
            supports['names'].forEach(function(item){
                if(item == supports['nameUser']){
                    html_modal_new_etp = html_modal_new_etp + '<option selected>' + item + '</option>';
                } else {
                    html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
                }
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-2">' +
            '<label for="AnoNewEtp"><b>Ano</b></label>' +
            '<input type="number" class="form-control" value="' + supports['year'] + '" id="AnoNewEtp" min="2021" onKeyDown="return false">' +
            '</div>' +
            '</div>' +
            '<div class="form-row">' +
            '<div class="form-group col-md-6">' +
            '<label for="DemandaNewEtp"><b>Demanda</b></label>' +
            '<select onchange="verificaDemanda(\'DemandaNewEtp\', \'MotivadorNewEtp\')" class="form-control" id="DemandaNewEtp">' +
            '<option></option>'
            supports['demand'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-6">' +
            '<label for="MotivadorNewEtp"><b>Motivador</b></label>' +
            '<select class="form-control" id="MotivadorNewEtp">' +
            '<option></option>' +
            /*
            supports['motivator'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            */
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="form-row">' +
            '<div class="form-group col-md-4">' +
            '<label for="HierarquiaNewEtp"><b>Hierarquia</b></label>' +
            '<select class="form-control" id="HierarquiaNewEtp" multiple>' +
            '<option></option>'
            supports['hierarchy'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-4">' +
            '<label for="PropFibraNewEtp"><b>Prop. da Fibra</b></label>' +
            '<select class="form-control" id="PropFibraNewEtp" multiple>' +
            '<option></option>'
            supports['fiber_owner'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-4">' +
            '<label for="VendorNewEtp"><b>Vendor</b></label>' +
            '<select class="form-control" id="VendorNewEtp" multiple>' +
            '<option></option>'
            supports['vendor'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="form-row">' +
            '<div class="form-group col-md-4">' +
            '<label for="ComplementoTipoNewEtp"><b>Tipo do Complemento</b></label>' +
            '<select onchange="complementoModelo(\'ComplementoTipoNewEtp\', \'ComplementoTextoNewEtp\')" class="form-control" id="ComplementoTipoNewEtp">' +
            '<option></option>' +
            '<option>ID NOVA ROTA</option>' +
            '<option>CLUSTER METRO SPO</option>' +
            '<option>DADOS B2B</option>' +
            '<option>TEXTO LIVRE</option>' +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-8">' +
            '<label for="ComplementoTextoNewEtp"><b>Complemento</b></label>' +
            '<input type="text" maxlength="35" class="form-control" id="ComplementoTextoNewEtp">' +
            '</div>' +
            '</div>' +
            '<div class="form-row">' +
            '<div class="form-group col-md-4">' +
            '<label for="MunANewEtp"><b>Município A</b></label>' +
            '<select class="form-control" id="MunANewEtp">' +
            '<option></option>'
            supports['cnl'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '<div class="form-group col-md-4">' +
            '<label for="MunBNewEtp"><b>Município B</b></label>' +
            '<select class="form-control" id="MunBNewEtp">' +
            '<option></option>'
            supports['cnl'].forEach(function(item){
                html_modal_new_etp = html_modal_new_etp + '<option>' + item + '</option>';
            })
            html_modal_new_etp = html_modal_new_etp +
            '</select>' +
            '</div>' +
            '</div>' +
            '<button class="btn btn-outline-secondary" type="button" id="bt-grava-etpNewEtp" onclick="verifyNewEtpAtributes()">Gravar</button>' +
            '</form>'

            modalEtp = '' +
            '<div id="ModalDetails_' + etp + '" class="modal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-xl" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<h5 class="modal-title">Gerar Nova ETP</h5>' +
            '<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="showModalDetails(\'none\', \'' + etp +  '\')">' +
            '<span aria-hidden="true">&times;</span>' +
            '</button>' +
            '</div>' +
            '<div class="modal-body">' +
            html_modal_new_etp +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'

            modalDetailsEtps.innerHTML = modalEtp;
            showModalDetails('block', etp);
        },
        error: function(error){
            console.log(error);
            swal("Erro!", "Um erro ocorreu ao iniciar a criação de um novo ETP", "error");
        }
    });
}

function verifyNewEtpAtributes(){
    var saveEtp = true;
    var newEtp = {
        TipoNewEtp: String(document.getElementById('TipoNewEtp').value),
        ElaboradorNewEtp: String(document.getElementById('ElaboradorNewEtp').value),
        AnoNewEtp: document.getElementById('AnoNewEtp').value,
        DemandaNewEtp: String(document.getElementById('DemandaNewEtp').value),
        MotivadorNewEtp: String(document.getElementById('MotivadorNewEtp').value),

        HierarquiaNewEtp: Array.prototype.map.call(document.getElementById('HierarquiaNewEtp').selectedOptions, function(x){ return x.value }),
        PropFibraNewEtp: Array.prototype.map.call(document.getElementById('PropFibraNewEtp').selectedOptions, function(x){ return x.value }),
        VendorNewEtp: Array.prototype.map.call(document.getElementById('VendorNewEtp').selectedOptions, function(x){ return x.value }),

        MunANewEtp: String(document.getElementById('MunANewEtp').value)
    };

    Object.keys(newEtp).forEach(function(item){
        e = ['HierarquiaNewEtp', 'PropFibraNewEtp']
        if(newEtp['TipoNewEtp'] === 'Demanda' && Boolean(e.find( i => i === item))){

        } else {
            if(newEtp[item] == '' || newEtp[item].length == 0){
                saveEtp = false;
                document.getElementById(item).classList.remove('is-valid');
                document.getElementById(item).classList.add('is-invalid');
            } else {
                document.getElementById(item).classList.remove('is-invalid');
                document.getElementById(item).classList.add('is-valid');
            }
        }
    })

    if(saveEtp){
        newEtp['MunBNewEtp'] = String(document.getElementById('MunBNewEtp').value);
        newEtp['ComplementoTipoNewEtp'] = String(document.getElementById('ComplementoTipoNewEtp').value);
        newEtp['ComplementoTextoNewEtp'] = String(document.getElementById('ComplementoTextoNewEtp').value);

        swal("", "A ETP será cadastrada e um novo número será gerado!!! \n\n Confira todas as informações antes de enviar...", "warning",
        {buttons: {
            cancel: "Cancelar",
            roll: {
                text: 'Continuar',
                type: 'success'
            }
        }
        }
        ).then(function(e) {
            if(e){ saveNewEtpAtributes(newEtp); }
            });
    }
}

function saveNewEtpAtributes(newEtp){
    function showNewEtpAtr(etp){
        if(document.getElementById('collapseZero_'+etp)){
            showModalDetails('block', etp);
            document.getElementById('collapseZero_'+etp).classList.add('show');
        } else {
            setTimeout(() => { showNewEtpAtr(etp); }, 2000);
        }
    }

    $.ajax({
        url: '/ajax-etp-new',
        type: 'POST',
        data: {
            TipoNewEtp: newEtp['TipoNewEtp'],
            ElaboradorNewEtp: newEtp['ElaboradorNewEtp'],
            DemandaNewEtp: newEtp['DemandaNewEtp'],
            MotivadorNewEtp: newEtp['MotivadorNewEtp'],

            HierarquiaNewEtp: newEtp['HierarquiaNewEtp'].join('_'),
            PropFibraNewEtp: newEtp['PropFibraNewEtp'].join('_'),
            VendorNewEtp: newEtp['VendorNewEtp'].join('_'),

            AnoNewEtp: newEtp['AnoNewEtp'],
            MunANewEtp: newEtp['MunANewEtp'],
            MunBNewEtp: newEtp['MunBNewEtp'],
            ComplementoTipoNewEtp: newEtp['ComplementoTipoNewEtp'],
            ComplementoTextoNewEtp: newEtp['ComplementoTextoNewEtp']
        },
        //contentType: 'application/json',
        success: function(response){
            etp = response['etp']

            //modalDetailsEtps.innerHTML = '';
            showModalDetails('block', 'newEtp');
            modalDetailsEtps.innerHTML = '';

            document.getElementById('etp-text').value = ""
            document.getElementById('etp-text').value = etp;
            document.getElementById('bt-busca-etp').click();

            createInfoTables();

            showNewEtpAtr(etp);
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao gravar a nova ETP!", "error");
        }
    });
}

function complementoModelo(fieldList, fieldTxt){
    value = document.getElementById(fieldList).value;

    if(value == 'ID NOVA ROTA'){
        model = 'ID_202X-XXX'
    } else if (value == 'CLUSTER METRO SPO'){
        model = 'CXX-AXX-SXX'
    } else if (value == 'DADOS B2B'){
        model = 'XXXX/XX-CLIENTE-SER-XXXXXXX'
    } else {
        model = ''
    }

    document.getElementById(fieldTxt).value = model;
}

function verificaTipo(fieldList){
    value = document.getElementById(fieldList).value;
    var disabledField = false;
    var visibilityField = 'visible';

    if(value === 'Demanda'){
        disabledField = true;
        visibilityField = 'hidden';
    }

    document.getElementById('HierarquiaNewEtp').value = null;
    document.getElementById('HierarquiaNewEtp').disabled = disabledField;
    document.getElementById('HierarquiaNewEtp').style.visibility = visibilityField;
    document.getElementById('PropFibraNewEtp').value = null;
    document.getElementById('PropFibraNewEtp').disabled = disabledField;
    document.getElementById('PropFibraNewEtp').style.visibility = visibilityField;
}

function verificaDemanda(fieldIn, fieldOut){
    value = document.getElementById(fieldIn).value;
    create = document.getElementById(fieldOut);

    var length = create.options.length;
    for (i = length-1; i >= 0; i--) {
      if(create.options[i].value !== ''){
        create.options[i] = null;
      }
    }

    if(value !== ''){
        supports['dxm'][value].forEach(function(item){
            var option = document.createElement("option");
            option.text = item;
            create.add(option);
        })
    }
}