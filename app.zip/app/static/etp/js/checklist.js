function createModalChecklist(checklist, etp, validation){
    var optionList = ['OK', 'NOK', 'N/A'];
    var optionMean = checklist.filter(function(obj){return obj.k !== 'ped_demanda' && obj.k !== 'topologia' && obj.k !== 'eild_legado' && obj.k !== 'site_science' && obj.k !== 'ots_desativa'
                                                             && obj.k !== 'comissiona_gbe'  && obj.k !== 'descomissiona_gbe'  && obj.k !== 'comissiona_portadora'  && obj.k !== 'descomissiona_portadora'});
    var optionTopologia = checklist.filter(function(obj){return obj.k == 'topologia'});
    var optionPedDemanda = checklist.filter(function(obj){return obj.k == 'ped_demanda'})[0];
    var pedDemandaValue = checklist.filter(function(obj){return obj.k == 'ped_demanda'})[0]['v'];
    var optionEildLegado = checklist.filter(function(obj){return obj.k == 'eild_legado'})[0];
    var EildLegadoValue = checklist.filter(function(obj){return obj.k == 'eild_legado'})[0]['v'];
    var optionSiteScience = checklist.filter(function(obj){return obj.k == 'site_science'})[0];
    var SiteScienceValue = checklist.filter(function(obj){return obj.k == 'site_science'})[0]['v'];
    var optionOtsDesativa = checklist.filter(function(obj){return obj.k == 'ots_desativa'})[0];
    var OtsDesativaValue = checklist.filter(function(obj){return obj.k == 'ots_desativa'})[0]['v'];

    var optionComissionaGbe = checklist.filter(function(obj){return obj.k == 'comissiona_gbe'})[0];
    var ComissionaGbeValue = checklist.filter(function(obj){return obj.k == 'comissiona_gbe'})[0]['v'];
    var optionDescomissionaGbe = checklist.filter(function(obj){return obj.k == 'descomissiona_gbe'})[0];
    var DescomissionaGbeValue = checklist.filter(function(obj){return obj.k == 'descomissiona_gbe'})[0]['v'];
    var optionComissionaPortadora = checklist.filter(function(obj){return obj.k == 'comissiona_portadora'})[0];
    var ComissionaPortadoraValue = checklist.filter(function(obj){return obj.k == 'comissiona_portadora'})[0]['v'];
    var optionDescomissionaPortadora = checklist.filter(function(obj){return obj.k == 'descomissiona_portadora'})[0];
    var DescomissionaPortadoraValue = checklist.filter(function(obj){return obj.k == 'descomissiona_portadora'})[0]['v'];

    html = ''
    if(validation && !['Concluída', 'Cancelada'].includes(etps_result[etp]["details"]["ATRIBUTOS"]["status"])){
    html = html + '<i id="inputEtpEdit-' + etp +'" class="material-icons" style="cursor:pointer" onclick="disableEtpChecklist(\'' + etp +  '\', \'' + pedDemandaValue.join('_') +  '\', \'' + EildLegadoValue.join('_') +  '\', \'' + SiteScienceValue.join('_') +  '\', \'' + OtsDesativaValue.join('_') +  '\', false, \'block\', \'none\')">edit_note</i>'
    }
    html = html +
    '<form id="formGravaChecklist-' + etp +'">' +
    '<div class="form-row">'

    optionMean.forEach(function(item){
        html = html +
        '<div class="form-group col-md-3">' +
        '<label for="' + item['k'] + '-' + etp +'">' + item['l'] + '</label>' +
        '<big id="' + item['k'] + 'Txt-' + etp +'" class="form-text text-muted">' + item['v'] + '</big>' +
        '<select style="display: none" class="form-control" disabled id="' + item['k'] + '-' + etp +'">'
        optionList.forEach(function(op){
          option = (item['v'] === op) ? '<option selected>'+op+'</option>' : '<option>'+op+'</option>';
          html = html + option;
        })
        html = html +
        '</select>' +
        '</div>'
    })

    html = html +
    '</div>' +

    // TOPOLOGIA + PED DEMANDA
   '<div class="form-row">'
    optionTopologia.forEach(function(item){
        html = html +
        '<div class="form-group col-md-3">' +
        '<label for="' + item['k'] + '-' + etp +'">' + item['l'] + '</label>' +
        '<big id="' + item['k'] + 'Txt-' + etp +'" class="form-text text-muted">' + item['v'] + '</big>' +
        '<select style="display: none" class="form-control" disabled id="' + item['k'] + '-' + etp +'">'
        optionList.forEach(function(op){
          option = (item['v'] === op) ? '<option selected>'+op+'</option>' : '<option>'+op+'</option>';
          html = html + option;
        })
        html = html +
        '</select>' +
        '</div>'
    })

    html = html +
    '<div class="form-group col-md-3">' +
    '<label for="' + optionPedDemanda['k'] + '-' + etp +'">SSI PED Demanda</label>' +
    '<br>' +
    '<div id="' + optionPedDemanda['k'] + 'DivList-' + etp +'">'
    pedDemandaValue.forEach(function(item){
        html = html +
        '<span>' +
        '<button id="' + optionPedDemanda['k'] + 'Txt-' + item + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infosPedDemanda(item) + '">' + item + '</button>' +
        '<a id="' + optionPedDemanda['k'] + 'Del-' + item + '-' + etp +'" class="text-danger" style="cursor:pointer; display: none;" onclick="deletePedDemanda(\'' + optionPedDemanda['k'] +  '\', \'' + item +  '\', \'' + etp +  '\')">x</a>' +
        '</span>' +
        '<br id="' + optionPedDemanda['k'] + 'Br-' + item + '-' + etp +'">'
    })
    html = html +
    '</div>' +
    '<input type="hidden" id="' + optionPedDemanda['k'] + '-' + etp +'" value="' + pedDemandaValue.join('_') + '">' +
    '</div>' +
    '<div style="display: none" id="' + optionPedDemanda['k'] + 'Div-' + etp + '" class="form-group col-md-3">' +
    '<label for="' + optionPedDemanda['k'] + 'Input-' + etp +'">Buscar Ped Demanda</label>' +
    '<input type="text" class="form-control" id="' + optionPedDemanda['k'] + 'Input-' + etp +'">' +
    '<button id="' + optionPedDemanda['k'] + 'Button-' + etp +'" class="btn btn-sm" type="button" onclick="searchPedDemanda(\'' + optionPedDemanda['k'] +  '\', \'' + etp +  '\')"><i class="material-icons">search</i></button>' +
    '</div>' +
    '</div>'

    var visibilityEildLegado = (etp.substring(0, 4) === '0040') ? 'none' : '';
    //EILD LEGADO
    html = html +
    '<div class="form-row" style="display: '+visibilityEildLegado+'">' +
    '<div class="form-group col-md-3">' +
    '<label for="' + optionEildLegado['k'] + 'Ignorar-' + etp +'"></label>' +
    '<big id="' + optionEildLegado['k'] + 'Ignorar-' + etp +'" class="form-text text-muted"></big>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionEildLegado['k'] + '-' + etp +'">EILD Legado</label>' +
    '<br>' +
    '<div id="' + optionEildLegado['k'] + 'DivList-' + etp +'">'
    EildLegadoValue.forEach(function(item){
        html = html +
        '<span>' +
        '<button id="' + optionEildLegado['k'] + 'Txt-' + item + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infosEildLegado(item) + '">' + item + '</button>' +
        '<a id="' + optionEildLegado['k'] + 'Del-' + item + '-' + etp +'" class="text-danger" style="cursor:pointer; display: none;" onclick="deleteEildLegado(\'' + optionEildLegado['k'] +  '\', \'' + item +  '\', \'' + etp +  '\')">x</a>' +
        '</span>' +
        '<br id="' + optionEildLegado['k'] + 'Br-' + item + '-' + etp +'">'
    })
    html = html +
    '</div>' +
    '<input type="hidden" id="' + optionEildLegado['k'] + '-' + etp +'" value="' + EildLegadoValue.join('_') + '">' +
    '</div>' +
    '<div style="display: none" id="' + optionEildLegado['k'] + 'Div-' + etp + '" class="form-group col-md-3">' +
    '<label for="' + optionEildLegado['k'] + 'Input-' + etp +'">Buscar EILD Legado</label>' +
    '<input type="text" class="form-control" id="' + optionEildLegado['k'] + 'Input-' + etp +'">' +
    '<button id="' + optionEildLegado['k'] + 'Button-' + etp +'" class="btn btn-sm" type="button" onclick="searchEildLegado(\'' + optionEildLegado['k'] +  '\', \'' + etp +  '\')"><i class="material-icons">search</i></button>' +
    '</div>' +
    '</div>'

    //SITE SCIENCE
    html = html +
    '<div class="form-row">' +
    '<div class="form-group col-md-3">' +
    '<label for="' + optionSiteScience['k'] + 'Ignorar-' + etp +'"></label>' +
    '<big id="' + optionSiteScience['k'] + 'Ignorar-' + etp +'" class="form-text text-muted"></big>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionSiteScience['k'] + '-' + etp +'">Sites Adicionais</label>' +
    '<br>' +
    '<div id="' + optionSiteScience['k'] + 'DivList-' + etp +'">'
    SiteScienceValue.forEach(function(item){
        html = html +
        '<span>' +
        '<button id="' + optionSiteScience['k'] + 'Txt-' + item + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infosSiteScience(item) + '">' + item + '</button>' +
        '<a id="' + optionSiteScience['k'] + 'Del-' + item + '-' + etp +'" class="text-danger" style="cursor:pointer; display: none;" onclick="deleteSiteScience(\'' + optionSiteScience['k'] +  '\', \'' + item +  '\', \'' + etp +  '\')">x</a>' +
        '</span>' +
        '<br id="' + optionSiteScience['k'] + 'Br-' + item + '-' + etp +'">'
    })
    html = html +
    '</div>' +
    '<input type="hidden" id="' + optionSiteScience['k'] + '-' + etp +'" value="' + SiteScienceValue.join('_') + '">' +
    '</div>' +
    '<div style="display: none" id="' + optionSiteScience['k'] + 'Div-' + etp + '" class="form-group col-md-3">' +
    '<label for="' + optionSiteScience['k'] + 'Input-' + etp +'">Buscar Site Science</label>' +
    '<input type="text" class="form-control" id="' + optionSiteScience['k'] + 'Input-' + etp +'">' +
    '<button id="' + optionSiteScience['k'] + 'Button-' + etp +'" class="btn btn-sm" type="button" onclick="searchSiteScience(\'' + optionSiteScience['k'] +  '\', \'' + etp +  '\')"><i class="material-icons">search</i></button>' +
    '</div>' +
    '</div>'

    //OTS DESATIVA
    html = html +
    '<div class="form-row">' +
    '<div class="form-group col-md-3">' +
    '<label for="' + optionOtsDesativa['k'] + 'Ignorar-' + etp +'"></label>' +
    '<big id="' + optionOtsDesativa['k'] + 'Ignorar-' + etp +'" class="form-text text-muted"></big>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionOtsDesativa['k'] + '-' + etp +'">OTS(s) a desativar</label>' +
    '<br>' +
    '<div id="' + optionOtsDesativa['k'] + 'DivList-' + etp +'">'
    OtsDesativaValue.forEach(function(item){
        html = html +
        '<span>' +
        '<span  id="' + optionOtsDesativa['k'] + 'Txt-' + item + '-' + etp +'">' + item + '</span>' +
        //'<button id="' + optionOtsDesativa['k'] + 'Txt-' + item + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infosSiteScience(item) + '">' + item + '</button>' +
        '<a id="' + optionOtsDesativa['k'] + 'Del-' + item + '-' + etp +'" class="text-danger" style="cursor:pointer; display: none;" onclick="deleteOtsDesativar(\'' + optionOtsDesativa['k'] +  '\', \'' + item +  '\', \'' + etp +  '\')">x</a>' +
        '</span>' +
        '<br id="' + optionOtsDesativa['k'] + 'Br-' + item + '-' + etp +'">'
    })
    html = html +
    '</div>' +
    '<input type="hidden" id="' + optionOtsDesativa['k'] + '-' + etp +'" value="' + OtsDesativaValue.join('_') + '">' +
    '</div>' +
    '<div style="display: none" id="' + optionOtsDesativa['k'] + 'Div-' + etp + '" class="form-group col-md-3">' +
    '<label for="' + optionOtsDesativa['k'] + 'Input-' + etp +'">Buscar OTS</label>' +
    '<input type="text" class="form-control" id="' + optionOtsDesativa['k'] + 'Input-' + etp +'">' +
    '<button id="' + optionOtsDesativa['k'] + 'Button-' + etp +'" class="btn btn-sm" type="button" onclick="searchOtsDesativar(\'' + optionOtsDesativa['k'] +  '\', \'' + etp +  '\')"><i class="material-icons">search</i></button>' +
    '</div>' +
    '</div>'

    //Comissionamento / Descomissionamento - GBE / Portadora
    html = html +
    '<div class="form-row">' +
    '<div class="form-group col-md-3">' +
    '<label for="' + optionComissionaGbe['k'] + '-' + etp +'">Comissionar GBE</label>' +
    '<textarea class="form-control" id="' + optionComissionaGbe['k'] + 'TxtArea-' + etp +'" rows="3" readonly>'
    ComissionaGbeValue.forEach(function(item){
        html = html + item + '&#10;';
    })
    html = html +
    '</textarea>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionDescomissionaGbe['k'] + '-' + etp +'">Descomissionar GBE</label>' +
    '<textarea class="form-control" id="' + optionDescomissionaGbe['k'] + 'TxtArea-' + etp +'" rows="3" readonly>'
    DescomissionaGbeValue.forEach(function(item){
        html = html + item + '&#10;';
    })
    html = html +
    '</textarea>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionComissionaPortadora['k'] + '-' + etp +'">Comissionar Portadora</label>' +
    '<textarea class="form-control" id="' + optionComissionaPortadora['k'] + 'TxtArea-' + etp +'" rows="3" readonly>'
    ComissionaPortadoraValue.forEach(function(item){
        html = html + item + '&#10;';
    })
    html = html +
    '</textarea>' +
    '</div>' +

    '<div class="form-group col-md-3">' +
    '<label for="' + optionDescomissionaPortadora['k'] + '-' + etp +'">Descomissionar Portadora</label>' +
    '<textarea class="form-control" id="' + optionDescomissionaPortadora['k'] + 'TxtArea-' + etp +'" rows="3" readonly>'
    DescomissionaPortadoraValue.forEach(function(item){
        html = html + item + '&#10;';
    })
    html = html +
    '</textarea>' +
    '</div>' +

    '</div>' +

    '<button style="display: none" class="btn btn-outline-secondary" type="button" id="bt-grava-checklist-' + etp +'" onclick="saveEtpChecklist(\'' + etp +  '\')">Gravar</button>' +
    '</form>'

    return html;
}

function disableEtpChecklist(etp, pedDemanda, eildLegado, siteScience, otsDesativa, boolDisabled, displayInput, displayTxt){
    var fields = ['cadastro', 'ped_infra', 'ped_re', 'ped_dcn', 'topologia']
    var fieldsGbePortadora = ['comissiona_gbe', 'descomissiona_gbe', 'comissiona_portadora', 'descomissiona_portadora']

    fields.forEach(function(item){
        document.getElementById(item+'-'+etp).disabled = boolDisabled;
        document.getElementById(item+'-'+etp).style.display = displayInput;
        document.getElementById(item+'Txt-'+etp).style.display = displayTxt;
    })

    fieldsGbePortadora.forEach(function(item){
        document.getElementById(item+'TxtArea-'+etp).readOnly = false;
    })

    pedDemanda.split('_').filter(item => item).forEach(function(item){
        document.getElementById('ped_demandaDel-'+item+'-'+etp).style.display = displayInput;
    })
    document.getElementById('ped_demandaDiv-'+etp).style.display = displayInput;

    eildLegado.split('_').filter(item => item).forEach(function(item){
        document.getElementById('eild_legadoDel-'+item+'-'+etp).style.display = displayInput;
    })
    document.getElementById('eild_legadoDiv-'+etp).style.display = displayInput;

    siteScience.split('_').filter(item => item).forEach(function(item){
        document.getElementById('site_scienceDel-'+item+'-'+etp).style.display = displayInput;
    })
    document.getElementById('site_scienceDiv-'+etp).style.display = displayInput;

    otsDesativa.split('_').filter(item => item).forEach(function(item){
        document.getElementById('ots_desativaDel-'+item+'-'+etp).style.display = displayInput;
    })
    document.getElementById('ots_desativaDiv-'+etp).style.display = displayInput;

    document.getElementById('bt-grava-checklist-'+etp).style.display = displayInput;
}

function saveEtpChecklist(etp){
    $.ajax({
        url: '/ajax-etp-checklist',
        type: 'GET',
        data: {
            etp: etp,
            cadastro: String(document.getElementById('cadastro-'+etp).value),
            ped_infra: String(document.getElementById('ped_infra-'+etp).value),
            ped_re: String(document.getElementById('ped_re-'+etp).value),
            ped_dcn: String(document.getElementById('ped_dcn-'+etp).value),
            ped_demanda: String(document.getElementById('ped_demanda-'+etp).value),
            topologia: String(document.getElementById('topologia-'+etp).value),
            eild_legado: String(document.getElementById('eild_legado-'+etp).value),
            site_science: String(document.getElementById('site_science-'+etp).value),
            ots_desativa: String(document.getElementById('ots_desativa-'+etp).value),
            comissiona_gbe: String(document.getElementById('comissiona_gbeTxtArea-'+etp).value),
            descomissiona_gbe: String(document.getElementById('descomissiona_gbeTxtArea-'+etp).value),
            comissiona_portadora: String(document.getElementById('comissiona_portadoraTxtArea-'+etp).value),
            descomissiona_portadora: String(document.getElementById('descomissiona_portadoraTxtArea-'+etp).value),
        },
        contentType: 'application/json',
        success: function(response){
            html_modal_checklist = createModalChecklist(response['checklist'], etp, true);
            document.getElementById('modal-detalhes-checklist_' + etp).innerHTML = html_modal_checklist;
            swal("Sucesso!", "Checklist atualizado!", "success");
        },
        error: function(error){
            console.log(error);
            swal("Erro!", "Um erro ocorreu. O Checklist não foi atualizado!", "error");
        }
    });
}

function searchPedDemanda(tipo, etp){
    $.ajax({
        url: '/ajax-ped-demanda',
        type: 'GET',
        data: {
            ped: document.getElementById(tipo + 'Input-' + etp).value
        },
        contentType: 'application/json',
        success: function(response){
            ped = response['ped_demanda']

            if(ped.length>0){
                var infos_ped_demanda = '' +
                'Ped: '+ ped[0]['NUMERO_SSI_PED'] + ' \n' +
                'Solicitante: '+ ped[0]['SIGLA_AREA_SOLICITANTE'] + ' \n' +
                'Requisitada: '+ ped[0]['SIGLA_AREA_REQUISITADA'] + ' \n' +
                'Status: '+ ped[0]['DESC_STATUS'] + ' \n' +
                'Título: '+ ped[0]['TITULO_SSI'] + ' \n' +
                'Aplicação: '+ ped[0]['APLICACAO'] + ' \n' +
                'Motivação: '+ ped[0]['MOTIVACAO'] + ' \n' +
                'SP FSP: '+ ped[0]['SP_FSP'] + ' \n' +
                'UF(s): '+ ped[0]['UFs']

                html_ped = '' +
                '<button id="' + tipo + 'Txt-' + ped[0]['NUMERO_SSI_PED'] + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infos_ped_demanda + '">' + ped[0]['NUMERO_SSI_PED'] + '</button>' +
                '<a id="' + tipo + 'Del-' + ped[0]['NUMERO_SSI_PED'] + '-' + etp +'" class="text-danger" style="cursor:pointer" onclick="deletePedDemanda(\'' + tipo +  '\', \'' + ped[0]['NUMERO_SSI_PED'] +  '\', \'' + etp +  '\')">x</a>' +
                '<br id="' + tipo + 'Br-' + ped[0]['NUMERO_SSI_PED'] + '-' + etp +'">'
                document.getElementById(tipo + 'DivList-' + etp).innerHTML = document.getElementById(tipo + 'DivList-' + etp).innerHTML+html_ped;
                document.getElementById(tipo + 'Input-' + etp).value = '';
                document.getElementById(tipo + '-' + etp).value = (document.getElementById(tipo + '-' + etp).value === '') ? ped[0]['NUMERO_SSI_PED'] : document.getElementById(tipo + '-' + etp).value+'_'+ped[0]['NUMERO_SSI_PED'];

                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-invalid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-valid');
            } else {
                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-valid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-invalid');
            }
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao buscar a Ped de Demanda!", "error");
        }
    });
}

function infosPedDemanda(ped){
    var infos;
    infos = '';
    $.ajax({
        url: '/ajax-ped-demanda',
        type: 'GET',
        async: false,
        data: {
            ped: String(ped)
        },
        contentType: 'application/json',
        success: function(response){
            ped = response['ped_demanda']

            if(ped.length>0){
                infos =  infos +
                'Ped: '+ ped[0]['NUMERO_SSI_PED'] + ' \n' +
                'Solicitante: '+ ped[0]['SIGLA_AREA_SOLICITANTE'] + ' \n' +
                'Requisitada: '+ ped[0]['SIGLA_AREA_REQUISITADA'] + ' \n' +
                'Status: '+ ped[0]['DESC_STATUS'] + ' \n' +
                'Título: '+ ped[0]['TITULO_SSI'] + ' \n' +
                'Aplicação: '+ ped[0]['APLICACAO'] + ' \n' +
                'Motivação: '+ ped[0]['MOTIVACAO'] + ' \n' +
                'SP FSP: '+ ped[0]['SP_FSP'] + ' \n' +
                'UF(s): '+ ped[0]['UFs']
            }
        },
        error: function(error){
            console.log(error);
        }
    });
    return infos;
}

function deletePedDemanda(tipo, ped, etp){
    listPeds = document.getElementById(tipo + '-' + etp).value.split('_');

    document.getElementById(tipo + '-' + etp).value = listPeds.filter(function(value, index, arr){
        return value !== ped;
    }).join('_');

    document.getElementById(tipo + 'Txt-' + ped + '-' + etp).remove();
    document.getElementById(tipo + 'Del-' + ped + '-' + etp).remove();
    document.getElementById(tipo + 'Br-' + ped + '-' + etp).remove()
}

function searchSiteScience(tipo, etp){
    $.ajax({
        url: '/ajax-site-science',
        type: 'GET',
        data: {
            site: document.getElementById(tipo + 'Input-' + etp).value
        },
        contentType: 'application/json',
        success: function(response){
            site = response['site']

            if(site.length>0){
                var infos_site_science = '' +
                'Sigla: '+ site[0]['sigla'] + ' \n' +
                'UF: '+ site[0]['uf'] + ' \n' +
                'Nome: '+ site[0]['nome'] + ' \n' +
                'Id Financeiro: '+ site[0]['id_financeiro'] + ' \n' +
                'Municipio: '+ site[0]['municipio'] + ' \n' +
                'Bairro: '+ site[0]['bairro'] + ' \n' +
                'Endereço: '+ site[0]['endereco'] + ' \n' +
                'CEP: '+ site[0]['cep'] + ' \n' +
                'Utilização: '+ site[0]['utilizacao'] + ' \n' +
                'Latitude: '+ site[0]['latitude'] + ' \n' +
                'Longitude: '+ site[0]['longitude']

                html_site = '' +
                '<button id="' + tipo + 'Txt-' + site[0]['sigla']+'.'+site[0]['uf'] + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infos_site_science + '">' + site[0]['sigla']+'.'+site[0]['uf'] + '</button>' +
                '<a id="' + tipo + 'Del-' + site[0]['sigla']+'.'+site[0]['uf'] + '-' + etp +'" class="text-danger" style="cursor:pointer" onclick="deleteSiteScience(\'' + tipo +  '\', \'' + site[0]['sigla']+'.'+site[0]['uf'] +  '\', \'' + etp +  '\')">x</a>' +
                '<br id="' + tipo + 'Br-' + site[0]['sigla']+'.'+site[0]['uf'] + '-' + etp +'">'
                document.getElementById(tipo + 'DivList-' + etp).innerHTML = document.getElementById(tipo + 'DivList-' + etp).innerHTML+html_site;
                document.getElementById(tipo + 'Input-' + etp).value = '';
                document.getElementById(tipo + '-' + etp).value = (document.getElementById(tipo + '-' + etp).value === '') ? site[0]['sigla']+'.'+site[0]['uf'] : document.getElementById(tipo + '-' + etp).value+'_'+site[0]['sigla']+'.'+site[0]['uf'];

                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-invalid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-valid');
            } else {
                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-valid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-invalid');
            }
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao buscar o site Science!", "error");
        }
    });
}

function infosSiteScience(site){
    var infos;
    infos = '';
    $.ajax({
        url: '/ajax-site-science',
        type: 'GET',
        async: false,
        data: {
            site: String(site)
        },
        contentType: 'application/json',
        success: function(response){
            site = response['site']

            if(site.length>0){
                infos =  infos +
                'Sigla: '+ site[0]['sigla'] + ' \n' +
                'UF: '+ site[0]['uf'] + ' \n' +
                'Nome: '+ site[0]['nome'] + ' \n' +
                'Id Financeiro: '+ site[0]['id_financeiro'] + ' \n' +
                'Municipio: '+ site[0]['municipio'] + ' \n' +
                'Bairro: '+ site[0]['bairro'] + ' \n' +
                'Endereço: '+ site[0]['endereco'] + ' \n' +
                'CEP: '+ site[0]['cep'] + ' \n' +
                'Utilização: '+ site[0]['utilizacao'] + ' \n' +
                'Latitude: '+ site[0]['latitude'] + ' \n' +
                'Longitude: '+ site[0]['longitude']
            }
        },
        error: function(error){
            console.log(error);
        }
    });
    return infos;
}

function deleteSiteScience(tipo, site, etp){
    listSites = document.getElementById(tipo + '-' + etp).value.split('_');

    document.getElementById(tipo + '-' + etp).value = listSites.filter(function(value, index, arr){
        return value !== site;
    }).join('_');

    document.getElementById(tipo + 'Txt-' + site + '-' + etp).remove();
    document.getElementById(tipo + 'Del-' + site + '-' + etp).remove();
    document.getElementById(tipo + 'Br-' + site + '-' + etp).remove()
}

function searchOtsDesativar(tipo, etp){
    $.ajax({
        url: '/ajax-ots-desativar',
        type: 'GET',
        data: {
            ots: document.getElementById(tipo + 'Input-' + etp).value
        },
        contentType: 'application/json',
        success: function(response){
            ots_sigla = response['ots_sigla']

            if(ots_sigla.length>0){
                html_site = '' +
                '<span id="' + tipo + 'Txt-' + ots_sigla[0]['ChaveOTS'] + '-' + etp +'" >' + ots_sigla[0]['ChaveOTS'] + '</span>' +
                //'<button id="' + tipo + 'Txt-' + site[0]['sigla']+'.'+site[0]['uf'] + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infos_site_science + '">' + site[0]['sigla']+'.'+site[0]['uf'] + '</button>' +
                '<a id="' + tipo + 'Del-' + ots_sigla[0]['ChaveOTS'] + '-' + etp +'" class="text-danger" style="cursor:pointer" onclick="deleteOtsDesativar(\'' + tipo +  '\', \'' + ots_sigla[0]['ChaveOTS'] +  '\', \'' + etp +  '\')">x</a>' +
                '<br id="' + tipo + 'Br-' + ots_sigla[0]['ChaveOTS'] + '-' + etp +'">'
                document.getElementById(tipo + 'DivList-' + etp).innerHTML = document.getElementById(tipo + 'DivList-' + etp).innerHTML+html_site;
                document.getElementById(tipo + 'Input-' + etp).value = '';
                document.getElementById(tipo + '-' + etp).value = (document.getElementById(tipo + '-' + etp).value === '') ? ots_sigla[0]['ChaveOTS'] : document.getElementById(tipo + '-' + etp).value+'_'+ots_sigla[0]['ChaveOTS'];

                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-invalid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-valid');
            } else {
                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-valid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-invalid');
            }
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao buscar a OTS!", "error");
        }
    });
}

function deleteOtsDesativar(tipo, ots, etp){
    listOts = document.getElementById(tipo + '-' + etp).value.split('_');

    document.getElementById(tipo + '-' + etp).value = listOts.filter(function(value, index, arr){
        return value !== ots;
    }).join('_');

    document.getElementById(tipo + 'Txt-' + ots + '-' + etp).remove();
    document.getElementById(tipo + 'Del-' + ots + '-' + etp).remove();
    document.getElementById(tipo + 'Br-' + ots + '-' + etp).remove()
}

function infosEildLegado(eild){
    var infos;
    infos = '';
    $.ajax({
        url: '/ajax-eild-legado',
        type: 'GET',
        async: false,
        data: {
            eild: String(eild)
        },
        contentType: 'application/json',
        success: function(response){
            eild = response['eild_legado']

            if(eild.length>0){
                infos =  infos +
                'EILD: '+ eild[0]['NumEILD'] + ' \n' +
                'id Rota: '+ eild[0]['idRota'] + ' \n' +
                'Status: '+ eild[0]['StatusCircuito'] + ' \n' +
                'Site A: '+ eild[0]['rotaSiteA'] + ' \n' +
                'Site B: '+ eild[0]['rotaSiteB'] + ' \n' +
                'Velocidade: '+ eild[0]['VelocidadeMeio']
            }
        },
        error: function(error){
            console.log(error);
        }
    });
    return infos;
}

function deleteEildLegado(tipo, eild, etp){
    listEilds = document.getElementById(tipo + '-' + etp).value.split('_');

    document.getElementById(tipo + '-' + etp).value = listEilds.filter(function(value, index, arr){
        return value !== eild;
    }).join('_');

    document.getElementById(tipo + 'Txt-' + eild + '-' + etp).remove();
    document.getElementById(tipo + 'Del-' + eild + '-' + etp).remove();
    document.getElementById(tipo + 'Br-' + eild + '-' + etp).remove()
}

function searchEildLegado(tipo, etp){
    $.ajax({
        url: '/ajax-eild-legado',
        type: 'GET',
        data: {
            eild: document.getElementById(tipo + 'Input-' + etp).value
        },
        contentType: 'application/json',
        success: function(response){
            eild = response['eild_legado']

            if(eild.length>0){
                var infos_eild_legado = '' +
                'EILD: '+ eild[0]['NumEILD'] + ' \n' +
                'id Rota: '+ eild[0]['idRota'] + ' \n' +
                'Status: '+ eild[0]['StatusCircuito'] + ' \n' +
                'Site A: '+ eild[0]['rotaSiteA'] + ' \n' +
                'Site B: '+ eild[0]['rotaSiteB'] + ' \n' +
                'Velocidade: '+ eild[0]['VelocidadeMeio']

                html_ped = '' +
                '<button id="' + tipo + 'Txt-' + eild[0]['NumEILD'] + '-' + etp +'" type="button" class="btn btn-link btn-sm" data-toggle="tooltip" data-placement="left" title="' + infos_eild_legado + '">' + eild[0]['NumEILD'] + '</button>' +
                '<a id="' + tipo + 'Del-' + eild[0]['NumEILD'] + '-' + etp +'" class="text-danger" style="cursor:pointer" onclick="deleteEildLegado(\'' + tipo +  '\', \'' + eild[0]['NumEILD'] +  '\', \'' + etp +  '\')">x</a>' +
                '<br id="' + tipo + 'Br-' + eild[0]['NumEILD'] + '-' + etp +'">'
                document.getElementById(tipo + 'DivList-' + etp).innerHTML = document.getElementById(tipo + 'DivList-' + etp).innerHTML+html_ped;
                document.getElementById(tipo + 'Input-' + etp).value = '';
                document.getElementById(tipo + '-' + etp).value = (document.getElementById(tipo + '-' + etp).value === '') ? eild[0]['NumEILD'] : document.getElementById(tipo + '-' + etp).value+'_'+eild[0]['NumEILD'];

                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-invalid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-valid');
            } else {
                document.getElementById(tipo + 'Input-' + etp).classList.remove('is-valid');
                document.getElementById(tipo + 'Input-' + etp).classList.add('is-invalid');
            }
        },
        error: function(error){
            swal("Erro!", "Ocorreu um erro ao buscar o EILD Legado!", "error");
        }
    });
}