// @Author: Rodolfo Castanho - Maio/2019

function layerVisible(cb){
    var visible;
    
    if(cb.checked){
        visible = map;
    } else {
        visible = null;
    }

    if(cb.value == 'marcadores'){
        changeMarkers(visible)
    } else {
        if(document.getElementById('marcadores').checked && cb.checked){
            addMarkers(markers.filter(function(obj){return obj.vendor == cb.value}), map);
            addMarkers(markersOts.filter(function(obj){return obj.vendor == cb.value}), map);
        } else {
            addMarkers(markers.filter(function(obj){return obj.vendor == cb.value}), null);
            addMarkers(markersOts.filter(function(obj){return obj.vendor == cb.value}), null);
        }
        addNetworkCoordinates(networkCoordinates.filter(function(obj){return obj.vendor == cb.value}), visible);
        addNetworkCoordinates(networkCoordinatesOts.filter(function(obj){return obj.vendor == cb.value}), visible);
    }
}

function initZoom(map){
    map.setCenter(new google.maps.LatLng(-15.7797203, -47.9297218));
    map.setZoom(5);
    hideLabel(map);
}

function searchSiteByName(txt, map){
    if(event.keyCode == 13) {
        var site = markers.concat(markersOts).find(function(obj){return obj.site + "." + obj.uf == txt.value.toUpperCase()});
        
        if(site == undefined){
            //PROCURAR MUNICÍPIO
            var municipio = municipiosCoordinates.find(function(obj){return obj.nome + " - " + obj.UF == txt.value.toUpperCase()});
            if(municipio == undefined){
                swal("", "Nenhum local encontrado!!", "warning", {buttons: false, timer: 1500});
                //alert("Nenhum local encontrado!!");
            } else {
                map.setCenter(new google.maps.LatLng(municipio["latitude"], municipio["longitude"]));
                map.setZoom(10);
                showLabel(map);
            }
        } else {
            map.setCenter(new google.maps.LatLng(site["lat"], site["lng"]));
            map.setZoom(10);
            site.setLabel({text: site.site+'.'+site.uf, fontWeight: "bold", color: '#363636'})
            //showLabel(map);
        }
    }
}

function searchIdRota(map){
    if(event.keyCode == 13){

        if(markersIdRota != undefined){
            addMarkers(markersIdRota, null);
            addNetworkCoordinates(networkCoordinatesIdRota, null);
        }

        initZoom(map);
        var ids = txt.value.split(" ");
        var arrIdRota = [];
        var arrIdRotaTrail = [];

        ids.forEach(function(item, index, ids){
            var arrFilter = idsRota.filter(function(obj){return obj.idRota == ids[index]});

            if(arrFilter.length > 0){
                arrFilter.forEach(function(itemFilter, indexFilter, arrFilter){
                    arrIdRota.push(arrFilter[indexFilter]);

                    //TRAIL
                    if(arrFilter[indexFilter].idRota_wdmtrail > 0){
                        var arrFilterTrail = idsRota.filter(function(obj){return obj.idRota == arrFilter[indexFilter].idRota_wdmtrail});
                        if(arrFilterTrail.length > 0){
                            arrFilterTrail.forEach(function(itemFilterTrail, indexFilterTrail, arrFilterTrail){
                                arrIdRotaTrail.push(arrFilterTrail[indexFilterTrail]);
                            })
                        }
                    }
                })
            }
        })

        if(arrIdRota.length == 0){
            swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
            //alert("Nenhum idRota encontrado!!!");
        } else {
            addIdRotaTopology(arrIdRota, arrIdRotaTrail, map);
        }
    }
}


function ajax_idRota(map){
    if(event.keyCode == 13){

        txt = document.getElementById("txtSearchIdRota").value;
        select = document.getElementById("selectIdRota");
        filtro = select.value;
        title = select.options[select.selectedIndex].text;

        document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';
        document.getElementById("idRotaLegend").innerHTML = "";

        initZoom(map);
        //var ids = txt.split(" ");
        var ids = "'" + txt.split(" ").join("', '") + "'";

        if(markersIdRota != undefined){
            addMarkers(markersIdRota, null);
            addNetworkCoordinates(networkCoordinatesIdRota, null);
        }

        $.ajax({
            url: '/ajax-idrota',
            data: {
              ids_form: String(ids),
              filtro: String(filtro)
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                document.getElementById("progress").innerHTML = "";
                if(response['idsRota'].length == 0){
                    idsRotaExcel = [];
                    idsRotaFields = {};
                    swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                    //alert("Nenhum idRota encontrado!!!");
                } else {
                    idsRotaExcel = response['idsRotaExcel'];
                    idsRotaFields = response['idsRotaFields'];
                    addIdRotaTopology(title, ids, filtro, response['idsRota'], response['idsRotaOMS'], map);
                }
            },
            error: function(error){
                document.getElementById("progress").innerHTML = "";
                swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                //alert("Nenhum idRota encontrado!!!");
            }
        });

    }
}

function floatClick(element, map){

    tipoMapa = element.title;

    switch(tipoMapa) {
        case 'Topologia':
            floatClickClean(map);
            createTopologyMap(markersOts, networkCoordinatesOts, map);
            break;
        case 'IdRota':
            floatClickClean(map)
            createIdRotaControl(map);
            break;
        case 'PER':
            createPerTopology(map);
            break;
        case 'SitesScience':
            createScience(map);
            break;
        default:
            createTopologyMap(map);
    }

}

function floatClickClean(map){

    initZoom(map);

    addMarkers(markers, null);
    addNetworkCoordinates(networkCoordinates, null);

    addMarkers(markersOts, null);
    addNetworkCoordinates(networkCoordinatesOts, null);

    addMarkers(markersIdRotaBase, null);
    addNetworkCoordinates(networkCoordinatesIdRotaBase, null);

    if(markersIdRota != undefined){
        addMarkers(markersIdRota, null);
        addNetworkCoordinates(networkCoordinatesIdRota, null);
    }

    document.getElementById("legend").innerHTML = "";
    //hideInfoPolyline();
}

/*
function showInfoPolyline(info){
    document.getElementById("infoPolyline").innerHTML = info;
}

function hideInfoPolyline(){
    document.getElementById("infoPolyline").innerHTML = "";
    //document.getElementById('infoPolyline').style.display="none";
}

function showInfoOms(latA, lngA, latB, lngB){
    var routesFiltered = networkCoordinates.filter(function(obj){
        return (obj.originCoordinate.LatitudeA == latA && obj.originCoordinate.LongitudeA == lngA && obj.originCoordinate.LatitudeB == latB && obj.originCoordinate.LongitudeB == lngB)
    })
    //console.log(routesFiltered);
    infoHtml = fillContentString(routesFiltered);
    showInfoPolyline(infoHtml);
}

function fillContentString(coordinates){
    var infosHtml = '';
    for(var i=0; i<coordinates.length; i++){
        infosHtml = infosHtml +
        '<h5 id="firstHeading" class="firstHeading">' + coordinates[i].originCoordinate.SiteA + '-' + coordinates[i].originCoordinate.UFA + ' <-> ' + coordinates[i].originCoordinate.SiteB + '-' + coordinates[i].originCoordinate.UFB + '</h5>'+
        '<div id="bodyContent">'+
        '<p>' +
        '<b>Id OMS:</b> ' + coordinates[i].originCoordinate.idWDMOMS +
        '<br>' +
        '<b>Proprietário da Fibra:</b> ' + coordinates[i].originCoordinate.PropriedadeFibra +
        '<br>' +
        '<b>HOP:</b> ' + coordinates[i].originCoordinate.SiteA + '-' + coordinates[i].originCoordinate.UFA + ' <-> ' + coordinates[i].originCoordinate.SiteB + '-' + coordinates[i].originCoordinate.UFB +
        '<br>' +
        '<br>' +
        '<b>Site A:</b> ' + coordinates[i].originCoordinate.SiteA +
        '<br>' +
        '<b>Equipamento A:</b> ' + coordinates[i].originCoordinate.EquipA +
        '<br>' +
        '<b>Latitude A:</b> ' + coordinates[i].originCoordinate.LatitudeA +
        '<br>' +
        '<b>Longitude A:</b> ' + coordinates[i].originCoordinate.LongitudeA +
        '<br>' +
        '<br>' +
        '<b>Site B:</b> ' + coordinates[i].originCoordinate.SiteB +
        '<br>' +
        '<b>Equipamento B:</b> ' + coordinates[i].originCoordinate.EquipB +
        '<br>' +
        '<b>Latitude B:</b> ' + coordinates[i].originCoordinate.LatitudeB +
        '<br>' +
        '<b>Longitude B:</b> ' + coordinates[i].originCoordinate.LongitudeB +
        '<br>' +
        '<br>' +
        '<b>Sigla:</b> ' + coordinates[i].originCoordinate.Sigla +
        '<br>' +
        '<b>Status:</b> ' + coordinates[i].originCoordinate.Status +
        '<br>' +
        '<b>Nº de Canais:</b> ' + coordinates[i].originCoordinate.NumCanais +
        '<br>' +
        '<b>Vendor:</b> ' + coordinates[i].originCoordinate.FabricanteA +
        '<br>' +
        '<br>' +
        '<b>CNL Início-Fim:</b> ' + coordinates[i].originCoordinate.InicioFimCNL +
        '<br>' +
        '<b>Nome da Rota Novo:</b> ' + coordinates[i].originCoordinate.NomeRotaNovo +
        '<br>' +
        '<b>Origem da Rota:</b> ' + coordinates[i].originCoordinate.OrigemRota +
        '<br>' +
        '<b>Coerente - Não Coerente:</b> ' + coordinates[i].originCoordinate.Coerente +
        '<br>' +
        '<b>Tipo de Fibra:</b> ' + coordinates[i].originCoordinate.TipoFibra +
        '<br>' +
        '<br>' +
        '<b>KM:</b> ' + coordinates[i].originCoordinate.KM +
        '<br>' +
        '<b>Atenuação por KM:</b> ' + coordinates[i].originCoordinate.AtenuacaoKM +
        '<br>' +
        '<b>Atenuação total:</b> ' + coordinates[i].originCoordinate.AtenuacaoTotal +
        '</p>'+
        '</div>'
    }
    return '' +
            '<div id="close">' +
            '<a class="close" href="#!">' +
            '<i class="material-icons" onclick="hideInfoPolyline()">close</i>' +
            '</a>' +
            '</div>' +
            '<div id="content">'+
            infosHtml +
            '</div>';
}
*/

function showLabel(map){
    var x = '2.0';

    var markersFiltered = markers.filter(function(obj){
                return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
            });

    var markersFilteredOts = markersOts.filter(function(obj){
                return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
            });

    for (var i = 0; i < markersFiltered.length; i++){
        markersFiltered[i].setLabel({text: markersFiltered[i].site+'.'+markersFiltered[i].uf, fontWeight: 'bold', color: '#363636'});
    }

    for (var i = 0; i < markersFilteredOts.length; i++){
        markersFilteredOts[i].setLabel({text: markersFilteredOts[i].site+'.'+markersFilteredOts[i].uf, fontWeight: 'bold', color: '#363636'});
    }
}

function hideLabel(map){
    for (var i = 0; i < markers.length; i++){
        markers[i].setLabel(null);
    }

    for (var i = 0; i < markersOts.length; i++){
        markersOts[i].setLabel(null);
    }
}

function labelIdRota(map, condition){
    if(condition){
        for (var i = 0; i < markersIdRota.length; i++){
            markersIdRota[i].setLabel(markersIdRota[i].site);
        }
    } else {
        for (var i = 0; i < markersIdRota.length; i++){
            markersIdRota[i].setLabel(null);
        }
        for (var i = 0; i < markersIdRotaPt.length; i++){
            markersIdRotaPt[i].setLabel(markersIdRotaPt[i].site);
        }
    }
}

function showDetailsOms(latA, lngA, latB, lngB){

    if(document.getElementById('layerList').value === 'OTS'){
        var routesFiltered = networkCoordinatesOts.filter(function(obj){
            return (obj.originCoordinate.LatitudeA == latA && obj.originCoordinate.LongitudeA == lngA && obj.originCoordinate.LatitudeB == latB && obj.originCoordinate.LongitudeB == lngB) || (obj.originCoordinate.LatitudeA == latB && obj.originCoordinate.LongitudeA == lngB && obj.originCoordinate.LatitudeB == latA && obj.originCoordinate.LongitudeB == lngA)
        })

        //html Detalhes OTS
        infosOTS = fillDetalhesOTS(routesFiltered);
        htmlDetalhesOTS = infosOTS[0];
        document.getElementById("modalDetalhesOTS").innerHTML = htmlDetalhesOTS;

        document.getElementById('ModalOTS').style.display = "block"

    } else {
        var routesFiltered = networkCoordinates.filter(function(obj){
            return (obj.originCoordinate.LatitudeA == latA && obj.originCoordinate.LongitudeA == lngA && obj.originCoordinate.LatitudeB == latB && obj.originCoordinate.LongitudeB == lngB) || (obj.originCoordinate.LatitudeA == latB && obj.originCoordinate.LongitudeA == lngB && obj.originCoordinate.LatitudeB == latA && obj.originCoordinate.LongitudeB == lngA)
        })

        //html Detalhes OMS
        infosOMS = fillDetalhesOMS(routesFiltered);
        htmlDetalhesOMS = infosOMS[0];
        document.getElementById("modalDetalhesOMS").innerHTML = htmlDetalhesOMS;

        //html Circuitos OMS
        $.ajax({
            url: '/ajax-circuitos-oms',
            data: {
              ids_oms: String(infosOMS[1].split(" "))
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                if(response['circuitosOMS'].length == 0){
                    console.log("Nenhum ciruito encontrado!!!");
                } else {
                    htmlCircuitosOMS = fillCircuitosOMS(response['circuitosOMS']);
                    document.getElementById("modalCircuitosOMS").innerHTML = htmlCircuitosOMS;
                }
            },
            error: function(error){
                console.log("Erro ao carregar circuitos!!!");
            }
        });

        document.getElementById('ModalOMS').style.display = "block"
    }

}

function hideDetailsOms(){
   document.getElementById("modalDetalhesOMS").innerHTML = '';
   document.getElementById("modalCircuitosOMS").innerHTML = '';
   document.getElementById("collapseOne").classList.add("show");
   document.getElementById("collapseTwo").classList.remove("show");
   document.getElementById('ModalOMS').style.display = "none"

   document.getElementById("modalDetalhesOTS").innerHTML = '';
   document.getElementById('ModalOTS').style.display = "none"
}

function fillDetalhesOTS(coordinates){
    var detalhesHtml = '';
    var ots = '';
    var infos = [];

    for(var i=0; i<coordinates.length; i++){
        ots = ots + coordinates[i].originCoordinate.idWDMOTS + ' ';
        var omss = (coordinates[i].originCoordinate.omss) ? coordinates[i].originCoordinate.omss : 'Sem Informação';

        detalhesHtml = detalhesHtml +
        '<h5>' + coordinates[i].originCoordinate.SiteA + '-' + coordinates[i].originCoordinate.UFA + ' <-> ' + coordinates[i].originCoordinate.SiteB + '-' + coordinates[i].originCoordinate.UFB + '</h5>' +
        '<table id="detalhesOTS" class="table table-sm table-hover table-bordered">' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Id OTS</th>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">Status</th>' +
        '<th scope="col">Tipo da Fibra</th>' +
        '<th scope="col">Tipo de Rede Optica</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.idWDMOTS + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Sigla + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Status + '</td>' +
        '<td>' + coordinates[i].originCoordinate.TipoFibra + '</td>' +
        '<td>' + coordinates[i].originCoordinate.TipoRedeOptica + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Site</th>' +
        '<th scope="col">Equipamento</th>' +
        '<th scope="col">Fabricante</th>' +
        '<th scope="col">Latitude</th>' +
        '<th scope="col">Longitude</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteA + '.' + coordinates[i].originCoordinate.UFA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.FabricanteA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LatitudeA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LongitudeA + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteB + '.' + coordinates[i].originCoordinate.UFB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.FabricanteB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LatitudeB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.LongitudeB + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Site</th>' +
        '<th scope="col">Sh/Sl/Po RX</th>' +
        '<th scope="col">Sh/Sl/Po TX</th>' +
        '<th scope="col">Modelo</th>' +
        '<th scope="col">Release HW</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteA + '.' + coordinates[i].originCoordinate.UFA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfARX + '/' + coordinates[i].originCoordinate.SlotARX + '/' + coordinates[i].originCoordinate.PortaARX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfATX + '/' + coordinates[i].originCoordinate.SlotATX + '/' + coordinates[i].originCoordinate.PortaATX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ModeloA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ReleaseHWA + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteB + '.' + coordinates[i].originCoordinate.UFB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfBRX + '/' + coordinates[i].originCoordinate.SlotBRX + '/' + coordinates[i].originCoordinate.PortaBRX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfBTX + '/' + coordinates[i].originCoordinate.SlotBTX + '/' + coordinates[i].originCoordinate.PortaBTX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ModeloB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ReleaseHWB + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Dist. Teór.</th>' +
        '<th scope="col">Dist. Basel.</th>' +
        '<th scope="col">Atenu. Teór.</th>' +
        '<th scope="col">Atenu. Basel. TX</th>' +
        '<th scope="col">Atenu. Basel. RX</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.DistanciaTeorica + '</td>' +
        '<td>' + coordinates[i].originCoordinate.DistanciaReal + '</td>' +
        '<td>' + coordinates[i].originCoordinate.AtenuacaoTeorica + '</td>' +
        '<td>' + coordinates[i].originCoordinate.AtenuacaoRealTX + '</td>' +
        '<td>' + coordinates[i].originCoordinate.AtenuacaoRealRX + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">dB KM</th>' +
        '<th scope="col">Coerente</th>' +
        '<th colspan="3" scope="col">OMS(s)</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.dB_Km + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Coerente + '</td>' +
        '<td colspan="3" >' + omss + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th colspan="2" scope="col">Proprietário da Fibra</th>' +
        '<th colspan="3" scope="col">Nome da Rota</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td colspan="2"  scope="row">' + coordinates[i].originCoordinate.PropriedadeFibra + '</td>' +
        '<td colspan="3">' + coordinates[i].originCoordinate.NomeRotaNovo + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>'
    }

    infos.push(detalhesHtml);
    infos.push(ots.trim());
    return infos;
}

function fillDetalhesOMS(coordinates){
    var detalhesHtml = '';
    var oms = '';
    var infos = [];

    for(var i=0; i<coordinates.length; i++){
        oms = oms + coordinates[i].originCoordinate.idWDMOMS + ' ';

        detalhesHtml = detalhesHtml +
        '<h5>' + coordinates[i].originCoordinate.SiteA + '-' + coordinates[i].originCoordinate.UFA + ' <-> ' + coordinates[i].originCoordinate.SiteB + '-' + coordinates[i].originCoordinate.UFB + '</h5>' +
        '<table id="detalhesOMS" class="table table-sm table-hover table-bordered">' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Id OMS</th>' +
        '<th scope="col">Sigla</th>' +
        '<th scope="col">Status</th>' +
        '<th scope="col">Vendor</th>' +
        '<th scope="col">Canais</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.idWDMOMS + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Sigla + '</td>' +
        '<td>' + coordinates[i].originCoordinate.Status + '</td>' +
        '<td>' + coordinates[i].originCoordinate.FabricanteA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.NumCanais + '</td>' +
        '</tr>' +
        '</tbody>' +
        '<thead>' +
        '<tr class="table-active">' +
        '<th scope="col">Site</th>' +
        '<th scope="col">Modelo</th>' +
        '<th scope="col">Sh/Sl RX</th>' +
        '<th colspan="2" scope="col">Sh/Sl TX</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteA + '.' + coordinates[i].originCoordinate.UFA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipA + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfRXA + '/' + coordinates[i].originCoordinate.SlotRXA + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.ShelfTXA + '/' + coordinates[i].originCoordinate.SlotTXA + '</td>' +
        '</tr>' +
        '<tr>' +
        '<td scope="row">' + coordinates[i].originCoordinate.SiteB + '.' + coordinates[i].originCoordinate.UFB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.EquipB + '</td>' +
        '<td>' + coordinates[i].originCoordinate.ShelfRXB + '/' + coordinates[i].originCoordinate.SlotRXB + '</td>' +
        '<td colspan="2">' + coordinates[i].originCoordinate.ShelfTXB + '/' + coordinates[i].originCoordinate.SlotTXB + '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>'
    }

    infos.push(detalhesHtml);
    infos.push(oms.trim());
    return infos;
}

function fillCircuitosOMS(circuitos){
    var circuitosHtml = '';

    circuitosHtml = circuitosHtml +
    '<div class="row"><div class="col-11">&nbsp;</div><div class="col-1"><a id="downloadLink" onclick="exportF(this)"><span style="cursor:pointer"><i class="fas fa-file-excel" style="font-size:24px;color:green"></i></span></a></div></div>' +
    '<table id="circuitosOMS" class="table table-sm table-hover table-bordered">' +
    '<thead>' +
    '<tr class="table-active">' +
    '<th scope="col">Id OMS</th>' +
    '<th scope="col">EILD</th>' +
    '<th scope="col">Sigla Rota</th>' +
    '<th scope="col">Velocidade</th>' +
    '<th scope="col">Num OE</th>' +
    '<th scope="col">Descrição OE</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>'

    for(var i=0; i<circuitos.length; i++){
        circuitosHtml = circuitosHtml +
        '<tr>' +
        '<td scope="row">' + circuitos[i].ID_OMS + '</td>' +
        '<td>' + circuitos[i].EILD1 + '</td>' +
        '<td>' + circuitos[i].SiglaRota + '</td>' +
        '<td>' + circuitos[i].VelocidadeRota + '</td>' +
        '<td>' + circuitos[i].NumOE + '</td>' +
        '<td title="' + circuitos[i].DescrOE + '">' + circuitos[i].DescrOE + '...</td>' +
        '</tr>'
    }

    circuitosHtml = circuitosHtml +
    '</tbody>' +
    '</table>'

    return circuitosHtml;
}

function exportF(elem) {
  var table = document.getElementById("circuitosOMS");
  var html = table.outerHTML;
  var url = 'data:application/vnd.ms-excel,' + escape(html); // Set your html table into url
  elem.setAttribute("href", url);
  elem.setAttribute("download", "circuitosOMS.xls"); // Choose the file name
  return false;
}


function orderExcelObject(datas, fields){
	orderedData = [];
	for (const row of datas) {
		orderedDict = {};
		for (const key of fields) {
			orderedDict[key] = row[key];
		}
		orderedData.push(orderedDict);
	}
	return orderedData;
}

function geraXLS (datas, fields){
    orderedData = orderExcelObject(datas, Object.values(fields));
    downloadXLS(orderedData);
}

function orderExcelObject(datas, fields){
	orderedData = [];
	for (const row of datas) {
		orderedDict = {};
		for (const key of fields) {
			orderedDict[key] = row[key];
		}
		orderedData.push(orderedDict);
	}
	return orderedData;
}

function downloadXLS(data) {

    let myExcelXML = (function() {
        let Workbook, WorkbookStart = '<?xml version="1.0"?><ss:Workbook  xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">';
        const WorkbookEnd = '</ss:Workbook>';
        let fs, SheetName = 'SHEET 1',
            styleID = 1, columnWidth = 80,
            fileName = "PortalBBTX_Filtros_"+String(Date.now()), uri, link;

        class myExcelXML {
            constructor(o) {
                let respArray = JSON.parse(o);
                let finalDataArray = [];

                for (let i = 0; i < respArray.length; i++) {
                    finalDataArray.push(flatten(respArray[i]));
                }

                let s = JSON.stringify(finalDataArray);
                fs = s.replace(/&/gi, '&amp;');
            }

            downLoad() {
                const Worksheet = myXMLWorkSheet(SheetName, fs);

                WorkbookStart += myXMLStyles(styleID);

                Workbook = WorkbookStart + Worksheet + WorkbookEnd;

                uri = 'data:text/xls;charset=utf-8,' + encodeURIComponent(Workbook);
                link = document.createElement("a");
                link.href = uri;
                link.style = "visibility:hidden";
                link.download = fileName + ".xls";

                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }

            get fileName() {
                return fileName;
            }

            set fileName(n) {
                fileName = n;
            }

            get SheetName() {
                return SheetName;
            }

            set SheetName(n) {
                SheetName = n;
            }

            get styleID() {
                return styleID;
            }

            set styleID(n) {
                styleID = n;
            }
        }

        const myXMLStyles = function(id) {
            let Styles = '<ss:Styles><ss:Style ss:ID="' + id + '"><ss:Font ss:Bold="1"/></ss:Style></ss:Styles>';

            return Styles;
        }

        const myXMLWorkSheet = function(name, o) {
            const Table = myXMLTable(o);
            let WorksheetStart = '<ss:Worksheet ss:Name="' + name + '">';
            const WorksheetEnd = '</ss:Worksheet>';

            return WorksheetStart + Table + WorksheetEnd;
        }

        const myXMLTable = function(o) {
            let TableStart = '<ss:Table>';
            const TableEnd = '</ss:Table>';

            const tableData = JSON.parse(o);

            if (tableData.length > 0) {
                const columnHeader = Object.keys(tableData[0]);
                let rowData;
                for (let i = 0; i < columnHeader.length; i++) {
                    TableStart += myXMLColumn(columnWidth);

                }
                for (let j = 0; j < tableData.length; j++) {
                    rowData += myXMLRow(tableData[j], columnHeader);
                }
                TableStart += myXMLHead(1, columnHeader);
                TableStart += rowData;
            }

            return TableStart + TableEnd;
        }

        const myXMLColumn = function(w) {
            return '<ss:Column ss:AutoFitWidth="0" ss:Width="' + w + '"/>';
        }


        const myXMLHead = function(id, h) {
            let HeadStart = '<ss:Row ss:StyleID="' + id + '">';
            const HeadEnd = '</ss:Row>';

            for (let i = 0; i < h.length; i++) {
                //const Cell = myXMLCell(h[i].toUpperCase());
                const Cell = myXMLCell(h[i]);
                HeadStart += Cell;
            }

            return HeadStart + HeadEnd;
        }

        const myXMLRow = function(r, h) {
            let RowStart = '<ss:Row>';
            const RowEnd = '</ss:Row>';
            for (let i = 0; i < h.length; i++) {
                const Cell = myXMLCell(r[h[i]]);
                RowStart += Cell;
            }

            return RowStart + RowEnd;
        }

        const myXMLCell = function(n) {
            let CellStart = '<ss:Cell>';
            const CellEnd = '</ss:Cell>';

            const Data = myXMLData(n);
            CellStart += Data;

            return CellStart + CellEnd;
        }

        const myXMLData = function(d) {
            let DataStart = '<ss:Data ss:Type="String">';
            const DataEnd = '</ss:Data>';

            return DataStart + d + DataEnd;
        }

        const flatten = function(obj) {
            var obj1 = JSON.parse(JSON.stringify(obj));
            const obj2 = JSON.parse(JSON.stringify(obj));
            if (typeof obj === 'object') {
                for (var k1 in obj2) {
                    if (obj2.hasOwnProperty(k1)) {
                        if (typeof obj2[k1] === 'object' && obj2[k1] !== null) {
                            delete obj1[k1]
                            for (var k2 in obj2[k1]) {
                                if (obj2[k1].hasOwnProperty(k2)) {
                                    obj1[k1 + '-' + k2] = obj2[k1][k2];
                                }
                            }
                        }
                    }
                }
                var hasObject = false;
                for (var key in obj1) {
                    if (obj1.hasOwnProperty(key)) {
                        if (typeof obj1[key] === 'object' && obj1[key] !== null) {
                            hasObject = true;
                        }
                    }
                }
                if (hasObject) {
                    return flatten(obj1);
                } else {
                    return obj1;
                }
            } else {
                return obj1;
            }
        }

        return myExcelXML;
    })();

    var dataJson = JSON.stringify(data)
    var dataXML = new myExcelXML(dataJson);
    dataXML.downLoad();
}

function changeColor(id){
    colors = {
      0: "#696969",
      1: "#00008B",
      2: "#228B22",
      3: "#FF8C00",
      4: "#8B008B",
      5: "#8B0000"
    }
    colorNow = parseInt(document.getElementById(id).className);
    colorNow = (colorNow === 5) ? 0 : colorNow+1;
    document.getElementById(id).className = colorNow
    document.getElementById(id).style.color = colors[colorNow];

    lines = networkCoordinatesIdRota.filter(function(obj){return obj.idRota == id});
    for(var i=0; i<lines.length; i++){
        lines[i].setOptions({strokeColor: colors[colorNow]});
    };
}

function changeMarkers(visible){
    for(var i in iconsVendor){
        vendor = iconsVendor[i]['vendor'];
        if(document.getElementById(vendor).checked == true){
            addMarkers(markers.filter(function(obj){return obj.vendor == vendor}), visible);
            addMarkers(markersOts.filter(function(obj){return obj.vendor == vendor}), visible);
        }
    }
}


