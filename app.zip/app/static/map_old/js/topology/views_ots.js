function createLayerLegend(legend){
    var html = '<table><tr>' +
        '<td align="center" width="80">Camada</td>' +
        '<td align="left" width="40">' +
        '<select onchange="chooseLayer(this)" id="layerList">' +
        '<option>OTS</option>' +
        '<option>OMS</option>' +
        '</select>' +
        '</td>' +
        '</tr></table>'
        var div = document.createElement('div');
        div.innerHTML = html;
        legend.appendChild(div);
}

function chooseLayer(item){
    var layer = item.value;
    var showOMS = (layer == 'OMS') ? map : null;
    var showOTS = (layer == 'OTS') ? map : null;

    addMarkers(markers, showOMS);
    addNetworkCoordinates(networkCoordinates, showOMS);
    addMarkers(markersOts, showOTS);
    addNetworkCoordinates(networkCoordinatesOts, showOTS);

    layerVisible(document.getElementById('marcadores'));

    ['Ciena', 'Coriant', 'Huawei', 'Nokia', 'Padtec', 'ECI'].forEach(function(item, index, vendors){
        layerVisible(document.getElementById(item));
    })
}

function showDetailsOts(){
    console.log('detail ots');
}