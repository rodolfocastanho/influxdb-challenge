function createScience(map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    $.ajax({
        url: '/ajax-science',
        type: 'GET',
        contentType: 'application/json',
        success: function(response){
            scienceCoordinates = response['marker'];

            var scienceDiv = document.createElement('div');
            scienceDiv.id = 'science';
            createScienceDiv(scienceDiv);
            scienceDiv.setAttribute('class', 'w-50');
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(scienceDiv);

            var scienceSelected;
            var scienceTopology;

            $.extend( true, $.fn.dataTable.defaults, {
                retrieve: true,
                lengthChange: false,
                paging: false,
                info: false
            } );

            $( "#accordionScience" ).on("shown.bs.collapse", function() {
                $.each($.fn.dataTable.tables(true), function(){
                $(this).DataTable().columns.adjust().draw();
                });
            });

            $('#tableScience tfoot th').each( function () {
                var title = $(this).text();
                if(title !== ''){
                    $(this).html( '<input type="text" placeholder="Busca '+title+'" />' );
                }
            } );

            var table = $('#tableScience').DataTable({
                data: scienceCoordinates,
                columns: [
                    { title: '', defaultContent: '' },
                    { title: 'Sigla', data: 'sigla' },
                    { title: 'UF', data: 'uf' },
                    { title: 'Nome', data: 'nome' },
                    { title: 'Município', data: 'municipio' },
                    { title: 'Utilização', data: 'utilizacao' }
                ],
                columnDefs: [
                    {targets: [0, 3, 4, 5], orderable: false},
                    //{targets: [1, 2], orderable: true},
                    {targets: 0, checkboxes: { selectRow: true }}
                ],
                select: {
                    style: 'multi'
                },
                scrollY: '400px',
                scrollCollapse: true,
                language: {
                    //url: "http://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
                    search: 'Pesquisar:',
                    zeroRecords: 'Nenhum registro encontrado...'
                },
                dom: 'Bfrtip',
                select: true,
                buttons: [
                    {
                        text: 'Plotar Site(s) selecionados',
                        action: function () {
                            scienceSelected = table.rows( { selected: true } );
                            scienceTopology = [];

                            if(scienceSelected.count() == 0){
                                alert("Nenhum Site selecionado...")
                            } else {
                                for(i=0; i<scienceSelected.count(); i++){
                                    scienceTopology.push(scienceSelected.data()[i]);
                                }
                                //chama função para plotar
                                addScienceTopology(scienceTopology, map);
                                //fecha accordion
                                document.getElementById("btnSelectScience").click();
                            }
                        }
                    }
                ],


                initComplete: function () {
                    // Apply the search
                    this.api().columns().every( function () {
                        var that = this;

                        $( 'input', this.footer() ).on( 'keyup change clear', function () {
                            if ( that.search() !== this.value ) {
                                that
                                    .search( this.value )
                                    .draw();
                            }
                        } );
                    } );
                }
            });
            //document.getElementById("collapsePer").setAttribute('class', 'collapse w-100');
            scienceDiv.setAttribute('class', 'w-100');
            scienceDiv.setAttribute('class', 'w-50');
            document.getElementById("progress").innerHTML = '';
        },
        error: function(error){
            console.log(error);
            document.getElementById("progress").innerHTML = '';
        }
    });
}

function createScienceDiv(scienceDiv){
    var html = '' +
    '<div class="accordion" id="accordionScience">' +
    '<div class="card">' +
    '<div class="card-header" id="headingScience">' +
    '<h2 class="mb-0">' +
    '<button id="btnSelectScience" class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseScience" aria-expanded="true" aria-controls="collapseScience">' +
    'Sites (Science)' +
    '</button>' +
    '<a class="close" href="#!">' +
    '<i class="material-icons" onclick="hideScience()">close</i>' +
    '</a>' +
    '</h2>' +
    '</div>' +
    '<div id="collapseScience" class="collapse show" aria-labelledby="headingPer" data-parent="#accordionScience">' +
    '<div class="card-body">' +
    '<table id="tableScience" class="display compact card-table table">' +

    '<tfoot>' +
    '<tr>' +
    '<th></th>' +
    '<th>Sigla</th>' +
    '<th>UF</th>' +
    '<th>Nome</th>' +
    '<th>Municipio</th>' +
    '<th>Utilizacao</th>' +
    '</tr>' +
    '</tfoot>' +

    '</table>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'
    scienceDiv.innerHTML = html;
}

function hideScience(){
   if(markersScience != undefined){
        addMarkers(markersScience, null);
        //addNetworkCoordinates(networkCoordinatesPer, null);
    }
    document.getElementById("science").innerHTML = "";
    map.controls[google.maps.ControlPosition.TOP_CENTER].pop(document.getElementById('science'));
    scienceCoordinates = [];
    markersScience = [];
    //networkCoordinatesPer = [];
}

function addScienceTopology(idsScienceCoordinates, map){
    document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';

    if(markersScience != undefined){
        addMarkers(markersScience, null);
        //addNetworkCoordinates(networkCoordinatesPer, null);
    }

    markersScience = [];
    //networkCoordinatesPer = [];
    color = '#EE0000';

    for(var i=0; i<idsScienceCoordinates.length; i++){
        createMarkerScience(idsScienceCoordinates[i], map);
        //createLinePer(idsPerCoordinates[i], color, map);
    }

    function createMarkerScience(coord, map){
        var scaleIcon = 8;
        var scaleIconClick = 12;
        var opacity = 0.5;

        var iconClick = {
            url: iconBase + '/vendor/Outros/Outros.png',
            scaledSize: { height: scaleIconClick, width: scaleIconClick },
            labelOrigin: new google.maps.Point(0, -4)
        }

        var icon = {
                url: iconBase + '/vendor/Outros/Outros.png',
                scaledSize: { height: scaleIcon, width: scaleIcon }
            }

        var marker = new google.maps.Marker({
            //label: coord.SiteA,
            title: coord.sigla+'.'+coord.uf,
            icon: icon,
            position: new google.maps.LatLng(coord.latitude, coord.longitude),
            opacity: opacity
        });

        marker.addListener('click', function() {
          if(marker.label == null){
            marker.setIcon(iconClick);
            marker.setLabel({text: coord.sigla+'.'+coord.uf, fontWeight: 'bold', color: '#363636'});
            marker.setOpacity(1);
          } else  {
            marker.setIcon(icon);
            marker.setLabel(null);
            marker.setOpacity(opacity);
          }
        });

        markersScience.push(marker);
        marker.setMap(map);
    }

    /*
    function createLinePer(coord, color, map){
        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 1.5
        })

        networkCoordinatesPer.push(line);
        line.setMap(map);
    }
    */

    document.getElementById("progress").innerHTML = '';
}