var infowindow;

function createAllElements(){
    createCompleteLegend();

    infowindow = new google.maps.InfoWindow();
    markers = defineMarkers(fibrados);
    addMarkers(markers, map);
    createInfoTables();
    createUfsLegend();
    showInfoTable();
}

function createCompleteLegend(){
    var legend = document.getElementById('legend');
    createLegendTitle(legend);
    createLineLegend(legend);
    createLegend(iconsVendor, legend, true);
    createLineLegend(legend);
    createShowLabel(legend);
    createLineLegend(legend);
    createScaleIcon(legend);
    createLineLegend(legend);
    createSearchSite(legend);
}

function defineMarkers(loc){
    var markers = [];

    for(var i=0; i<loc.length; i++){
        //console.log(loc[i].codigo_ibge, loc[i].final, loc[i].classifica_populacao)
        locIcon = capacities.find(function(obj){return obj[0] == loc[i].final})[1]
        //scaleIcon = population.find(function(obj){return obj[0] == loc[i].classifica_populacao})[1]
        scaleIcon = 6;

        var icon = {
            url: iconBase + 'vendor/' + locIcon + '/TOADM.png',
            scaledSize: { height: scaleIcon, width: scaleIcon },
            labelOrigin: new google.maps.Point(0, -4)
        }

        var marker = new google.maps.Marker({
            //label: {text: loc[i].chave, color: 'black', fontSize: "4px"},
            chave: loc[i].chave,
            ibge: loc[i].codigo_ibge,
            qtdPopulation: loc[i].populacao,
            capacity: loc[i].final,
            population: loc[i].classifica_populacao,
            uf:  loc[i].uf,
            localidade: loc[i].nome_uf + ' (' + loc[i].uf + ')',
            lat: loc[i].latitude,
            lng: loc[i].longitude,
            icon: icon,
            position: new google.maps.LatLng(loc[i].latitude, loc[i].longitude)
        });

        marker.addListener('click', function() {
            showInfoWindow(this, map);
        });

        markers.push(marker);
    };

    return markers;
}

function showInfoWindow(mThis, map){
    var infos =
        '<div id="infos_municipios">' +
        '<h5>' + mThis.chave + '</h5>' +
        '<div id="infos_infos">' +
        '<span><b>Cod. IBGE:</b> ' + mThis.ibge + '</span><br>' +
        '<span><b>População:</b> ' + mThis.qtdPopulation + '</span><br>' +
        '<span><b>Transporte:</b> ' + mThis.capacity + '</span><br>' +
        '<span><b>Classificação:</b> ' + mThis.population + '</span><br>' +
        '<span><b>Localidade:</b> ' + mThis.localidade + '</span><br>' +
        '</div>' +
        '</div>';

    infowindow.close();
    infowindow.setContent(infos);
    infowindow.open(map, mThis);
    map.setCenter(mThis.getPosition());
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

function createCustomControls(customControls){
    var div = document.createElement('div');
    var html = '' +
    //'<img id="reportIcon" src="img/icons/report.png" alt="Resumo" onclick="showReport(map, report)">' +
    //'<hr>' +
    '<img id="zoomIcon" src="static/map/img/icons/zoom.png" alt="Visão Geral" onclick="initZoom(map)">'
    div.innerHTML = html;
    customControls.appendChild(div);
}

function initZoom(map){
    map.setCenter(new google.maps.LatLng(-15.7797203, -47.9297218));
    map.setZoom(4);
}

function createLegendTitle(legend){
    var div = document.createElement('div');
    div.innerHTML = '<h7>Legenda</h7>';
    legend.appendChild(div);
}

function createLineLegend(legend){
    var div = document.createElement('div');
    //div.innerHTML = '<hr>';
    div.innerHTML = '<table><tr><td colspan="3">&nbsp</td></tr>';
    legend.appendChild(div);
}

function createLegend(icons, legend, checkbox){
    for(i=0; i<capacities.length; i++){
        var div = document.createElement('div');
        var checkboxDiv = "";
        if(checkbox){
        checkboxDiv = '' +
        '<div class="form-check">' +
        '<label class="form-check-label" for="' + capacities[i][0] + '">&nbsp;</label>' +
        '<input class="form-check-input" type="checkbox" id="' + capacities[i][0] + '" checked="checked" value="' + capacities[i][0] + '" onclick="layerVisible(this)">' +
        '</div>'
        }

        var html = '<table>' +
        '<tr>' +
        '<td align="center" width="20"><img src="' + iconBase + '/vendor/' + capacities[i][1] + '/TOADM.png"></td>' +
        '<td align="left" width="80">' + capacities[i][0] + '</td>' +
        '<td align="left" width="20">' +
        checkboxDiv +
        '</td>' +
        '</tr>' +
        '</table>'
        div.innerHTML = html;
        legend.appendChild(div);
    }
}

function createShowLabel(legend){
    var html = '<table><tr>' +
        '<td align="center" width="80">Labels</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="showLabel(map)">add</i></a>' +
        '</td>' +
        '<td align="left" width="20">' +
        '<a href="#"><i class="material-icons" onclick="hideLabel(map)">remove</i></a>' +
        '</td>' +
        '</tr></table>'
        var div = document.createElement('div');
        div.innerHTML = html;
        legend.appendChild(div);
}

function createScaleIcon(legend){
    var div = document.createElement('div');
    var checkboxDiv = '' +
    '<div class="form-check">' +
    '<label class="form-check-label" for="scale-icon">&nbsp;</label>' +
    '<input class="form-check-input" type="checkbox" id="scale-icon" onclick="changeIconScale(this)">' +
    '</div>'

    var html = '<table>' +
    '<tr>' +
    '<td align="center" colspan="2" width="100">Ícone por Popul.</td>' +
    '<td align="left" width="20">' +
    checkboxDiv +
    '</td>' +
    '</tr>' +
    '</table>'
    div.innerHTML = html;
    legend.appendChild(div);
}

function createSearchSite(legend){
    var div = document.createElement('div');
    var html = '' +
    '<div class="form-group">' +
    '<input id="txtSearchSiteByName" type="text" class="validate" onkeydown="searchSiteByName(this, map)" placeholder="Busca por município">' +
    '</div>'

    //'<input size="17" type="text" id="txtSearchSiteByName" placeholder="Busca por site" onkeydown="searchSiteByName(this, map)"/>'
    div.innerHTML = html;
    legend.appendChild(div);
    //autocomplete(document.getElementById("txtSearchSiteByName"), [document.getElementById("sites").value]);
    autocomplete(document.getElementById("txtSearchSiteByName"), municipios);
}

function searchSiteByName(txt, map){
    if(event.keyCode == 13) {
        var pos = municipios.find(function(obj){return obj.Site == txt.value.toUpperCase()});

        map.setCenter(new google.maps.LatLng(pos["latitude"], pos["longitude"]));
        map.setZoom(10);
    }
}

function layerVisible(cb){
    var visible;
    var filter;

    if(cb.checked){
        visible = map;
        filter = 1;
    } else {
        visible = null;
        filter = 0;
    }

    if(cb.value == 'marcadores'){
        changeMarkers(visible)
    } else {
        addMarkers(markers.filter(function(obj){return obj.capacity == cb.value && filtersTable['ufs'].includes(obj.uf)}), visible);
        filtersTable['capacities'].filter(function(obj){return obj[0] == cb.value})[0][1] = filter;
    }

    createInfoTables();
}

function layerUfVisible(cb){
    var visible;

    var capacitiesFilter = [];
    for(i=0; i<filtersTable['capacities'].length; i++){
        if(filtersTable['capacities'][i][1]>0){
            capacitiesFilter.push(filtersTable['capacities'][i][0]);
        }
    }

    if(cb.checked){
        visible = map;
        filtersTable['ufs'].push(cb.value)
    } else {
        visible = null;
        delete filtersTable['ufs'][filtersTable['ufs'].indexOf(cb.value)]
        filtersTable['ufs'] = filtersTable['ufs'].flat()
    }

    addMarkers(markers.filter(function(obj){return obj.uf == cb.value && capacitiesFilter.includes(obj.capacity)}), visible);
    createInfoTables();
}

function layerUfTodosVisible(cb){
    var capacitiesFilter = [];
    for(i=0; i<filtersTable['capacities'].length; i++){
        if(filtersTable['capacities'][i][1]>0){
            capacitiesFilter.push(filtersTable['capacities'][i][0]);
        }
    }

    var listufs = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB',
                    'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO']
    for(i=0; i<listufs.length; i++){
        document.getElementById(listufs[i]).checked = cb.checked;
    }

    filtersTable['ufs'] = (cb.checked) ? listufs : [];
    var visible = (cb.checked) ? map : null;
    addMarkers(markers.filter(function(obj){return listufs.includes(obj.uf) && capacitiesFilter.includes(obj.capacity)}), visible);
    createInfoTables();
}

function changeIconScale(cb){
    for (var i=0; i<markers.length; i++){
        scaleIcon = (cb.checked) ? population.find(function(obj){return obj[0] == markers[i].population})[1] : 6;
        markers[i].setIcon(
            {
              url: markers[i].icon.url,
              scaledSize: { height: scaleIcon, width: scaleIcon },
              labelOrigin: new google.maps.Point(0, -4)
            }
        );
    }
}

function showLabel(map){
    var x = '.5';
    var markersFiltered = markers.filter(function(obj){
                return (obj.lng <= parseFloat(parseFloat(map.getCenter().lng()) + parseFloat(x)) && obj.lng >= parseFloat(parseFloat(map.getCenter().lng()) - parseFloat(x))) && (obj.lat <= parseFloat(parseFloat(map.getCenter().lat()) + parseFloat(x)) && obj.lat >= parseFloat(parseFloat(map.getCenter().lat()) - parseFloat(x)))
            });

    for (var i = 0; i < markersFiltered.length; i++){
        markersFiltered[i].setLabel({text: markersFiltered[i].chave, fontWeight: 'bold', color: '#363636'});
    }
}

function hideLabel(map){
    for (var i = 0; i < markers.length; i++){
        markers[i].setLabel(null);
    }
}

function createInfoTables(){
    document.getElementById('tableInfos').innerHTML = '';

    var capacitiesFilter = [];
    for(i=0; i<filtersTable['capacities'].length; i++){
        if(filtersTable['capacities'][i][1]>0){
            capacitiesFilter.push(filtersTable['capacities'][i][0]);
        }
    }

    var municipiosTable = grupos.filter(function(obj){return filtersTable['ufs'].includes(obj._id.uf) && capacitiesFilter.includes(obj._id.final)})

    var cTotalCP = 0;
    var totalCapacities = {
        'CADASTRO': 0,
        'FIBRADO': 0,
        'OPEX': 0,
        'RÁDIO': 0,
        'SATÉLITE': 0,
        'SWAP CAPACIDADE': 0,
        'N/A': 0
    }

    html = '' +
    '<table class="table table-sm table-bordered">' +
    '<thead>' +
    '<tr>' +
    '<th scope="col">#</th>'
    for(i=0; i<filtersTable['capacities'].length; i++){
        html = html + '<th scope="col" width="80">' + filtersTable['capacities'][i][2] + '</th>';
    }
    html = html +
    '<th scope="col" width="80">Total</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>'
    for(p=0; p<filtersTable['population'].length; p++){
        var cTotalC = 0;
        html = html +
        '<tr>' +
        '<th scope="row">' + filtersTable['population'][p] + '</th>'
        for(c=0; c<filtersTable['capacities'].length; c++){
            var cTotal = municipiosTable.filter(function(obj){return obj._id.classifica_populacao == filtersTable['population'][p] && obj._id.final == filtersTable['capacities'][c][0]})
            if(cTotal.length > 0){
                cTotal = cTotal.reduce(function(prev, cur) {
                  return prev + cur.count;
                }, 0);
            } else {
                cTotal = 0;
            }
            cTotalC = cTotalC + cTotal;
            totalCapacities[filtersTable['capacities'][c][0]] = totalCapacities[filtersTable['capacities'][c][0]] + cTotal;
            cTotal = (cTotal>0) ? cTotal : '-';

            html = html + '<td>' + cTotal + '</td>'
        }
        html = html +
        '<th scope="row">' + cTotalC + '</th>' +
        '</tr>'
    }
    html = html + '<tr><th scope="row"></th>'
    cTotalFList = []
    for(i=0; i<filtersTable['capacities'].length; i++){
        cTotalF = totalCapacities[filtersTable['capacities'][i][0]];
        cTotalFList.push(cTotalF)
        cTotalCP = cTotalCP + cTotalF;
    }
    for(i=0; i<cTotalFList.length; i++){
        cPct = (cTotalCP>0) ? Math.round((cTotalFList[i]/cTotalCP)*100) : '-';
        cVlr = (cTotalFList[i]>0) ? cTotalFList[i] : '-';
        html = html + '<th scope="row">' + cVlr + ' (' + cPct + '%)</th>';
    }
    html = html + '<th scope="row">' + cTotalCP + '</th></tr>'
    html = html +
    '</tbody>' +
    '</table>'

    document.getElementById('tableInfos').innerHTML = html;
}

function createUfsLegend(){
    document.getElementById('ufs').innerHTML = '';

     html = '' +
    '<table>' +
    '<thead>' +
    '<tr>'
    for(i=0; i<filtersTable['ufs'].length; i++){
        html = html + '<th scope="col">' + filtersTable['ufs'][i] + '</th>';
    }
    html = html +
    '<th scope="col">Todos</th>' +
    '</tr>' +
    '</thead>' +
    '<tbody>' +
    '<tr>'
    for(i=0; i<filtersTable['ufs'].length; i++){
        var checkUf = '' +
        '<div class="form-check">' +
        '<label class="form-check-label" for="' + filtersTable['ufs'][i] + '">&nbsp;</label>' +
        '<input class="form-check-input" type="checkbox" id="' + filtersTable['ufs'][i] + '" checked="checked" value="' + filtersTable['ufs'][i] + '" onclick="layerUfVisible(this)">' +
        '</div>'
        html = html + '<td>' + checkUf + '</td>';
    }
    var checkUfTodos = '' +
    '<div class="form-check">' +
    '<label class="form-check-label" for="Todos">&nbsp;</label>' +
    '<input class="form-check-input" type="checkbox" id="Todos" checked="checked" value="Todos" onclick="layerUfTodosVisible(this)">' +
    '</div>'
    html = html +
    '<td>' + checkUfTodos + '</td>' +
    '</tr>' +
    '</tbody>' +
    '</table>'

    document.getElementById('ufs').innerHTML = html;
    showInfoTable();
}

function showInfoTable(){
    if(document.getElementById('tableInfos').style.display == 'block'){
        document.getElementById('tableInfos').style.display = 'none';
        document.getElementById('aTableInfos').text = 'Ver Informações...';
    } else {
        document.getElementById('tableInfos').style.display = 'block';
        document.getElementById('aTableInfos').text = 'Ocultar Informações...';
    }
}