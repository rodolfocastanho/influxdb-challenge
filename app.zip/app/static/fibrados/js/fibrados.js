// @Author: Rodolfo Castanho - Maio/2019

var map;
var markers;
var networkCoordinates;
var searchSite;

var capacities = [
    //['CADASTRO', 'Coriant'],
    ['FIBRADO', 'Huawei'],
    ['OPEX', 'Padtec'],
    ['RÁDIO', 'ECI'],
    ['SATÉLITE', 'Nokia'],
    ['SWAP CAPACIDADE', 'Outros'],
    ['N/A', 'Ciena']
]

var population = [
    ['1) Municípios <50K', 4],
    ['2) Municípios >50K < 100K', 6],
    ['3) Municípios >100K <200K', 8],
    ['4) Municípios >200K <300K', 10],
    ['5) Municípios >300K <500K', 12],
    ['6) Municípios >500K', 14]
]

var filtersTable = {
    capacities: [
        //['CADASTRO', 1, 'Cadastro'],
        ['FIBRADO', 1, 'Fibrado'],
        ['OPEX', 1, 'Opex'],
        ['RÁDIO', 1, 'Rádio'],
        ['SATÉLITE', 1, 'Satélite'],
        ['SWAP CAPACIDADE', 1, 'Swap Capac.'],
        ['N/A', 1, 'N/A']
    ],
    population: ['1) Municípios <50K', '2) Municípios >50K < 100K', '3) Municípios >100K <200K',
                 '4) Municípios >200K <300K', '5) Municípios >300K <500K', '6) Municípios >500K'],
    ufs: ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB',
          'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO']
}

function initMap() {

    var styledMapType = new google.maps.StyledMapType(
            [{ "elementType": "geometry", "stylers": [ { "color": "#f5f5f5" } ] },
            { "elementType": "geometry.fill", "stylers": [ { "visibility": "simplified" } ] },
            //{ "elementType": "geometry.fill", "stylers": [ { "color": "#FFFAFA" } ] },
            { "elementType": "geometry.stroke", "stylers": [ { "visibility": "on" }, { "weight": 1 } ] },
            { "elementType": "labels.icon", "stylers": [ { "visibility": "off" } ] },
            { "elementType": "labels.text.fill", "stylers": [ { "color": "#9a9a9a" } ] },
            { "elementType": "labels.text.stroke", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [ { "color": "#bdbdbd" } ] },
            { "featureType": "poi", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "poi.park", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "road", "elementType": "geometry", "stylers": [ { "color": "#ffffff" } ] },
            { "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [ { "color": "#757575" } ] },
            { "featureType": "road.highway", "elementType": "geometry", "stylers": [ { "color": "#dadada" } ] },
            { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [ { "color": "#616161" } ] },
            { "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] },
            { "featureType": "transit.line", "elementType": "geometry", "stylers": [ { "color": "#e5e5e5" } ] },
            { "featureType": "transit.station", "elementType": "geometry", "stylers": [ { "color": "#eeeeee" } ] },
            { "featureType": "water", "elementType": "geometry", "stylers": [ { "color": "#c9c9c9" } ] },
            //{ "featureType": "water", "elementType": "geometry.fill", "stylers": [ {"color": "#F0FFFF"} ] },
            { "featureType": "water", "elementType": "labels.text.fill", "stylers": [ { "color": "#9e9e9e" } ] } ],
            {name: 'Simples'});

    map = new google.maps.Map(document.getElementById('map'), {
      zoom: 4,
      center: new google.maps.LatLng(-15.7797203, -47.9297218), //Brasília
      //mapTypeId: 'roadmap',
      //gestureHandling: 'cooperative',
      streetViewControl: false,
      zoomControl: false,
      fullscreenControl: true,
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain',
                'styled_map']
      }
    });

    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');

    var customControls = document.getElementById('customControls')
    createCustomControls(customControls);
    map.controls[google.maps.ControlPosition.TOP_RIGHT].push(customControls);
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('ufs'));

    // Fibrados
    map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('legend'));
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(document.getElementById('infos'));
    createAllElements();
    //plotFibrados(map, fibrados);

    // Add a marker clusterer to manage the markers.
    // var markerCluster = new MarkerClusterer(map, markers,{imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});

}

