function limpaResultados(){
    document.getElementById('tableResumo').innerHTML='';
    document.getElementById("legend").innerHTML = '';
    //document.getElementById("diagrama").innerHTML = '';
    document.getElementById('collapseResumo').classList.remove('show');
    //document.getElementById('collapseDiagrama').classList.remove('show');
    document.getElementById('collapseMapa').classList.remove('show');
}

function searchUplinks(txt, map){
    if(event.keyCode == 13) {
        var filtro = txt.value.toUpperCase();

        limpaResultados();
        if(markersIdRota != undefined){
            addMarkers(markersIdRota, null);
            addNetworkCoordinates(networkCoordinatesIdRota, null);
        }

        //document.getElementById("progress").innerHTML = '<img src="static/map/img/preload_DoubleRing.gif">';
        $.ajax({
            url: '/ajax-uplinks',
            data: {
              filtro: String(filtro)
            },
            type: 'GET',
            contentType: 'application/json',
            success: function(response){
                //document.getElementById("progress").innerHTML = "";
                resumo = response['resumo'];
                if(resumo.length == 0){
                    swal("", "Nenhum elemento encontrado!!", "warning", {buttons: false, timer: 1500});
                } else {
                    addTableResumo(resumo, 'tableResumo');
                    //addDiagrama(response['diagrama']);
                    document.getElementById('collapseResumo').classList.add('show');
                    if(response['idsRota'].length > 0){
                        addIdRotaTopology(response['idsRota'], response['idsRotaOMS'], map);
                    }
                }
            },
            error: function(error){
                //document.getElementById("progress").innerHTML = "";
                console.log(error);
                swal("", "Erro na busca. Tente novamente!!", "warning", {buttons: false, timer: 1500});
            }
        });
    }
}

function addTableResumo(resumo, divId){
    var html = '<table class="table table-sm table-hover">' +
                '<thead>' +
                '<tr>' +
                '<th scope="col" colspan="8">Encontradas ' + resumo.length + ' conexões</th>' +
                '</tr>' +
                '<tr>' +
                '<th scope="col">SiteA</th>' +
                '<th scope="col">CidadeA</th>' +
                '<th scope="col">CamadaA</th>' +
                '<th scope="col">SiteB</th>' +
                '<th scope="col">CidadeB</th>' +
                '<th scope="col">CamadaB</th>' +
                '<th scope="col">Velocidade</th>' +
                '<th scope="col">Designador</th>' +
                '<th scope="col">Host</th>' +
                '<th scope="col">Int</th>' +
                '</tr>' +
                '</thead>' +
                '<tbody>'
    for(var i=0; i<resumo.length; i++){
        html = html + '<tr>'
        html = html + '<td>' + resumo[i].SITE_A + '-' + resumo[i].UF_A + '</td>'
        html = html + '<td>' + resumo[i].CIDADE_A + '</td>'
        html = html + '<td>' + resumo[i].CamadaA + '</td>'
        html = html + '<td>' + resumo[i].SITE_B + '-' + resumo[i].UF_B + '</td>'
        html = html + '<td>' + resumo[i].CIDADE_B + '</td>'
        html = html + '<td>' + resumo[i].CamadaB + '</td>'
        html = html + '<td>' + resumo[i].TesteVelocidade + '</td>'
        html = html + '<td>' + resumo[i].Designador + '</td>'
        html = html + '<td>' + resumo[i].HOST_A + '</td>'
        html = html + '<td>' + resumo[i].INT_A_APOIO + '</td>'
        html = html + '</tr>'
    };
    html = html + '</tbody>' +
                '</table>'

    document.getElementById(divId).innerHTML+=html;
}

var lineSymbol = {
    path: 'M 0,-1 0,1',
    //strokeOpacity: 1,
    strokeColor: '#DCDCDC',
    scale: 4
};

function addIdRotaTopology(idsRota, idsRotaCoordinates, map){

    markersIdRota = [];
    networkCoordinatesIdRota = [];
    markersIdRotaPt = [];

    var html_table = ''
    //html_table = html_table + '<div id="legend">'
    html_table = html_table + '<table class="table table-borderless table-sm"><thead><tr>';
    html_table = html_table + '<th scope="col">EILD(s)</th>';
    html_table = html_table + '<th scope="col">Site A</th><th scope="col">Site B</th>';
    html_table = html_table + '<th scope="col">Latencia (RTD)</th>';
    html_table = html_table + '<th scope="col">Rest. L1</th>';
    html_table = html_table + '<th scope="col">Rest. L0</th>';
    html_table = html_table + '</tr></thead><tbody>';
    for(var c=0; c<idsRota.length; c++){
        oms = idsRotaCoordinates.filter(function(obj){return obj.idRota == idsRota[c].idRota});
        color = '#'+Math.floor(Math.random()*16777215).toString(16);

        for(var i=0; i<oms.length; i++){
            createMarkerIdRota(oms[i], map, idsRota[c].SiteA, idsRota[c].SiteB);
            createLineIdRota(oms[i], idsRota[c].idRota, color, map);
        };
        html_table = html_table + '<tr id="' + idsRota[c].idRota + '" style="color:' + color + ';" >';
        html_table = html_table + '<td>' + idsRota[c].idRota + '</td>';
        html_table = html_table + '<td>' + idsRota[c].SiteA + '</td>';
        html_table = html_table + '<td>' + idsRota[c].SiteB + '</td>';
        html_table = html_table + '<td>' + idsRota[c].Latencia.toFixed(3) * 2 + '</td>';
        html_table = html_table + '<td>' + idsRota[c].L1 + '</td>';
        html_table = html_table + '<td>' + idsRota[c].L0 + '</td>';
        html_table = html_table + '</tr>';
    }
    html_table = html_table + '</tbody></table>';

    html_table = html_table + '<table>';
    /*
    html_table = html_table + '<tr>';
    html_table = html_table + '<td align="left" width="80">Detalhes: </td>';
    html_table = html_table + '<td align="left" width="20">';
    html_table = html_table + '<a id="detalhesIdRota" onclick="geraXLS(idsRotaExcel, idsRotaFields)"><span style="cursor:pointer"><i class="material-icons">archive</i></span></a>';
    html_table = html_table + '</td>';
    html_table = html_table + '</tr>';
    */
    html_table = html_table + '<tr>';
    html_table = html_table + '<td align="left" width="80">Labels</td>';
    html_table = html_table + '<td align="left" width="20">';
    html_table = html_table + '<i style="cursor:pointer" class="material-icons" onclick="labelIdRota(map, true)">add</i>';
    html_table = html_table + '</td>';
    html_table = html_table + '<td align="left" width="20">';
    html_table = html_table + '<i style="cursor:pointer" class="material-icons" onclick="labelIdRota(map, false)">remove</i>';
    html_table = html_table + '</td>';
    html_table = html_table + '</tr>';
    html_table = html_table + '</table>';
    //html_table = html_table + '</div>';

    //document.getElementById('map').appendChild(html_table);
    //map.controls[google.maps.ControlPosition.LEFT_TOP].push(document.getElementById('legend'));
    document.getElementById("legend").innerHTML+=html_table;


    function createMarkerIdRota(coord, map, ptA, ptB){
        labelA = null;
        labelB = null;

        if(coord.SiteA + '-' + coord.UFA == ptA || coord.SiteA + '-' + coord.UFA == ptB) labelA = coord.SiteA + '.' + coord.UFA;
        if(coord.SiteB + '-' + coord.UFB == ptA || coord.SiteB + '-' + coord.UFB == ptB) labelB = coord.SiteB + '.' + coord.UFB;

        var markerA = new google.maps.Marker({
            label: labelA,
            site: coord.SiteA + '.' + coord.UFA,
            title: coord.SiteA + '.' + coord.UFA + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeA, coord.LongitudeA)
        });

        var markerB = new google.maps.Marker({
            label: labelB,
            site: coord.SiteB + '.' + coord.UFB,
            title: coord.SiteB + '.' + coord.UFB + ' (idRota: ' + coord.idRota + ')',
            icon: {
                url: iconBase + '/vendor/Outros/FOADM.png',
                labelOrigin: new google.maps.Point(0, -4)
            },
            position: new google.maps.LatLng(coord.LatitudeB, coord.LongitudeB)
        });

        if(!(markerA.label == null)){
            markersIdRotaPt.push(markerA);
        } else {
            markerA.addListener('click', function() {
              if(markerA.label == null){
                markerA.setLabel(markerA.site);
              } else  {
                markerA.setLabel(null);
              }
            });
        }

        if(!(markerB.label == null)){
            markersIdRotaPt.push(markerB);
        } else {
            markerB.addListener('click', function() {
              if(markerB.label == null){
                markerB.setLabel(markerB.site);
              } else  {
                markerB.setLabel(null);
              }
            });
        }

        markersIdRota.push(markerA);
        markersIdRota.push(markerB);
        markerA.setMap(map);
        markerB.setMap(map);
    }

    function createLineIdRota(coord, id, color, map){

        iconLine = []
        if(coord.Status != 'Ativado'){
            iconLine = [{
                icon: lineSymbol,
                offset: '0',
                repeat: '20px'
            }]
        }

        var line = new google.maps.Polyline({
            path: [{'lat': Number(coord.LatitudeA),
                    'lng': Number(coord.LongitudeA)},
                   {'lat': Number(coord.LatitudeB),
                    'lng': Number(coord.LongitudeB)}],
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1,
            strokeWeight: 3,
            icons: iconLine,
            idRota: id
        })

        networkCoordinatesIdRota.push(line);
        line.setMap(map);
    }
}

function addMarkers(markers, visible){
    for (var i=0; i<markers.length; i++){
        markers[i].setMap(visible);
    }
}

function addNetworkCoordinates(networkCoordinates, visible){
    for(var i=0; i<networkCoordinates.length; i++){
        networkCoordinates[i].setMap(visible);
    }
}

function labelIdRota(map, condition){
    if(condition){
        for (var i = 0; i < markersIdRota.length; i++){
            markersIdRota[i].setLabel(markersIdRota[i].site);
        }
    } else {
        for (var i = 0; i < markersIdRota.length; i++){
            markersIdRota[i].setLabel(null);
        }
        for (var i = 0; i < markersIdRotaPt.length; i++){
            markersIdRotaPt[i].setLabel(markersIdRotaPt[i].site);
        }
    }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function gambMap() {
    document.getElementById('collapseMapa').classList.add('show');
    await sleep(2000);
    document.getElementById('collapseMapa').classList.remove('show');
}

function addDiagrama(diagrama){
    /*
    cy = cytoscape({
        container: document.getElementById('progress'), // container to render in
        elements: data_elements,
        style: style_cy,
        layout: layout_cy
    });
    */
    var html_diagrama = ''
    html_diagrama = html_diagrama + '<img';
    html_diagrama = html_diagrama + 'src="' + diagrama + '"';
    html_diagrama = html_diagrama + 'alt="Diagrama"';
    html_diagrama = html_diagrama + 'height="200"';
    html_diagrama = html_diagrama + '/>';

}
