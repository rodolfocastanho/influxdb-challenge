var data_elements = [{
    'data': {
        'id': 'NIT.RJ'
    }
}, {
    'data': {
        'id': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 6,
        'source': 'NIT.RJ',
        'target': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 'MGERJ.RJ'
    }
}, {
    'data': {
        'id': 'NIT.RJ'
    }
}, {
    'data': {
        'id': 3497,
        'source': 'MGERJ.RJ',
        'target': 'NIT.RJ'
    }
}, {
    'data': {
        'id': 'JPV.RJ'
    }
}, {
    'data': {
        'id': 'MGERJ.RJ'
    }
}, {
    'data': {
        'id': 3498,
        'source': 'JPV.RJ',
        'target': 'MGERJ.RJ'
    }
}, {
    'data': {
        'id': 'JPV.RJ'
    }
}, {
    'data': {
        'id': 'MSJ.RJ'
    }
}, {
    'data': {
        'id': 2038,
        'source': 'JPV.RJ',
        'target': 'MSJ.RJ'
    }
}, {
    'data': {
        'id': 'BAR.RJ'
    }
}, {
    'data': {
        'id': 'MSJ.RJ'
    }
}, {
    'data': {
        'id': 4,
        'source': 'BAR.RJ',
        'target': 'MSJ.RJ'
    }
}, {
    'data': {
        'id': 'MSJ.RJ'
    }
}, {
    'data': {
        'id': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 9,
        'source': 'MSJ.RJ',
        'target': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 'ARC.RJ'
    }
}, {
    'data': {
        'id': 'BAR.RJ'
    }
}, {
    'data': {
        'id': 8,
        'source': 'ARC.RJ',
        'target': 'BAR.RJ'
    }
}, {
    'data': {
        'id': 'ARC.RJ'
    }
}, {
    'data': {
        'id': 'TLP.RJ'
    }
}, {
    'data': {
        'id': 7,
        'source': 'ARC.RJ',
        'target': 'TLP.RJ'
    }
}]