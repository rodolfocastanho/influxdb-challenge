var style_cy = [ // the stylesheet for the graph
    {
        selector: 'node',
        style: {
        'background-color': '#666',
        'label': 'data(id)'
        }
    },

    {
        selector: 'edge',
        style: {
        'width': 3,
        'line-color': '#ccc',
        'target-arrow-color': '#ccc',
        'target-arrow-shape': 'triangle'
        }
    }
]

var layout_cy = {
    // Called on `layoutready`
    ready: function () {
    },
    // Called on `layoutstop`
    stop: function () {
    },
    // number of ticks per frame; higher is faster but more jerky
    refresh: 30,
    // Whether to fit the network view after when done
    fit: true,
    // Padding on fit
    padding: 10,
    // Prevent the user grabbing nodes during the layout (usually with animate:true)
    ungrabifyWhileSimulating: false,
    // Type of layout animation. The option set is {'during', 'end', false}
    animate: 'end',
    // Duration for animate:end
    animationDuration: 500,   
    // How apart the nodes are
    nodeSeparation: 60
}