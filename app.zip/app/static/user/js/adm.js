function resetSenha(id){
    $.ajax({
        url: '/usuario/adm',
        data: {
          id_user: id
        },
        type: 'GET'
    });

    document.getElementById('img-'+id).classList.remove('text-secondary');
    document.getElementById('img-'+id).classList.add('text-warning');
}

function admUser(id){
    var user = document.getElementById('tdUserNameId-'+String(id)).textContent;
    var name = document.getElementById('tdUserName-'+String(id)).textContent;
    var userPerm = usersPermission.filter(function(obj){return obj.user_id == id}).map((data) => data.role_id);

    html = '' +
    '<form>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputLogin">Login</label>' +
    '<big id="inputLogin" class="form-text text-muted">'+user+'</big>' +
    '<input type="hidden" id="inputId" value="'+id+'" />' +
    '</div>' +
    '</div>' +
    '<div class="form-row">' +
    '<div class="form-group col-md-12">' +
    '<label for="inputNome">Nome</label>' +
    '<input type="text" class="form-control" id="inputNome" value="'+name+'">' +
    '</div>' +
    '</div>' +
    //'<div class="form-check">' +
    //'<input type="checkbox" class="form-check-input" id="inputReset">' +
    //'<label class="form-check-label">Resetar a senha</label>' +
    //'</div>' +
    '<hr>' +
    '<big class="form-text text-muted">Permissões</big>'

    roles.forEach(function(item){
        var checked = (userPerm.includes(item.id)) ? 'checked' : '';
        html = html +
        '<div class="form-check">' +
        '<input '+checked+' class="form-check-input" name="inputPermissoes" type="checkbox" value="'+item.id+'" id="'+item.name+'">' +
        '<label class="form-check-label" for="'+item.name+'">'+item.description+'</label>' +
        '</div>'
    });

    html = html +
    '<hr>' +
    '<button class="btn btn-outline-secondary" type="button" onclick="saveEditUser()">Gravar</button>' +
    '</form>'

    document.getElementById('modalEditarUsuarioFiltro').innerHTML = html;
    document.getElementById('modalEditarUsuario').style.display='block';
}

function closeModal(){
    document.getElementById('modalEditarUsuario').style.display='none';
    document.getElementById('modalEditarUsuarioFiltro').innerHTML = '';
}

function saveEditUser(){
    var rolesAdd = [];
    var rolesDel = []

    x = document.getElementsByName('inputPermissoes')
    for(k=0;k< x.length;k++)
    {
        console.log(k);
        console.log(x[k].checked);
      if(x[k].checked){
        rolesAdd.push(parseInt(x[k].value));
        var addR = {};
        addR['user_id'] = parseInt(document.getElementById('inputId').value);
        addR['role_id'] = parseInt(x[k].value);
        usersPermission.push(addR);
      } else {
        rolesDel.push(parseInt(x[k].value));
        var indexObj = usersPermission.indexOf(usersPermission.filter(function(obj){return obj.user_id === parseInt(document.getElementById('inputId').value) && obj.role_id === parseInt(x[k].value)})[0]);
        if(indexObj >= 0){
            usersPermission.splice(parseInt(indexObj), 1);
        }
      }
    }

    $.ajax({
        url: '/usuario/adm',
        data: {
          id_user: String(document.getElementById('inputId').value),
          name: String(document.getElementById('inputNome').value),
          //resetSenha: document.getElementById('inputReset').checked,
          rolesAdd: rolesAdd.join('_'),
          rolesDel: rolesDel.join('_')
        },
        type: 'GET'
    });

    document.getElementById('tdUserName-'+String(document.getElementById('inputId').value)).textContent = String(document.getElementById('inputNome').value);
    document.getElementById('trUserName-'+String(document.getElementById('inputId').value)).style.backgroundColor = '#d5f5e3'

    swal("", "Usuário Atualizado!!", "success", {buttons: false, timer: 2000});
    closeModal();
}